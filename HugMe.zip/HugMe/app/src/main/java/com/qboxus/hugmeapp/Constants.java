package com.qboxus.hugmeapp;

public class Constants {
    public static String tag="hugme_";


    public static final String BASE_URL ="https://domain.com/mobileapp_apis/";
    public static final String API_BASE_URL = BASE_URL +"index.php?p=";


    // if you want to add a time limit in live streaming then make this true
    public static final boolean STREAMING_LIMIT = true;

    // if you want to change the streaming time then change it for now it is 60 sec
    public static final int MAX_STREMING_TIME = 60000;

    // if you want a user can't share a video from your app then you have to set this value to true
    public static final boolean IS_SECURE_INFO = false;


    public static final boolean CALLING_LIMIT =true;
    public static final int MAX_VIDEO_CALLING_TIME =60000;
    public static final int MAX_VOICE_CALLING_TIME =60000;

    public static String licenseKey="licenseKey";
    public static final String PRODUCT_ID ="test_sub_weekly1";
    public static final String PRODUCT_ID_2 ="test_sub_monthly1";
    public static final String PRODUCT_ID_3 ="test_sub_yearly1";

    public static final int BOOST_TIME =1800000;

    public static int minAge = 15;

    public static String defalutMinAge ="15";
    public static String defalutMaxAge = "64";
    public static String defalutMaxDistance = "10000";
    public static String defalutGender ="all";
    public static String defalutSearchByStatus ="all";


}
