package com.qboxus.hugmeapp.models;

public class InboxModel {

    String block, date, msg, name, pic, rid, status, like;


    public String getBlock() {
        return block;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPic() {
        return pic;
    }


    public String getRid() {
        return rid;
    }


    public String getStatus() {
        return status;
    }


    public void setStatus(String status) {
        this.status = status;
    }


    public String getLike() {
        return like;
    }

    public void setLike(String like) {
        this.like = like;
    }
}
