package com.qboxus.hugmeapp.activitiesandfragments.activities;

import static com.qboxus.hugmeapp.codeclasses.Functions.hasPermissions;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.facebook.drawee.view.SimpleDraweeView;
import com.qboxus.hugmeapp.Constants;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.PermissionUtils;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.interfaces.FragmentCallBack;
import com.qboxus.hugmeapp.volleypackage.FileUploader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class VerifyProfile extends AppCompatActivity implements View.OnClickListener {

    SimpleDraweeView userImage;

    TextView takePhotoBtn,whyneedbtn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_profile);
        findViewById(R.id.back_btn).setOnClickListener(this);


        takePhotoBtn= findViewById(R.id.takePhotoBtn);
        takePhotoBtn.setOnClickListener(this);

        whyneedbtn=findViewById(R.id.whyneedbtn);
        whyneedbtn.setOnClickListener(this);

        userImage=findViewById(R.id.userImage);


      }


    @Override
    public void onClick(View view) {
        switch (view.getId()){

            case R.id.back_btn:
                finish();
                break;

            case R.id.takePhotoBtn:
                if(selectedImage!=null){
                    uploadProfileVideo(imageFilePath);
                }
                else  {
                        openCameraIntent();
                }
                break;

            case R.id.whyneedbtn:
                if(selectedImage!=null) {
                    openCameraIntent();
                }
                else {
                    VerifyMessageBottomSheet verifyMessageBottomSheet = VerifyMessageBottomSheet.newInstance(new FragmentCallBack() {
                        @Override
                        public void onResponce(Bundle bundle) {
                            if (bundle != null) {
                                openCameraIntent();

                            }
                        }
                    });
                    verifyMessageBottomSheet.show(getSupportFragmentManager(), "VerifyMessageBottomSheet");

                }
                break;
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    public boolean checkPermissions() {

        String[] PERMISSIONS = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
        };

        if (!hasPermissions(this, PERMISSIONS)) {
            requestPermissions(PERMISSIONS, 2);
        } else {
            return true;
        }

        return false;
    }



    String imageFilePath;
    Uri selectedImage;
    private File createImageFile() throws IOException {
        String timeStamp =
                new SimpleDateFormat("yyyyMMdd_HHmmss",
                        Locale.getDefault()).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir =
                this.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );

        imageFilePath = image.getAbsolutePath();
        return image;
    }


    PermissionUtils takePermissionUtils;
    private void openCameraIntent() {

        takePermissionUtils=new PermissionUtils(VerifyProfile.this,mPermissionResult);
        if (takePermissionUtils.isStorageCameraPermissionGranted())
        {
            Intent pictureIntent = new Intent(
                    MediaStore.ACTION_IMAGE_CAPTURE);
            if (pictureIntent.resolveActivity(getPackageManager()) != null) {
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                } catch (Exception ex) {
                }
                if (photoFile != null) {
                    Uri photoURI = FileProvider.getUriForFile(getApplicationContext(), getPackageName() + ".fileprovider", photoFile);
                    pictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    resultCallbackForCamera.launch(pictureIntent);
                }
            }
        }
        else
        {
            takePermissionUtils.showStorageCameraPermissionDailog(getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
        }

    }


    private ActivityResultLauncher<String[]> mPermissionResult = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onActivityResult(Map<String, Boolean> result) {

                    boolean allPermissionClear=true;
                    List<String> blockPermissionCheck=new ArrayList<>();
                    for (String key : result.keySet())
                    {
                        if (!(result.get(key)))
                        {
                            allPermissionClear=false;
                            blockPermissionCheck.add(Functions.getPermissionStatus(VerifyProfile.this,key));
                        }
                    }
                    if (blockPermissionCheck.contains("blocked"))
                    {
                        Functions.showPermissionSetting(VerifyProfile.this,getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
                    }
                    else
                    if (allPermissionClear)
                    {
                        openCameraIntent();
                    }

                }
            });

    ActivityResultLauncher<Intent> resultCallbackForCamera = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Matrix matrix = new Matrix();
                        try {
                            android.media.ExifInterface exif = new android.media.ExifInterface(imageFilePath);
                            int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                            switch (orientation) {
                                case android.media.ExifInterface.ORIENTATION_ROTATE_90:
                                    matrix.postRotate(90);
                                    break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_180:
                                    matrix.postRotate(180);
                                    break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_270:
                                    matrix.postRotate(270);
                                    break;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        selectedImage = (Uri.fromFile(new File(imageFilePath)));

                        userImage.setVisibility(View.VISIBLE);
                        userImage.setImageURI(selectedImage);
                        findViewById(R.id.beforeSelectedLayout).setVisibility(View.GONE);
                        findViewById(R.id.afterSelectedLayout).setVisibility(View.VISIBLE);
                        takePhotoBtn.setText(R.string.agree_and_submit);
                        whyneedbtn.setText(R.string.retake);
                    }
                }
            });



    private void uploadProfileVideo(String filepath) {
        Functions.showLoader(this,false,false);
        String userId=Functions.getSharedPreference(this).getString(Variables.FB_ID, "");
        FileUploader fileUploader = new FileUploader(new File(filepath),getApplicationContext(),userId);
        fileUploader.SetCallBack(new FileUploader.FileUploaderCallback() {
            @Override
            public void onError() {
                Functions.cancelLoader();

            }

            @Override
            public void onFinish(String responses) {
                Functions.cancelLoader();
                Functions.printLog(Constants.tag,responses);
                try {
                    JSONObject jsonObject = new JSONObject(responses);
                    int code = jsonObject.optInt("code",0);
                    JSONArray msg = jsonObject.getJSONArray("msg");
                    JSONObject response=msg.getJSONObject(0);

                     if (code!=200) {
                        Functions.showAlert(VerifyProfile.this,"Verify Profile",response.optString("response"),null);
                    }
                    else {
                         Functions.getSharedPreference(VerifyProfile.this).edit().putString(Variables.Varified,"1").commit();
                        Functions.showAlert(VerifyProfile.this,"Verify Profile","Profile verified successfully",null);
                    }

                } catch (Exception e) {
                    Functions.printLog(Constants.tag,"Exception: "+e);
                }
            }

            @Override
            public void onProgressUpdate(int currentpercent, int totalpercent,String msg) {
                //send progress broadcast
                if (currentpercent>0)
                {

                }
            }
        });


    }



}