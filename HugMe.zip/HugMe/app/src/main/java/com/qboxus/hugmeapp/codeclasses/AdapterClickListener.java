package com.qboxus.hugmeapp.codeclasses;

import android.view.View;

public interface AdapterClickListener {

    void onItemClick(int postion, Object model, View view);
    void onLongItemClick(int postion, Object model, View view);
}
