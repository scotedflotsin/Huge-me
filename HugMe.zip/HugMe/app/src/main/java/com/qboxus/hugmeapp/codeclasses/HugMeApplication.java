package com.qboxus.hugmeapp.codeclasses;

import static com.qboxus.hugmeapp.codeclasses.ImagePipelineConfigUtils.getDefaultImagePipelineConfig;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.facebook.ads.AudienceNetworkAds;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.qboxus.hugmeapp.activitiesandfragments.activities.NoInternetA;
import com.qboxus.hugmeapp.interfaces.InternetCheckCallback;
import com.qboxus.hugmeapp.livestreaming.rtc.AgoraEventHandler;
import com.qboxus.hugmeapp.livestreaming.rtc.EngineConfig;
import com.qboxus.hugmeapp.livestreaming.rtc.EventHandler;
import com.qboxus.hugmeapp.livestreaming.stats.StatsManager;
import com.qboxus.hugmeapp.livestreaming.utils.FileUtil;
import com.qboxus.hugmeapp.livestreaming.utils.PrefManager;
import com.qboxus.hugmeapp.models.UserOnlineModel;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.activitiesandfragments.activities.CustomErrorActivity;
import com.smartnsoft.backgrounddetector.BackgroundDetectorCallback;
import com.smartnsoft.backgrounddetector.BackgroundDetectorHandler;

import java.util.HashMap;

import cat.ereza.customactivityoncrash.config.CaocConfig;
import io.agora.rtc.RtcEngine;


public class HugMeApplication extends Application implements Application.ActivityLifecycleCallbacks, BackgroundDetectorHandler.OnVisibilityChangedListener {

    private BackgroundDetectorHandler backgroundDetectorHandler;
    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseApp.initializeApp(getApplicationContext());
        Fresco.initialize(this,getDefaultImagePipelineConfig(this));
        AudienceNetworkAds.initialize(this);
        registerActivityLifecycleCallbacks(this);
        backgroundDetectorHandler = new BackgroundDetectorHandler(new BackgroundDetectorCallback(BackgroundDetectorHandler.ON_ACTIVITY_RESUMED, this));


        addFirebaseToken();
        setUserOnline();

        initCrashActivity();
        initConfig();
        Functions.createNoMediaFile(getApplicationContext());


    }







    private RtcEngine mRtcEngine;
    private EngineConfig mGlobalConfig = new EngineConfig();
    private AgoraEventHandler mHandler = new AgoraEventHandler();
    private StatsManager mStatsManager = new StatsManager();

    private void initConfig() {

        try {
            mRtcEngine = RtcEngine.create(getApplicationContext(), getString(R.string.agora_app_id), mHandler);
            mRtcEngine.setChannelProfile(io.agora.rtc.Constants.CHANNEL_PROFILE_LIVE_BROADCASTING);
            mRtcEngine.enableVideo();
            mRtcEngine.setLogFile(FileUtil.initializeLogFile(this));
        } catch (Exception e) {
            e.printStackTrace();
        }

        SharedPreferences pref = PrefManager.getPreferences(getApplicationContext());
        mGlobalConfig.setVideoDimenIndex(pref.getInt(
                com.qboxus.hugmeapp.livestreaming.Constants.PREF_RESOLUTION_IDX, com.qboxus.hugmeapp.livestreaming.Constants.DEFAULT_PROFILE_IDX));

        boolean showStats = pref.getBoolean(com.qboxus.hugmeapp.livestreaming.Constants.PREF_ENABLE_STATS, false);
        mGlobalConfig.setIfShowVideoStats(showStats);
        mStatsManager.enableStats(showStats);

        mGlobalConfig.setMirrorLocalIndex(pref.getInt(com.qboxus.hugmeapp.livestreaming.Constants.PREF_MIRROR_LOCAL, 0));
        mGlobalConfig.setMirrorRemoteIndex(pref.getInt(com.qboxus.hugmeapp.livestreaming.Constants.PREF_MIRROR_REMOTE, 0));
        mGlobalConfig.setMirrorEncodeIndex(pref.getInt(com.qboxus.hugmeapp.livestreaming.Constants.PREF_MIRROR_ENCODE, 0));
    }

    public EngineConfig engineConfig() {
        return mGlobalConfig;
    }

    public RtcEngine rtcEngine() {
        return mRtcEngine;
    }

    public StatsManager statsManager() {
        return mStatsManager;
    }

    public void registerEventHandler(EventHandler handler) {
        mHandler.addHandler(handler);
    }

    public void removeEventHandler(EventHandler handler) {
        mHandler.removeHandler(handler);
    }






    public void initCrashActivity(){
        CaocConfig.Builder.create()
                .backgroundMode(CaocConfig.BACKGROUND_MODE_SILENT)
                .enabled(true)
                .showErrorDetails(true)
                .showRestartButton(true)
                .logErrorOnRestart(true)
                .trackActivities(true)
                .minTimeBetweenCrashesMs(2000)
                .restartActivity(CustomErrorActivity.class)
                .errorActivity(CustomErrorActivity.class)
                .apply();
    }

    public static HashMap<String, UserOnlineModel> allOnlineUser=new HashMap<>();
    ChildEventListener onlineEventListener;
    DatabaseReference rootref;
    private void setUserOnline() {
        rootref = FirebaseDatabase.getInstance().getReference();
        addOnlineListener();
    }

    public void addOnlineListener(){
        if (onlineEventListener==null)
        {
            addOnlineStatus();
            onlineEventListener =new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                    if (!(TextUtils.isEmpty(snapshot.getValue().toString())))
                    {
                        UserOnlineModel item=snapshot.getValue(UserOnlineModel.class);
                        allOnlineUser.put(item.getUserId(),item);
                    }
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                    if (!(TextUtils.isEmpty(snapshot.getValue().toString())))
                    {
                        UserOnlineModel item=snapshot.getValue(UserOnlineModel.class);
                        allOnlineUser.remove(item.getUserId());
                    }
                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            };
            rootref.child(Variables.onlineUser).addChildEventListener(onlineEventListener);
        }
    }

    public void removeOnlineListener() {
        if (rootref!=null && onlineEventListener != null) {
            removeOnlineStatus();
            rootref.child(Variables.onlineUser).removeEventListener(onlineEventListener);
            onlineEventListener=null;
        }
    }

    private void removeOnlineStatus() {
        if (Functions.getSharedPreference(getApplicationContext()).getBoolean(Variables.IS_LOGIN,false))
        {
            rootref.child(Variables.onlineUser).child(Functions.getSharedPreference(getApplicationContext()).getString(Variables.FB_ID,"0"))
                    .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    Functions.logDMsg("removeOnlineStatus: "+Functions.getSharedPreference(getApplicationContext()).getString(Variables.FB_ID,"0"));
                };
            });

        }
    }

    private void addOnlineStatus() {
        if (Functions.getSharedPreference(getApplicationContext()).getBoolean(Variables.IS_LOGIN,false))
        {
            UserOnlineModel onlineModel=new UserOnlineModel();
            onlineModel.setUserId(Functions.getSharedPreference(getApplicationContext()).getString(Variables.FB_ID,"0"));
            onlineModel.setUserName(Functions.getSharedPreference(getApplicationContext()).getString(Variables.F_NAME,"")+" "+Functions.getSharedPreference(getApplicationContext()).getString(Variables.L_NAME,""));
            onlineModel.setUserPic(Functions.getSharedPreference(getApplicationContext()).getString(Variables.IMAGE1,""));

            rootref.child(Variables.onlineUser).child(Functions.getSharedPreference(getApplicationContext()).getString(Variables.FB_ID,"0")).onDisconnect().removeValue();
            rootref.child(Variables.onlineUser).child(Functions.getSharedPreference(getApplicationContext()).getString(Variables.FB_ID,"0")).keepSynced(true);
            rootref.child(Variables.onlineUser).child(Functions.getSharedPreference(getApplicationContext()).getString(Variables.FB_ID,"0")).setValue(onlineModel)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Functions.logDMsg("addOnlineStatus: "+onlineModel.getUserId());
                        };
                    });

        }
    }

    public void addFirebaseToken() {

        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            return;
                        }
                        // Get new FCM registration token
                        String token = task.getResult();
                        Functions.logDMsg("token: "+token);
                        SharedPreferences.Editor editor = Functions.getSharedPreference(getApplicationContext()).edit();
                        editor.putString(Variables.DEVICE_TOKEN, ""+token);
                        editor.commit();
                    }
                });


    }


    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState)
    {

    }

    @Override
    public void onTerminate()
    {
        super.onTerminate();
        unregisterActivityLifecycleCallbacks(this);
    }

    @Override
    public void onActivityStarted(Activity activity)
    {

    }

    @Override
    public void onActivityResumed(Activity activity)
    {
        backgroundDetectorHandler.onActivityResumed(activity);
        Functions.RegisterConnectivity(activity, new InternetCheckCallback() {
            @Override
            public void GetResponse(String requestType, String response) {
                if(response.equalsIgnoreCase("disconnected")) {
                    removeOnlineListener();
                    activity.startActivity(new Intent(activity, NoInternetA.class));
                    activity.overridePendingTransition(R.anim.in_from_bottom,R.anim.out_to_top);
                }
                else
                {
                    addOnlineListener();
                }
            }
        });
    }

    @Override
    public void onActivityPaused(Activity activity)
    {
        backgroundDetectorHandler.onActivityPaused(activity);
        Functions.unRegisterConnectivity(activity);
    }

    @Override
    public void onActivityStopped(Activity activity)
    {

    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState)
    {

    }

    @Override
    public void onActivityDestroyed(Activity activity)
    {

    }

    @Override
    public void onAppGoesToBackground(Context context)
    {
        removeOnlineListener();
    }

    @Override
    public void onAppGoesToForeground(Context context)
    {
        addOnlineListener();
    }


}
