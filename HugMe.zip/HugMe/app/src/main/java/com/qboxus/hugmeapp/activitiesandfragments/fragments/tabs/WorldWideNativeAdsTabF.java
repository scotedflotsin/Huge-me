package com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.android.volley.BuildConfig;
import com.appyvet.materialrangebar.RangeBar;
import com.facebook.drawee.view.SimpleDraweeView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.qboxus.hugmeapp.Constants;
import com.qboxus.hugmeapp.activitiesandfragments.activities.MainActivity;
import com.qboxus.hugmeapp.activitiesandfragments.activities.SearchPlacesA;
import com.qboxus.hugmeapp.adapters.WorldWideAdapter;
import com.qboxus.hugmeapp.bottomsheet.WorldWideProfileBottomSheet;
import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.codeclasses.RootFragment;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.interfaces.FragmentCallBack;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.codeclasses.SpacesItemDecoration;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.volleypackage.CallBack;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pl.bclogic.pulsator4droid.library.PulsatorLayout;

public class WorldWideNativeAdsTabF extends RootFragment {

    public  RecyclerView recyclerView;
    public WorldWideAdapter adapter;
    public List<Object> dataList = new ArrayList<>();
    public int numberofads;
    public  int swipePosition ;
    public  TextView searchPlaceWw;
    View v;
    Context context;
    RelativeLayout findNearbyUser;
    PulsatorLayout pulsator;
    ProgressBar progressBar;
    ImageView imageView;
    String searchGender, searchFilterBy, searchDistance;
    TextView distance;
    Toolbar toolbar;
    SimpleDraweeView profileimage;
    Button changeSettingBtn;
    private AdLoader adLoader;
    private List<UnifiedNativeAd> mNativeAds = new ArrayList<>();

    public WorldWideNativeAdsTabF()  {
        //required public constructor
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = LayoutInflater.from(getContext()).inflate(R.layout.fragment_world_wide, container,false);

        context = getContext();


        progressBar = v.findViewById(R.id.progress_bar);


        pulsator = (PulsatorLayout) v.findViewById(R.id.pulsator);
        findNearbyUser = v.findViewById(R.id.find_nearby_User);
        profileimage = v.findViewById(R.id.profileimage);

        changeSettingBtn = v.findViewById(R.id.change_setting_btn);
        changeSettingBtn.setOnClickListener(v -> displayFilterDialogue());


        try {
            String img = Functions.getSharedPreference(context).getString(Variables.IMAGE1,"");
            profileimage.setController(Functions.frescoImageLoad(img,R.drawable.ic_avatar,profileimage,false));

        } catch (Exception b) {
            Functions.logDMsg("" + b.toString());
        }

        MobileAds.initialize(context,
                getString(R.string.admob_app_id));


        toolbar = (Toolbar) v.findViewById(R.id.toolbar);
        imageView = (ImageView) v.findViewById(R.id.control_IV_id);
        imageView.setOnClickListener(v -> {
            displayFilterDialogue();

        });

        distance = v.findViewById(R.id.distance);


        recyclerView = (RecyclerView) v.findViewById(R.id.world_wide_RV_id);


        return v;

    }


    public  void updatedataOnrightSwipe(Context context, final UserModel item) {

        Functions.sendPushNotification(context, item.getFbId(), "Messege", "like");

        final DatabaseReference rootref = FirebaseDatabase.getInstance().getReference();
        final String user_id =Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        final String user_name = Functions.getSharedPreference(context).getString(Variables.F_NAME,"");


        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("hh");
        final String formattedDate = df.format(c);

        Query query = rootref.child("Match").child(item.getFbId()).child(user_id);
        query.keepSynced(true);

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists() || item.getSwipe().equals("like")) {
                    Map mymap = new HashMap<>();
                    mymap.put("match", "true");
                    mymap.put("type", "like");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getFirstName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("match", "true");
                    othermap.put("type", "like");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", user_name);
                    othermap.put("effect", "false");

                    rootref.child("Match").child(user_id + "/" + item.getFbId()).updateChildren(mymap);
                    rootref.child("Match").child(item.getFbId() + "/" + user_id).updateChildren(othermap);

                } else {
                    Map mymap = new HashMap<>();
                    mymap.put("match", "false");
                    mymap.put("type", "like");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getFirstName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("match", "false");
                    othermap.put("type", "like");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", user_name);
                    othermap.put("effect", "false");

                    rootref.child("Match").child(user_id + "/" + item.getFbId()).setValue(mymap);
                    rootref.child("Match").child(item.getFbId() + "/" + user_id).setValue(othermap);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void setMenuVisibility(boolean isVisibleToUser) {
        super.setMenuVisibility(isVisibleToUser);
        if (isVisibleToUser) {

            ArrayList<UserModel> tempList = new ArrayList<>();
            for (int i = 0; i < dataList.size(); i++) {

                if (dataList.get(i) instanceof UserModel) {
                    UserModel item = (UserModel) dataList.get(i);
                    if (SwipeTabF.removedUserIdsIndex.contains(item.getFbId())) {
                        tempList.add(item);

                    }
                }
            }

            for (int i = 0; i < tempList.size(); i++) {
                dataList.remove(tempList.get(i));
            }

            if (adapter != null)
                adapter.notifyDataSetChanged();


            if (Variables.isSearched == 1) {

                dataList.clear();
                String handleSearch =  Functions.getSharedPreference(context).getString(Variables.SEARCH_PARAMS_JSON,"{}");

                if (handleSearch != null) {
                    getNearByUsers();
                    Variables.isSearched = 0;
                }

            }
            else if(dataList.isEmpty()){
                getNearByUsers();
            }
        }
    }

    public void getNearByUsers() {

        String userId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        String search =  Functions.getSharedPreference(context).getString(Variables.SEARCH_PARAMS_JSON,"{}");
        String searchGender = "", searchAgeMin = "", searchAgeMax = "", searchDistance = "";
        try {

            JSONObject searchObj = new JSONObject(search);
            searchGender = searchObj.optString("gender", Constants.defalutGender);
            searchAgeMin = searchObj.optString("age_min", Constants.defalutMinAge);
            searchAgeMax = searchObj.optString("age_max", Constants.defalutMaxAge);
            searchDistance = searchObj.optString("search_distance", Constants.defalutMaxDistance);
        } catch (Exception n) {
            searchGender = Constants.defalutGender;
            searchAgeMin = Constants.defalutMinAge;
            searchAgeMax = Constants.defalutMaxAge;
            searchDistance = Constants.defalutMaxDistance;

        }


        final JSONObject parameters = new JSONObject();


        try {
            parameters.put("fb_id", userId);
            parameters.put("lat_long", Functions.getSharedPreference(context).getFloat(Variables.LATITUDE,0f)+", "+Functions.getSharedPreference(context).getFloat(Variables.LONGITUDE,0f));
            parameters.put("gender", searchGender);
            parameters.put("distance", searchDistance);
            parameters.put("device_token", Functions.getSharedPreference(context).getString(Variables.DEVICE_TOKEN,""));
            parameters.put("device", "android");
            parameters.put("age_min", searchAgeMin);
            parameters.put("age_max", searchAgeMax);
            parameters.put("version", BuildConfig.VERSION_NAME);
            if (MainActivity.purductPurchase)
                parameters.put("purchased", "1");
            else
                parameters.put("purchased", "0");

        } catch (Exception e) {
            e.printStackTrace();
        }

        Functions.logDMsg("parms at wordwide : "+ parameters.toString());
        progressBar.setVisibility(View.VISIBLE);

        ApiRequest.callApi(
                context,
                ApiLinks.userNearByMe,
                parameters,
                new CallBack() {
                    @Override
                    public void getResponse(String requestType, String resp) {
                        try {
                            JSONObject response = new JSONObject(resp);

                            handleResponse(response);


                        } catch (Exception b) {
                            Functions.toastMsg(context, "Err " + b.toString());
                        }


                    }
                }
        );


    }

    public void handleResponse(JSONObject response) {
        try {
            JSONArray msgArr = response.getJSONArray("msg");
            if (msgArr.length() == 0) {
                progressBar.setVisibility(View.GONE);
                findNearbyUser.setVisibility(View.VISIBLE);
                pulsator.start();


            } else {
                findNearbyUser.setVisibility(View.GONE);

                for (int i = 0; i < msgArr.length(); i++) {
                    JSONObject userObj = msgArr.getJSONObject(i);
                    UserModel nearby = ParseData.parseUserModel(userObj);


                    dataList.add(nearby);
                }

                loadNativeAds();

            }

        } catch (Exception b) {
            progressBar.setVisibility(View.GONE);
            Functions.toastMsg(context, "Error " + b.toString());
        }

    }

    private void loadNativeAds() {

        numberofads = dataList.size() / Variables.adDisplayAfter;

        AdLoader.Builder builder = new AdLoader.Builder(context, getString(R.string.native_ad_id));
        adLoader = builder.forUnifiedNativeAd(
                unifiedNativeAd -> {
                    Functions.printLog(Constants.tag,"unifiedNativeAd");
                    mNativeAds.add(unifiedNativeAd);
                    if (!adLoader.isLoading()) {
                        insertAdsInMenuItems();
                    }
                    else {
                        setAdapter();
                    }

                }).withAdListener(
                new AdListener() {
                    @Override
                    public void onAdFailedToLoad(LoadAdError errorCode) {
                        Functions.printLog(Constants.tag,errorCode.toString());
                        setAdapter();
                    }
                }).build();

        adLoader.loadAds(new AdRequest.Builder().build(), numberofads);
    }

    private void insertAdsInMenuItems() {
        if (mNativeAds.size() <= 0) {
            setAdapter();
            return;
        }

        int index = Variables.adDisplayAfter;
        while (index < dataList.size()) {

            for (UnifiedNativeAd ad : mNativeAds) {
                dataList.add(index, ad);
                index = index + Variables.adDisplayAfter + 1;
                if (index > dataList.size()) {
                    setAdapter();
                    return;
                }

            }
            setAdapter();
        }

        setAdapter();

    }

    public void setAdapter() {
        progressBar.setVisibility(View.GONE);
        if(adapter==null) {
            adapter = new WorldWideAdapter(new AdapterClickListener() {
                @Override
                public void onItemClick(int postion, Object model, View view) {

                    WorldWideProfileBottomSheet viewProfile = new WorldWideProfileBottomSheet(dataList, postion, new FragmentCallBack() {
                        @Override
                        public void onResponce(Bundle bundle) {
                            if(bundle!=null && bundle.getString("action")!=null){
                                String action= bundle.getString("action");
                                if(action.equals("like")){
                                    int position=bundle.getInt("pos");
                                    if(position<dataList.size() && dataList.get(position) instanceof UserModel) {
                                        updatedataOnrightSwipe(getContext(), (UserModel) dataList.get(position));

                                        dataList.remove(position);
                                        adapter.notifyDataSetChanged();
                                    }



                                }
                                else if(action.equals("scroll")){
                                    int position=bundle.getInt("pos");
                                    recyclerView.smoothScrollToPosition(position);
                                }


                            }
                        }
                    });
                    viewProfile.show(getActivity().getSupportFragmentManager(), viewProfile.getTag());
                    swipePosition = postion;


                }

                @Override
                public void onLongItemClick(int postion, Object model, View view) {

                }

            }, dataList, context);
            StaggeredGridLayoutManager manager = new StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.VERTICAL);
            recyclerView.addItemDecoration(new SpacesItemDecoration(context.getResources().getDimensionPixelSize(R.dimen.base_16), context.getResources().getDimensionPixelOffset(R.dimen.base_90)));
            recyclerView.setLayoutManager(manager);
            recyclerView.setHasFixedSize(false);
            recyclerView.setAdapter(adapter);
        }
        else {
            adapter.notifyDataSetChanged();
        }
    }

    public void displayFilterDialogue() {

        final Dialog dialog = new Dialog(getContext());

        final View dialogview = LayoutInflater.from(getContext()).inflate(R.layout.item_filter_dialog_layout, null);
        String handleSearch = Functions.getSharedPreference(context).getString(Variables.SEARCH_PARAMS_JSON,"{}");

        String handleSearchGender = "", handleSearchFilterBy = "", handleSearchAgeMin = "", handleSearchAgeMax = "",
                handleSearchDistance = "";
        String userSearchPlace = Functions.getSharedPreference(context).getString(Variables.SEARCH_PLACE_NAME,"");


        final TextView filterText = dialogview.findViewById(R.id.filter_text);
        String sourceString = "<b>Filter</b> ";
        filterText.setText(Html.fromHtml(sourceString));

        final TextView tv = (TextView) dialogview.findViewById(R.id.guys_id);
        final TextView tv1 = (TextView) dialogview.findViewById(R.id.girls_id);
        final TextView tv2 = (TextView) dialogview.findViewById(R.id.both_id);

        final TextView tv4 = (TextView) dialogview.findViewById(R.id.all_id);
        final TextView tv5 = (TextView) dialogview.findViewById(R.id.online_id);
        final TextView tv6 = (TextView) dialogview.findViewById(R.id.new_id);

        final ImageView iv1 = (ImageView) dialogview.findViewById(R.id.dialog_cross_Id);
        final ImageView iv2 = (ImageView) dialogview.findViewById(R.id.dialog_tick_id);
        RangeBar rangeBar = (RangeBar) dialogview.findViewById(R.id.ww_RB_id);

        final TextView textAge = dialogview.findViewById(R.id.text_age);
        final TextView distance = dialogview.findViewById(R.id.distance);
        SeekBar simpleSeekBar = dialogview.findViewById(R.id.simpleSeekBar);
        simpleSeekBar.setProgress(Integer.parseInt(Constants.defalutMaxDistance));
        distance.setText("" + simpleSeekBar.getProgress());
        dialog.setContentView(dialogview);

        RelativeLayout nearByRLId = dialogview.findViewById(R.id.near_by_RL_id);
        searchPlaceWw = dialogview.findViewById(R.id.search_place);
        if (!(TextUtils.isEmpty(userSearchPlace))) {
            searchPlaceWw.setText("" + userSearchPlace);
        } else {
            searchPlaceWw.setText("People nearby");
        }


        nearByRLId.setOnClickListener(v -> startActivity(new Intent(getActivity(), SearchPlacesA.class)));


        if (handleSearch != null) {

            try {

                JSONObject searchObj = new JSONObject(handleSearch);
                handleSearchGender = searchObj.optString("gender");
                handleSearchFilterBy = searchObj.optString("filter_by");
                handleSearchAgeMin = searchObj.optString("age_min");
                handleSearchAgeMax = searchObj.optString("age_max");
                handleSearchDistance = searchObj.optString("search_distance");
                textAge.setText(handleSearchAgeMin + " - " + handleSearchAgeMax);

                rangeBar.setRangePinsByValue(Float.parseFloat(handleSearchAgeMin), Float.parseFloat(handleSearchAgeMax));

            } catch (Exception b) {
                b.printStackTrace();
            }

            searchDistance = handleSearchDistance;
            searchGender = handleSearchGender;
            try {
                if (handleSearchDistance != null) {
                    simpleSeekBar.setProgress(Integer.parseInt(handleSearchDistance));
                    distance.setText("" + handleSearchDistance);
                } else {
                    distance.setText(Constants.defalutMaxDistance);
                    simpleSeekBar.setProgress(Integer.parseInt(Constants.defalutMaxDistance));
                }

            } catch (Exception b) {
                b.printStackTrace();
            }

            if (handleSearchGender.equals("female")) {
                tv1.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
                tv.setBackgroundResource(R.drawable.d_gray_border);
                tv2.setBackgroundResource(R.drawable.d_gray_border);
            } else if (handleSearchGender.equals("male")) {
                tv1.setBackgroundResource(R.drawable.d_gray_border);
                tv.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
                tv2.setBackgroundResource(R.drawable.d_gray_border);
            } else {
                tv1.setBackgroundResource(R.drawable.d_gray_border);
                tv.setBackgroundResource(R.drawable.d_gray_border);
                tv2.setBackgroundResource(R.drawable.d_round_blue_border_radius8);


            }

            if (handleSearchFilterBy.equals("All")) {
                tv4.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
                tv5.setBackgroundResource(R.drawable.d_gray_border);
                tv6.setBackgroundResource(R.drawable.d_gray_border);

            } else if (handleSearchFilterBy.equals("Online")) {
                tv4.setBackgroundResource(R.drawable.d_gray_border);
                tv5.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
                tv6.setBackgroundResource(R.drawable.d_gray_border);

            } else {
                tv4.setBackgroundResource(R.drawable.d_gray_border);
                tv5.setBackgroundResource(R.drawable.d_gray_border);
                tv6.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            }


        } else {

            searchGender = Constants.defalutGender;
            searchFilterBy = Constants.defalutSearchByStatus;
            searchDistance = Constants.defalutMaxDistance;
        }


        simpleSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                distance.setText("" + progress);
                searchDistance = "" + progress + "";

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        try {
            rangeBar.setOnRangeBarChangeListener((rangeBar1, leftPinIndex, rightPinIndex, leftPinValue, rightPinValue) -> {
                textAge.setText("" + leftPinValue + " - " + "" + rightPinValue);
                Functions.logDMsg("Left " + leftPinValue + " Right " + rightPinValue);
            });

        } catch (Exception b) {

            Functions.logDMsg("" + b.toString());
        }


        tv.setOnClickListener(v -> {
            tv.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv1.setBackgroundResource(R.drawable.d_gray_border);
            tv2.setBackgroundResource(R.drawable.d_gray_border);
            addGender(tv);  // get Value from gender

        });


        tv1.setOnClickListener(v -> {
            tv1.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv.setBackgroundResource(R.drawable.d_gray_border);
            tv2.setBackgroundResource(R.drawable.d_gray_border);
            addGender(tv1);  //get Value from gender

        });


        tv2.setOnClickListener(v -> {
            tv2.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv.setBackgroundResource(R.drawable.d_gray_border);
            tv1.setBackgroundResource(R.drawable.d_gray_border);
            addGender(tv2);  //get Value from gender

        });


        tv4.setOnClickListener(v -> {
            tv4.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv5.setBackgroundResource(R.drawable.d_gray_border);
            tv6.setBackgroundResource(R.drawable.d_gray_border);
            addAllFilter(tv4);  //get Value from All Filter

        });


        tv5.setOnClickListener(v -> {
            tv5.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv4.setBackgroundResource(R.drawable.d_gray_border);
            tv6.setBackgroundResource(R.drawable.d_gray_border);
            addAllFilter(tv5);  //get Value from All Filter

        });


        tv6.setOnClickListener(v -> {
            tv6.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv5.setBackgroundResource(R.drawable.d_gray_border);
            tv4.setBackgroundResource(R.drawable.d_gray_border);
            addAllFilter(tv6);

        });


        iv1.setOnClickListener(v -> {
            dialog.dismiss();

        });


        iv2.setOnClickListener(v -> {
            mNativeAds.clear();
            dataList.clear();
            try {
                adapter.notifyDataSetChanged();
            } catch (Exception b) {
                b.printStackTrace();
            }


            try {
                JSONObject searchParams = new JSONObject();
                searchParams.put("gender", "" + searchGender);
                searchParams.put("filter_by", "" + searchFilterBy);
                searchParams.put("age_min", "" + rangeBar.getLeftPinValue());
                searchParams.put("age_max", "" + rangeBar.getRightPinValue());
                searchParams.put("search_distance", "" + searchDistance);

                Functions.getSharedPreference(context).edit().putString(Variables.SEARCH_PARAMS_JSON,"" + searchParams).commit();

            } catch (Exception b) {
                b.printStackTrace();
            }

            Variables.isSearchedAtWw = 1;
            handleSearchParams();

            dialog.dismiss();

        });


        dialog.show();


    }

    public void addGender(TextView textView) {
        searchGender = textView.getText().toString();

        if (searchGender.equals("Male")) {
            searchGender = "male";
        } else if (searchGender.equals("Female")) {
            searchGender = "female";
        } else if (searchGender.equals("Both")) {
            searchGender = "all";
        }

    }

    public void addAllFilter(TextView textView) {
        searchFilterBy = textView.getText().toString();
    }

    public void handleSearchParams() {

        String handleSearch = Functions.getSharedPreference(context).getString(Variables.SEARCH_PARAMS_JSON,"{}");
        String handleSearchGender = "", handleSearchAgeMin = "", handleSearchAgeMax = "",
                handleSearchDistance = "";

        if (handleSearch != null) {

            try {

                JSONObject searchObj = new JSONObject(handleSearch);
                handleSearchGender = searchObj.getString("gender");
                handleSearchAgeMin = searchObj.getString("age_min");
                handleSearchAgeMax = searchObj.getString("age_max");
                handleSearchDistance = searchObj.getString("search_distance");
            } catch (Exception n) {
                Functions.logDMsg("Obj Error " + n.toString());
            }
            searchDistance = handleSearchDistance;
            searchGender = handleSearchGender;

        }

        try {
            getNearByUsers();

        } catch (Exception b) {
            Functions.logDMsg("" + b.toString());
        }


    }


}
