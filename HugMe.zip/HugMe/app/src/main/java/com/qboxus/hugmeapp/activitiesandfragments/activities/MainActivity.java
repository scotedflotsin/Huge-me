package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.ads.MobileAds;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.qboxus.hugmeapp.Constants;
import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.MainF;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.volleypackage.CallBack;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatLocaleActivity {

    public static String userId;
    public static boolean purductPurchase = false;
    MainF fragment;
    long mBackPressed;
    Context context;
    DatabaseReference rootref;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);


        setContentView(R.layout.activity_main);
        context = MainActivity.this;


        MobileAds.initialize(this);

        Functions.displayFbAd(context);

        rootref = FirebaseDatabase.getInstance().getReference();

        userId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");




        fragment = new MainF();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.replace(R.id.RL_id, fragment).commit();


        checkSubscription();
    }

    private void checkSubscription() {
        JSONObject parameters = new JSONObject();
        try {
            String userId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");
            parameters.put("fb_id", userId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ApiRequest.callApi(context, ApiLinks.checkSubscription, parameters, new CallBack() {
            @Override
            public void getResponse(String requestType, String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    if (jsonObject.optInt("code")==200)
                    {
                        JSONArray msgArray=jsonObject.getJSONArray("msg");
                        if (msgArray.length()>0)
                        {
                            JSONObject purchaseSubscription=msgArray.getJSONObject(0);
                            String duration=purchaseSubscription.optString("duration","0");
                            String created=purchaseSubscription.optString("created");
                            if (!(checkDateIsExpire(duration,created)))
                            {
                                Log.d(Constants.tag,"checkDateIsExpire: false");
                                Functions.getSharedPreference(context).edit().putBoolean(Variables.IS_PURCHASE,true).commit();
                                MainActivity.purductPurchase = true;
                            }
                            else
                            {
                                Log.d(Constants.tag,"checkDateIsExpire: true");
                                Functions.getSharedPreference(context).edit().putBoolean(Variables.IS_PURCHASE,false).commit();
                                MainActivity.purductPurchase = false;
                            }

                        }
                        else
                        {
                            Functions.getSharedPreference(context).edit().putBoolean(Variables.IS_PURCHASE,false).commit();
                            MainActivity.purductPurchase = false;
                        }

                    }
                    else
                    {
                        Functions.getSharedPreference(context).edit().putBoolean(Variables.IS_PURCHASE,false).commit();
                        MainActivity.purductPurchase = false;
                    }
                }
                catch (Exception e)
                {
                    Log.d(Constants.tag,"Exception: "+e);
                }

            }
        });

    }

    private boolean checkDateIsExpire(String duration, String created) {

        int month=Integer.parseInt(duration);
        String subscriptionEndDate=Functions.ChangeDateFormatWithAdditionalMonth("yyyy-MM-dd HH:mm:ssZZ","yyyy-MM-dd HH:mm:ssZZ",created+"+0000", month);
        Log.d(Constants.tag,"Subscription End Date: "+subscriptionEndDate);
        String todayDate=Functions.getCurrentDate("yyyy-MM-dd HH:mm:ss");
        Log.d(Constants.tag,"Today Date: "+todayDate);
        return Functions.isDateExpiredInDays("yyyy-MM-dd HH:mm:ss",todayDate,subscriptionEndDate);
    }


    @SuppressLint("WrongConstant")
    @Override
    public void onBackPressed() {
        if (!fragment.onBackPressed()) {
            int count = this.getSupportFragmentManager().getBackStackEntryCount();
            if (count == 0) {
                if (mBackPressed + 2000 > System.currentTimeMillis()) {
                    super.onBackPressed();
                    return;
                } else {
                    Functions.toastMsg(this, "Tap Again To Exit");
                    mBackPressed = System.currentTimeMillis();

                }
            } else {
                super.onBackPressed();

            }
        }


    }


    @Override
    protected void onStart() {
        super.onStart();

        try {
            rootref.child("Users").child(userId).child("token").setValue(Functions.getSharedPreference(MainActivity.this).getString(Variables.DEVICE_TOKEN,""));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        for (Fragment fragment : getSupportFragmentManager().getFragments()) {

            for (Fragment fragment1 : fragment.getChildFragmentManager().getFragments()) {
                fragment1.onActivityResult(requestCode, resultCode, data);
            }
            fragment.onActivityResult(requestCode, resultCode, data);
        }

    }

}
