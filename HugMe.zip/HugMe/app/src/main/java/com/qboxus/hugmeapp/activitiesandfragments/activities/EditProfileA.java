package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.codeclasses.PermissionUtils;
import com.qboxus.hugmeapp.adapters.EditProfileAdapter;
import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import static com.qboxus.hugmeapp.codeclasses.Variables.userGender;
import static com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs.ProfileTabF.mCircleView;

public class EditProfileA extends AppCompatLocaleActivity implements View.OnClickListener {


    public static TextView userLiving, userChildren, userSmoking, userDrinking, userRelationship, userSex;
    Toolbar tb;
    ImageView iv, iv1;
    RecyclerView recyclerView;
    EditProfileAdapter adapter;
    RelativeLayout basicInfo, living, children, smoking, drinking, relation, sex;
    FirebaseStorage storage;
    StorageReference storageReference;
    List<String> listUserImgFromApi = new ArrayList<>();
    EditText aboutMe;
    ImageView icTick;
    Context context;
    TextView tv3IdLiving, tv4IdChildren, tv5IdSmoking, tv6IdDrinking, tv7IdRelationship, tv8IdSexuality,verifiedStatusTxt;
    TextView tvBasicInfo;
    PermissionUtils takePermissionUtils;

    ByteArrayOutputStream baos=null;

    // Update Profile_F
    public static void updateProfile(final Context context, final JSONObject parameters) {

        Functions.showLoader(context, false, false);

        ApiRequest.callApi(context, ApiLinks.editProfile, parameters, (requestType, resp) -> {

                    try {
                        Functions.cancelLoader();
                        JSONObject response = new JSONObject(resp);

                        if (response.getString("code").equals("200")) {

                            JSONArray msgObj = response.getJSONArray("msg");

                            JSONObject userInfoObj = msgObj.getJSONObject(0);

                            UserModel userdetailModel= ParseData.parseUserModel(userInfoObj);
                            Functions.storeUserLoginDataIntoDb(context,userdetailModel);


                            mCircleView.setValue(Functions.calculateCompleteProfile(context));

                        } else {
                            Functions.cancelLoader();
                        }
                    } catch (Exception b) {
                        Functions.logDMsg("Error " + b.toString());
                        Functions.cancelLoader();
                    }
                }
        );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        setContentView(R.layout.activity_edit_profile);
        context = EditProfileA.this;

        tb = (Toolbar) findViewById(R.id.edit_prof_TB_id);
        iv = (ImageView) tb.findViewById(R.id.edit_prof_back_id);
        iv1 = (ImageView) tb.findViewById(R.id.edit_prof_eye_id);
        aboutMe = findViewById(R.id.about_me);
        icTick = findViewById(R.id.ic_tick);


        Functions.displayFbAd(context);


        final String about = Functions.getSharedPreference(context).getString(Variables.ABOUT_ME,"");
        final String basic = Functions.getSharedPreference(context).getString(Variables.F_NAME,"") + ", " + Functions.getSharedPreference(context).getInt(Variables.AGE,0);

        aboutMe.setText("" + about);
        tvBasicInfo = findViewById(R.id.TV_basic_info);
        tvBasicInfo.setText("" + basic);


        userLiving = findViewById(R.id.user_living);
        userChildren = findViewById(R.id.user_children);
        userSmoking = findViewById(R.id.user_smoking);
        userDrinking = findViewById(R.id.user_drinking);
        userRelationship = findViewById(R.id.user_relationship);
        userSex = findViewById(R.id.user_sex);

        verifiedStatusTxt=findViewById(R.id.verifiedStatusTxt);
        findViewById(R.id.verifyLayout).setOnClickListener(this);

        String living1 = Functions.getSharedPreference(context).getString(Variables.LIVING,"");
        String children1 = Functions.getSharedPreference(context).getString(Variables.CHILDREN,"");
        String smoking1 = Functions.getSharedPreference(context).getString(Variables.SMOKING,"");
        String drinking1 = Functions.getSharedPreference(context).getString(Variables.DRINKING,"");
        String relationship1 = Functions.getSharedPreference(context).getString(Variables.RELATIONSHIP,"");
        String sexuality1 = Functions.getSharedPreference(context).getString(Variables.SEXUALITY,"");

        if (living1.equals("0") || living1.equals("")) {
            living1 = "";
        }

        if (children1.equals("0") || children1.equals("")) {
            children1 = "";
        }

        if (smoking1.equals("0") || smoking1.equals("")) {
            smoking1 = "";
        }

        if (drinking1.equals("0") || drinking1.equals("")) {
            drinking1 = "";
        }

        if (relationship1.equals("0") || relationship1.equals("")) {
            relationship1 = "";
        }

        if (sexuality1.equals("0") || sexuality1.equals("")) {
            sexuality1 = "";
        }


        userLiving.setText("" + living1);
        userChildren.setText("" + children1);
        userSmoking.setText("" + smoking1);
        userDrinking.setText("" + drinking1);
        userRelationship.setText("" + relationship1);
        userSex.setText("" + sexuality1);


        basicInfo = (RelativeLayout) findViewById(R.id.RL1_id);
        living = (RelativeLayout) findViewById(R.id.RL3_id);
        children = (RelativeLayout) findViewById(R.id.RL4_id);
        smoking = (RelativeLayout) findViewById(R.id.RL5_id);
        drinking = (RelativeLayout) findViewById(R.id.RL6_id);
        relation = (RelativeLayout) findViewById(R.id.RL7_id);
        sex = (RelativeLayout) findViewById(R.id.RL8_id);

        // init TextViews
        tv3IdLiving = findViewById(R.id.TV3_id);
        tv4IdChildren = findViewById(R.id.TV4_id);
        tv5IdSmoking = findViewById(R.id.TV5_id);
        tv6IdDrinking = findViewById(R.id.TV6_id);
        tv7IdRelationship = findViewById(R.id.TV7_id);
        tv8IdSexuality = findViewById(R.id.TV8_id);


        // init Firebase Storage
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();


        recyclerView = findViewById(R.id.edit_prof_RL_id);
        adapter = new EditProfileAdapter( listUserImgFromApi, new AdapterClickListener() {
            @Override
            public void onItemClick(int postion, Object model, View view) {

                if (view.getId() == R.id.edit_prof_IV_id)
                {

                } else if (view.getId() == R.id.ivCancel) {
                    removeImage(postion);
                } else if (view.getId() == R.id.RL_add_img) {
                    takePermissionUtils=new PermissionUtils(EditProfileA.this,mPermissionResult);
                    if (takePermissionUtils.isStorageCameraPermissionGranted())
                    {
                        selectImage();
                    }
                    else
                    {
                        takePermissionUtils.showStorageCameraPermissionDailog(context.getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
                    }
                }

            }

            @Override
            public void onLongItemClick(int postion, Object model, View view) {

            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setHasFixedSize(false);
        recyclerView.setAdapter(adapter);

        iv.setOnClickListener(this);
        iv1.setOnClickListener(this);

        basicInfo.setOnClickListener(this);
        living.setOnClickListener(this);
        children.setOnClickListener(this);
        smoking.setOnClickListener(this);
        drinking.setOnClickListener(this);
        relation.setOnClickListener(this);
        sex.setOnClickListener(this);
        icTick.setOnClickListener(this);

    }

    @Override
    public void onResume() {
        super.onResume();
        getuserInfo(Functions.getSharedPreference(context).getString(Variables.FB_ID,""));
    }


    private ActivityResultLauncher<String[]> mPermissionResult = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onActivityResult(Map<String, Boolean> result) {

                    boolean allPermissionClear=true;
                    List<String> blockPermissionCheck=new ArrayList<>();
                    for (String key : result.keySet())
                    {
                        if (!(result.get(key)))
                        {
                            allPermissionClear=false;
                            blockPermissionCheck.add(Functions.getPermissionStatus(EditProfileA.this,key));
                        }
                    }
                    if (blockPermissionCheck.contains("blocked"))
                    {
                        Functions.showPermissionSetting(EditProfileA.this,context.getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
                    }
                    else
                    if (allPermissionClear)
                    {
                        selectImage();
                    }

                }
            });


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.ic_tick:
                createJsonForAPI();

                break;
            case R.id.edit_prof_back_id:
                mCircleView.setValue(Functions.calculateCompleteProfile(context));
                finish();
                break;
            case R.id.edit_prof_eye_id:
                startActivity(new Intent(EditProfileA.this, ViewProfileA.class));
                break;

            case R.id.verifyLayout:
                Intent verifyIntent = new Intent(EditProfileA.this, VerifyProfile.class);
                startActivity(verifyIntent);
                break;


            case R.id.RL1_id:

                Intent myintentGender = new Intent(EditProfileA.this, BasicInfoA.class);
                myintentGender.putExtra("gender", "" + userGender); //Optional parameters
                startActivity(myintentGender);

                break;
            case R.id.RL3_id:
                Intent myIntent = new Intent(EditProfileA.this, LivingA.class);
                myIntent.putExtra("living", "" + userLiving.getText()); //Optional parameters
                startActivity(myIntent);


                break;
            case R.id.RL4_id:
                Intent myintentChild = new Intent(EditProfileA.this, ChildrenA.class);
                myintentChild.putExtra("child", "" + userChildren.getText()); //Optional parameters
                startActivity(myintentChild);

                break;
            case R.id.RL5_id:

                Intent myIntentSmoking = new Intent(EditProfileA.this, SmokingA.class);
                myIntentSmoking.putExtra("smoking", "" + userSmoking.getText()); //Optional parameters
                startActivity(myIntentSmoking);

                break;
            case R.id.RL6_id:

                Intent myintentDrink = new Intent(EditProfileA.this, DrinkingA.class);
                myintentDrink.putExtra("drinking", "" + userDrinking.getText()); //Optional parameters
                startActivity(myintentDrink);


                break;
            case R.id.RL7_id:

                Intent myIntentRelation = new Intent(EditProfileA.this, RelationshipA.class);
                myIntentRelation.putExtra("relation", "" + userRelationship.getText()); //Optional parameters
                startActivity(myIntentRelation);

                break;
            case R.id.RL8_id:

                Intent myintentSexx = new Intent(EditProfileA.this, SexualityA.class);
                myintentSexx.putExtra("sexuality", "" + userSex.getText()); //Optional parameters
                startActivity(myintentSexx);
                break;



            default:
                break;

        }
    }

    public void removeImage(int position) {
        final String user_id = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");
        Functions.deleteImage(context, "" + listUserImgFromApi.get(position), user_id);

        listUserImgFromApi.remove(position);
        adapter.notifyDataSetChanged();

    }

    public void createJsonForAPI() {

        final String user_id = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", "" + user_id);
            parameters.put("about_me", "" + aboutMe.getText().toString().replaceAll("[-+.^:,']", ""));
            parameters.put("job_title", "job_title");
            parameters.put("company", "company");
            parameters.put("school", "school");
            parameters.put("living", "" + Variables.varLiving.replaceAll("[-+.^:,']", ""));
            parameters.put("children", "" + Variables.varChildren.replaceAll("[-+.^:,']", ""));
            parameters.put("smoking", "" + Variables.varSmoking.replaceAll("[-+.^:,']", ""));
            parameters.put("drinking", "" + Variables.varDrinking.replaceAll("[-+.^:,']", ""));
            parameters.put("relationship", "" + Variables.varRelationship.replaceAll("[-+.^:,']", ""));
            parameters.put("sexuality", "" + Variables.varSexuality.replaceAll("[-+.^:,']", ""));

            parameters.put("image1", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE1,""));
            parameters.put("image2", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE2,""));
            parameters.put("image3", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE3,""));
            parameters.put("image4", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE4,""));
            parameters.put("image5", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE5,""));
            parameters.put("image6", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE6,""));

            parameters.put("gender", "" + userGender.replaceAll("[-+.^:,']", ""));
            parameters.put("birthday", "" + Functions.getSharedPreference(context).getString(Variables.BIRTHDAY,""));

            Functions.logDMsg("parameters  e: " + parameters);
            updateProfile(context, parameters);

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    // this method will show the dialog of selete the either take a picture form camera or pick the image from gallary
    private void selectImage() {

        final CharSequence[] options = {getString(R.string.take_photo),
                getString(R.string.choose_from_gallery), getString(R.string.cancel)};


        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.AlertDialogCustom);

        builder.setTitle(getString(R.string.add_photo_));

        builder.setItems(options, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (options[item].equals(getString(R.string.take_photo))) {
                    openCameraIntent();
                } else if (options[item].equals(getString(R.string.choose_from_gallery))) {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    resultCallbackForGallery.launch(intent);
                } else if (options[item].equals(getString(R.string.cancel))) {
                    dialog.dismiss();
                }
            }

        });
        builder.show();

    }

    ActivityResultLauncher<Intent> resultCallbackForGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        Uri selectedImage = data.getData();
                        beginCrop(selectedImage);

                    }
                }
            });


    String imageFilePath="";
    private File createImageFile() throws Exception {
        String timeStamp =
                new SimpleDateFormat("yyyyMMdd_HHmmss",
                        Locale.ENGLISH).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir =
                context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );

        imageFilePath = image.getAbsolutePath();
        return image;
    }


    private void beginCrop(Uri source) {
        Intent intent= CropImage.activity(source).setCropShape(CropImageView.CropShape.RECTANGLE)
                .setAspectRatio(1,1).getIntent(context);
        resultCallbackForCrop.launch(intent);
    }

    ActivityResultLauncher<Intent> resultCallbackForCrop = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        CropImage.ActivityResult cropResult = CropImage.getActivityResult(data);
                        handleCrop(cropResult.getUri());
                    }
                }
            });

    // get the image uri after the image crope
    private void handleCrop(Uri userimageuri) {

        InputStream imageStream = null;
        try {
            imageStream = context.getContentResolver().openInputStream(userimageuri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        final Bitmap imagebitmap = BitmapFactory.decodeStream(imageStream);

        String path = userimageuri.getPath();
        Matrix matrix = new Matrix();
        android.media.ExifInterface exif = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            try {
                exif = new android.media.ExifInterface(path);
                int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                switch (orientation) {
                    case android.media.ExifInterface.ORIENTATION_ROTATE_90:
                        matrix.postRotate(90);
                        break;
                    case android.media.ExifInterface.ORIENTATION_ROTATE_180:
                        matrix.postRotate(180);
                        break;
                    case android.media.ExifInterface.ORIENTATION_ROTATE_270:
                        matrix.postRotate(270);
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        Bitmap rotatedBitmap = Bitmap.createBitmap(imagebitmap, 0, 0, imagebitmap.getWidth(), imagebitmap.getHeight(), matrix, true);
        baos = new ByteArrayOutputStream();
        rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 20, baos);

        File uriPath=Functions.getBitmapToUri(context,rotatedBitmap,"profilePic"+Functions.getRandomString(2)+".jpg");
        addProfilePic(uriPath);
    }


    // below three method is related with taking the picture from camera
    private void openCameraIntent() {
        Intent pictureIntent = new Intent(
                MediaStore.ACTION_IMAGE_CAPTURE);
        if (pictureIntent.resolveActivity(context.getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (Exception ex) {
            }
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(context.getApplicationContext(), context.getPackageName() + ".fileprovider", photoFile);
                pictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                resultCallbackForCamera.launch(pictureIntent);
            }
        }
    }

    ActivityResultLauncher<Intent> resultCallbackForCamera = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Matrix matrix = new Matrix();
                        try {
                            android.media.ExifInterface exif = new android.media.ExifInterface(imageFilePath);
                            int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                            switch (orientation) {
                                case android.media.ExifInterface.ORIENTATION_ROTATE_90:
                                    matrix.postRotate(90);
                                    break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_180:
                                    matrix.postRotate(180);
                                    break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_270:
                                    matrix.postRotate(270);
                                    break;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Uri selectedImage = (Uri.fromFile(new File(imageFilePath)));
                        beginCrop(selectedImage);
                    }
                }
            });



    // Upload User Profile_F.
    public void addProfilePic(File uriPath) {

        Functions.showLoader(context, true, false);


        final String fbId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        StorageReference ref = storageReference.child("images/" + UUID.randomUUID().toString());
        ref.putFile(Uri.fromFile(uriPath))
                .addOnSuccessListener(taskSnapshot -> ref.getDownloadUrl().addOnSuccessListener(uri -> {


                    listUserImgFromApi.add(uri.toString());

                    for (int i = 0; i < listUserImgFromApi.size(); i++) {
                        if (listUserImgFromApi.get(i).equals("") || listUserImgFromApi.get(i).equals("0")) {
                            listUserImgFromApi.remove(i);
                        }
                    }

                    if (listUserImgFromApi.size() < 6) {
                        listUserImgFromApi.add("0");
                    }
                    adapter.notifyDataSetChanged();


                    final JSONObject parameters = new JSONObject();
                    try {
                        parameters.put("image_link", uri.toString());
                        parameters.put("fb_id", fbId);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                    ApiRequest.callApi(context, "" + ApiLinks.uploadImages, parameters,
                            (requestType, response) -> {

                                Functions.cancelLoader();

                                try {
                                    JSONObject resp = new JSONObject(response);
                                    JSONArray msgArr = resp.getJSONArray("msg");
                                    msgArr.getJSONObject(0).getString("response");

                                    Functions.getUserInfo(fbId, context);  // Method to save User data into Local Shared Prefrence

                                    Functions.toastMsg(context, "" + msgArr.getJSONObject(0).getString("response"));
                                } catch (Exception v) {
                                    v.printStackTrace();
                                }


                            }
                    );
                }));


    }

    public void getuserInfo(final String userId) {

        Functions.showLoader(context, false, false);
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", userId);

        }
        catch (JSONException e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(context, ApiLinks.getUserInfo, parameters, (requestType, resp) -> {
                    try {
                        Functions.cancelLoader();

                        JSONObject response = new JSONObject(resp);

                        if (response.getString("code").equals("200")) {

                            JSONArray msgObj = response.getJSONArray("msg");
                            JSONObject userInfoObj = msgObj.getJSONObject(0);

                            UserModel userdetailModel= ParseData.parseUserModel(userInfoObj);
                            Functions.storeUserLoginDataIntoDb(context,userdetailModel);

                            Variables.varSexuality = userInfoObj.getString("about_me");
                            Variables.varLiving = userInfoObj.getString("living");
                            Variables.varChildren = userInfoObj.getString("children");
                            Variables.varSmoking = userInfoObj.getString("smoking");
                            Variables.varDrinking = userInfoObj.getString("drinking");
                            Variables.varRelationship = userInfoObj.getString("relationship");
                            Variables.varSexuality = userInfoObj.getString("sexuality");
                            Variables.varAboutMe = userInfoObj.getString("about_me");
                            userGender = userInfoObj.getString("gender");

                            String verified=userInfoObj.optString("verified","0");
                            if(verified.equalsIgnoreCase("1")){
                                verifiedStatusTxt.setText(R.string.verified);
                            }else {
                                verifiedStatusTxt.setText(R.string.not_verified);
                            }


                            listUserImgFromApi.clear();
                            if (!userInfoObj.getString("image1").equals("") && !userInfoObj.getString("image1").equals("0")) {
                                listUserImgFromApi.add(userInfoObj.getString("image1"));
                            }

                            if (!userInfoObj.getString("image2").equals("") && !userInfoObj.getString("image2").equals("0")) {
                                listUserImgFromApi.add(userInfoObj.getString("image2"));
                            }

                            if (!userInfoObj.getString("image3").equals("") && !userInfoObj.getString("image3").equals("0")) {
                                listUserImgFromApi.add(userInfoObj.getString("image3"));
                            }

                            if (!userInfoObj.getString("image4").equals("") && !userInfoObj.getString("image4").equals("0")) {
                                listUserImgFromApi.add(userInfoObj.getString("image4"));
                            }

                            if (!userInfoObj.getString("image5").equals("") && !userInfoObj.getString("image5").equals("0")) {
                                listUserImgFromApi.add(userInfoObj.getString("image5"));
                            }

                            if (!userInfoObj.getString("image6").equals("") && !userInfoObj.getString("image6").equals("0")) {
                                listUserImgFromApi.add(userInfoObj.getString("image6"));
                            }

                            listUserImgFromApi.add("");

                            String living = userInfoObj.getString("living");
                            String children = userInfoObj.getString("children");
                            String smoking = userInfoObj.getString("smoking");
                            String drinking = userInfoObj.getString("drinking");
                            String relationship = userInfoObj.getString("relationship");
                            String sexuality = userInfoObj.getString("sexuality");


                            if (living.equals("0") || living.equals("")) {
                                living = "";
                            }

                            if (children.equals("0") || children.equals("")) {
                                children = "";
                            }

                            if (smoking.equals("0") || smoking.equals("")) {
                                smoking = "";
                            }

                            if (drinking.equals("0") || drinking.equals("")) {
                                drinking = "";
                            }

                            if (relationship.equals("0") || relationship.equals("")) {
                                relationship = "";
                            }

                            if (sexuality.equals("0") || sexuality.equals("")) {
                                sexuality = "";
                            }

                            userLiving.setText("" + living);
                            userChildren.setText("" + children);
                            userSmoking.setText("" + smoking);
                            userDrinking.setText("" + drinking);
                            userRelationship.setText("" + relationship);
                            userSex.setText("" + sexuality);

                            aboutMe.setText("" + userInfoObj.getString("about_me"));

                            adapter.notifyDataSetChanged();
                        }
                    } catch (Exception b) {

                        Functions.toastMsg(context, "" + b.toString());
                    }finally {
                        Functions.cancelLoader();
                    }

                }
        );
    }


}
