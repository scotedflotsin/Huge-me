package com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.facebook.drawee.view.SimpleDraweeView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.qboxus.hugmeapp.Constants;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.codeclasses.PermissionUtils;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.activitiesandfragments.activities.EditProfileVpA;
import com.qboxus.hugmeapp.activitiesandfragments.activities.EditProfileA;
import com.qboxus.hugmeapp.activitiesandfragments.activities.MainActivity;
import com.qboxus.hugmeapp.activitiesandfragments.activities.ViewProfileA;
import com.qboxus.hugmeapp.boost.BoostF;
import com.qboxus.hugmeapp.bottomsheet.MyProfileBottomSheet;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.inappsubscription.InAppSubscriptionA;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.MainF;
import com.soundcloud.android.crop.Crop;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import at.grabner.circleprogress.CircleProgressView;
import at.grabner.circleprogress.Direction;

import static android.app.Activity.RESULT_OK;
import static com.facebook.FacebookSdk.getApplicationContext;


public class ProfileTabF extends Fragment implements View.OnClickListener {

    public static CircleProgressView mCircleView;
    View v;
    ImageView iv1;
    TextView profTv;
    CardView getMoreAten;
    RelativeLayout popularityRl;
    LinearLayout creditsActivatePopularity;
    LinearLayout creditPremiumLl;
    Context context;
    FirebaseStorage storage;
    StorageReference storageReference;
    RelativeLayout profileRLId;
    SimpleDraweeView userimageImg;
    TextView usernameTxt;
    TextView completeText, subscribeTxt;
    String userImage;
    String userName;
    String imageFilePath;

    PermissionUtils takePermissionUtils;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = LayoutInflater.from(getContext()).inflate(R.layout.fragment_profile, container,false);

        context = getContext();
        profileRLId = v.findViewById(R.id.profile_RL_id);
        completeText = v.findViewById(R.id.complete_text);

        usernameTxt = v.findViewById(R.id.username_txt);
        MainF.toolbar.setVisibility(View.GONE);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        userimageImg = v.findViewById(R.id.userimage_img);
        userimageImg.setOnClickListener(this);

        profileRLId.setOnClickListener(this);


        popularityRl =  v.findViewById(R.id.boost_layout);
        creditsActivatePopularity =  v.findViewById(R.id.credits_activate_popularity_rl_id);

        profTv =  v.findViewById(R.id.see_profile);

        creditPremiumLl =  v.findViewById(R.id.credtis_premium_ll_id);

        getMoreAten =  v.findViewById(R.id.get_more_atten_cv_id);

        iv1 =  v.findViewById(R.id.add_photo_img_id);
        iv1.setOnClickListener(this);


        mCircleView = v.findViewById(R.id.cpv_id);
        mCircleView.setMaxValue(100);
        mCircleView.setDirection(Direction.CW);
        mCircleView.setUnit("%");
        mCircleView.setUnitVisible(true);
        mCircleView.setMinimumWidth(42);
        mCircleView.setMinimumHeight(42);
        mCircleView.setTextSize(30); // text size set, auto text size off
        mCircleView.setUnitSize(22); // if i set the text size i also have to set the unit size
        mCircleView.setUnitScale(1f);
        mCircleView.setTextScale(1f);
        mCircleView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        mCircleView.setTextColor(ContextCompat.getColor(getActivity(), R.color.purple));
        mCircleView.setUnitColor(ContextCompat.getColor(getActivity(), R.color.purple));
        mCircleView.setBarColor(ContextCompat.getColor(getActivity(), R.color.purple));
        mCircleView.setBarWidth(6);

        mCircleView.setRimColor(ContextCompat.getColor(getActivity(), R.color.off_white));
        mCircleView.setRimWidth(6);

        mCircleView.setInnerContourSize(0);
        mCircleView.setOuterContourSize(0);

        getMoreAten.setOnClickListener(this);
        profTv.setOnClickListener(this);
        usernameTxt.setOnClickListener(this);


        v.findViewById(R.id.premium_layout).setOnClickListener(this);
        v.findViewById(R.id.boost_layout).setOnClickListener(this);

        subscribeTxt = v.findViewById(R.id.subscribe_txt);

        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        if(isVisibleToUser)
            setUserData();
    }

    public void setUserData() {
        userImage = Functions.getSharedPreference(context).getString(Variables.IMAGE1,"");

        userName = Functions.getSharedPreference(context).getString(Variables.F_NAME,"")
                + " " + Functions.getSharedPreference(context).getString(Variables.L_NAME,"");
        usernameTxt.setText(userName + ", " + Functions.getSharedPreference(context).getInt(Variables.AGE,0));

        userimageImg.setController(
                Functions.frescoImageLoad(userImage,
                        R.drawable.ic_user_icon,userimageImg,false));

        if(Functions.getSharedPreference(context).getString(Variables.Varified,"0").equalsIgnoreCase("1")){
            v.findViewById(R.id.verifiedIcon).setVisibility(View.VISIBLE);
        }else {
            v.findViewById(R.id.verifiedIcon).setVisibility(View.GONE);
        }

        if (MainActivity.purductPurchase)
        {
            subscribeTxt.setText(context.getString(R.string.activated));
        }
        else
        {
            subscribeTxt.setText(context.getString(R.string.activate));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.get_more_atten_cv_id:

                if (Functions.calculateCompleteProfile(context) == 100) {
                    startActivity(new Intent(getActivity(), EditProfileA.class));
                } else {
                    startActivity(new Intent(context, EditProfileVpA.class));
                }
                break;

            case R.id.see_profile:
                startActivity(new Intent(getActivity(), ViewProfileA.class));
                break;
            case R.id.username_txt:
                startActivity(new Intent(getActivity(), ViewProfileA.class));
                break;

            case R.id.premium_layout:
                if (MainActivity.purductPurchase) {
                    Functions.toastMsg(context, context.getString(R.string.already_subscribe_package));
                } else
                    openSubscriptionView();
                break;

            case R.id.boost_layout:
                if (MainActivity.purductPurchase)
                    openBoost();
                else
                    openSubscriptionView();
                break;

            case R.id.add_photo_img_id:
            {
                takePermissionUtils=new PermissionUtils(getActivity(),mCameraStoragePermissionResult);
                if (takePermissionUtils.isStorageCameraPermissionGranted()) {
                    selectImage();
                }
                else
                {
                    takePermissionUtils.
                            showStorageCameraPermissionDailog(getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
                }
            }
            break;

            case R.id.profile_RL_id:
                startActivity(new Intent(getActivity(), EditProfileA.class));
                break;

            case R.id.userimage_img:
                addUserRecord();
                break;

            default:
                break;
        }
    }


    private ActivityResultLauncher<String[]> mCameraStoragePermissionResult = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onActivityResult(Map<String, Boolean> result) {

                    boolean allPermissionClear=true;
                    List<String> blockPermissionCheck=new ArrayList<>();
                    for (String key : result.keySet())
                    {
                        if (!(result.get(key)))
                        {
                            allPermissionClear=false;
                            blockPermissionCheck.add(Functions.getPermissionStatus(getActivity(),key));
                        }
                    }
                    if (blockPermissionCheck.contains("blocked"))
                    {
                        Functions.showPermissionSetting(getActivity(),getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
                    }
                    else
                    if (allPermissionClear)
                    {
                        selectImage();
                    }

                }
            });



    public void openSubscriptionView() {
        Intent intent=new Intent(context, InAppSubscriptionA.class);
        startActivity(intent);
    }

    public void openBoost() {
        BoostF matchF = new BoostF();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.addToBackStack(null);
        transaction.replace(R.id.Main_F, matchF).commit();

    }

    Boolean isVisibleToUser;
    @Override
    public void setMenuVisibility(boolean isVisibleToUser) {
        super.setMenuVisibility(isVisibleToUser);
        this.isVisibleToUser = isVisibleToUser;
        if (isVisibleToUser) {
           new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
               @Override
               public void run() {
                   if (Functions.calculateCompleteProfile(context) == 100) {
                       completeText.setText("Get more attention - \nProfile completed.");
                   }

                   mCircleView.setValue(Functions.calculateCompleteProfile(context));
                   setUserData();
               }
           },200);
        }
    }

    public void addUserRecord() {


        UserModel item=new UserModel();
        item.setFbId(Functions.getSharedPreference(context).getString(Variables.FB_ID,""));
        item.setAboutMe(Functions.getSharedPreference(context).getString(Variables.ABOUT_ME,""));
        item.setJobTitle( "Job");
        item.setGender(Functions.getSharedPreference(context).getString(Variables.GENDER,""));
        item.setBirthday(Functions.getSharedPreference(context).getString(Variables.BIRTHDAY,""));
        item.setAge(Functions.getSharedPreference(context).getInt(Variables.AGE,0));
        item.setCompany(Functions.getSharedPreference(context).getString(Variables.COMPANY,""));
        item.setSchool(Functions.getSharedPreference(context).getString(Variables.SCHOOL,""));
        item.setFirstName(Functions.getSharedPreference(context).getString(Variables.F_NAME,""));
        item.setLastName(Functions.getSharedPreference(context).getString(Variables.L_NAME,""));
        item.setLiving(Functions.getSharedPreference(context).getString(Variables.LIVING,""));
        item.setChildren(Functions.getSharedPreference(context).getString(Variables.CHILDREN,""));
        item.setSmoking(Functions.getSharedPreference(context).getString(Variables.SMOKING,""));
        item.setDrinking(Functions.getSharedPreference(context).getString(Variables.DRINKING,""));
        item.setRelationship(Functions.getSharedPreference(context).getString(Variables.RELATIONSHIP,""));
        item.setImage1(Functions.getSharedPreference(context).getString(Variables.IMAGE1,""));
        item.setImage2(Functions.getSharedPreference(context).getString(Variables.IMAGE2,""));
        item.setImage3(Functions.getSharedPreference(context).getString(Variables.IMAGE3,""));
        item.setImage4(Functions.getSharedPreference(context).getString(Variables.IMAGE4,""));
        item.setImage5(Functions.getSharedPreference(context).getString(Variables.IMAGE5,""));
        item.setImage6(Functions.getSharedPreference(context).getString(Variables.IMAGE6,""));

        item.Swipe ="like";
        item.block = "";
        item.distance = "no";



        Bundle bundleUserProfile = new Bundle();
        bundleUserProfile.putString("user_id", "" + Functions.getSharedPreference(context).getString(Variables.FB_ID,""));
        bundleUserProfile.putString("current_position", "");
        bundleUserProfile.putSerializable("user_near_by", item);

        MyProfileBottomSheet viewProfile = new MyProfileBottomSheet();
        viewProfile.setArguments(bundleUserProfile);

        viewProfile.show(getActivity().getSupportFragmentManager(), viewProfile.getTag());

    }

    // this method will show the dialog of selete the either take a picture form camera or pick the image from gallary
    private void selectImage() {

        final CharSequence[] options = {getString(R.string.take_photo),
                getString(R.string.choose_from_gallery), getString(R.string.cancel)};


        AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.AlertDialogCustom);

        builder.setTitle(getString(R.string.add_photo_));

        builder.setItems(options, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (options[item].equals(getString(R.string.take_photo))) {
                    openCameraIntent();
                } else if (options[item].equals(getString(R.string.choose_from_gallery))) {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    resultCallbackForGallery.launch(intent);
                } else if (options[item].equals(getString(R.string.cancel))) {
                    dialog.dismiss();
                }
            }
        });

        builder.show();

    }


    ActivityResultLauncher<Intent> resultCallbackForCrop = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        CropImage.ActivityResult cropResult = CropImage.getActivityResult(data);
                        handleCrop(cropResult.getUri());
                    }
                }
            });


    ActivityResultLauncher<Intent> resultCallbackForGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        Uri selectedImage = data.getData();
                        beginCrop(selectedImage);

                    }
                }
            });

    ActivityResultLauncher<Intent> resultCallbackForCamera = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Matrix matrix = new Matrix();
                        try {
                            android.media.ExifInterface exif = new android.media.ExifInterface(imageFilePath);
                            int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                            switch (orientation) {
                                case android.media.ExifInterface.ORIENTATION_ROTATE_90:
                                    matrix.postRotate(90);
                                    break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_180:
                                    matrix.postRotate(180);
                                    break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_270:
                                    matrix.postRotate(270);
                                    break;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Uri selectedImage = (Uri.fromFile(new File(imageFilePath)));
                        beginCrop(selectedImage);
                    }
                }
            });


    public File createImageFile() throws IOException {
        String timeStamp =
                new SimpleDateFormat("yyyyMMdd_HHmmss",
                        Locale.getDefault()).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir =
                context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  // prefix /
                ".jpg",         // suffix /
                storageDir      // directory /
        );

        imageFilePath = image.getAbsolutePath();
        return image;
    }


    private void beginCrop(Uri source) {
        Intent intent=CropImage.activity(source).setCropShape(CropImageView.CropShape.OVAL)
                .setAspectRatio(1,1).getIntent(context);
        resultCallbackForCrop.launch(intent);
    }

    // get the image uri after the image crope
    private void handleCrop(Uri userimageuri) {
        try {
            addProfilePic(userimageuri);
        } catch (Exception e) {
            Log.d(Constants.tag,"Exception: "+e);
        }
    }


    // below three method is related with taking the picture from camera
    private void openCameraIntent() {
        Intent pictureIntent = new Intent(
                MediaStore.ACTION_IMAGE_CAPTURE);
        if (pictureIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (Exception ex) {
            }
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(context.getApplicationContext(), getActivity().getPackageName() + ".fileprovider", photoFile);
                pictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                resultCallbackForCamera.launch(pictureIntent);
            }
        }
    }


    // Upload User Profile_F.
    public void addProfilePic(Uri filePath) {

        Functions.showLoader(context, true, false);

        final String fb_id = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        StorageReference ref = storageReference.child("images/" + UUID.randomUUID().toString());
        ref.putFile(filePath)
                .addOnSuccessListener(taskSnapshot -> ref.getDownloadUrl().addOnSuccessListener(uri -> {

                    Functions.logDMsg("Img Url " + uri.toString());


                    final JSONObject parameters = new JSONObject();
                    try {
                        parameters.put("image_link", uri.toString());
                        parameters.put("fb_id", fb_id);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                    ApiRequest.callApi(
                            context,
                            "" + ApiLinks.changeProfilePicture,
                            parameters,
                            (requestType, response) -> {

                                Functions.cancelLoader();
                                try {
                                    JSONObject resp = new JSONObject(response);
                                    if (resp.getString("code").equals("200")) {


                                        JSONArray msgObj = resp.getJSONArray("msg");
                                        JSONObject userInfoObj = msgObj.getJSONObject(0);

                                        UserModel userdetailModel= ParseData.parseUserModel(userInfoObj);
                                        Functions.storeUserLoginDataIntoDb(context,userdetailModel);

                                        setUserData();
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }


                            }
                    );
                }))
                .addOnFailureListener(e -> {
                })
                .addOnProgressListener(taskSnapshot -> {
                    double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot
                            .getTotalByteCount());

                });


    }





}
