package com.qboxus.hugmeapp.activitiesandfragments.fragments;


import android.content.Context;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;

import java.util.ArrayList;

import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.RootFragment;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.activitiesandfragments.activities.EditProfileVpA;
import com.qboxus.hugmeapp.adapters.ProfileOptionsAdapter;
import com.qboxus.hugmeapp.models.ProfileInfoModel;
import com.qboxus.hugmeapp.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class SmokeF extends RootFragment {

    View view;
    RecyclerView rv;
    ProfileOptionsAdapter adapter;
    ArrayList<ProfileInfoModel> list;

    public SmokeF() {
        // Required empty public constructor
    }

    Context context;

    ListView listView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_smoke, container, false);
        context = getContext();
        rv = (RecyclerView) view.findViewById(R.id.rv_id);

        list = new ArrayList<>();
        Functions.addValuesToRv(list, Variables.ARR_LIST_SMOKE);



        listView = (ListView) view.findViewById(R.id.simple_list);

        final ArrayAdapter<String> arrayAdapter

                = new ArrayAdapter<>(context,

                android.R.layout.simple_list_item_single_choice,

                Variables.ARR_LIST_SMOKE);


        listView.setOnItemClickListener((parent, view, position, id) ->  {


                Variables.varSmoking = Variables.ARR_LIST_SMOKE[position];

                int adaptorPositionTotal = EditProfileVpA.segmentAdapter.getCount();
                int adpCurrentItemPosition = EditProfileVpA.vp.getCurrentItem() + 1;

                EditProfileVpA.vp.setCurrentItem(EditProfileVpA.vp.getCurrentItem() + 1);
                EditProfileVpA.fragCounter.setText((EditProfileVpA.vp.getCurrentItem() + 1) + "/ " + EditProfileVpA.segmentAdapter.getCount());
                EditProfileVpA.colorRl.setBackgroundColor(ContextCompat.getColor(getActivity(),R.color.coloraccent));



                Variables.varSmoking = Variables.ARR_LIST_SMOKE[position];

                if (adaptorPositionTotal == adpCurrentItemPosition) {

                    EditProfileVpA.createJsonForAPI(context);
                    getActivity().finish();
                } else {

                    EditProfileVpA.vp.setCurrentItem(EditProfileVpA.vp.getCurrentItem() + 1);
                    EditProfileVpA.fragCounter.setText((EditProfileVpA.vp.getCurrentItem() + 1) + "/ " + EditProfileVpA.segmentAdapter.getCount());
                    EditProfileVpA.colorRl.setBackgroundColor(ContextCompat.getColor(getActivity(),R.color.coloraccent));

                    EditProfileVpA.getFragmentName(adpCurrentItemPosition);

                }
            });


        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        listView.setAdapter(arrayAdapter);


        RelativeLayout.LayoutParams lp1 = (RelativeLayout.LayoutParams) EditProfileVpA.vpRl.getLayoutParams();
        lp1.height = (int) (Variables.height/2);

        EditProfileVpA.vpRl.setLayoutParams(lp1);

        EditProfileVpA.next.setVisibility(View.VISIBLE);


        adapter = new ProfileOptionsAdapter(getContext(), list, new AdapterClickListener() {
            @Override
            public void onItemClick(int postion, Object model, View view) {

            }

            @Override
            public void onLongItemClick(int postion, Object model, View view) {

            }
        });

        rv.setHasFixedSize(false);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));

        rv.setAdapter(adapter);

        return view;
    }






}
