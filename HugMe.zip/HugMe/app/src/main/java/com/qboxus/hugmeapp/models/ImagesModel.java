package com.qboxus.hugmeapp.models;

public class ImagesModel {
    String imgUrl;

    public ImagesModel(String img_url) {
        this.imgUrl = img_url;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}
