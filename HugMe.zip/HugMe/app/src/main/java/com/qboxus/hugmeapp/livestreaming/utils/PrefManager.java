package com.qboxus.hugmeapp.livestreaming.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {
    public static SharedPreferences getPreferences(Context context) {
        return context.getSharedPreferences(com.qboxus.hugmeapp.livestreaming.Constants.PREF_NAME, Context.MODE_PRIVATE);
    }
}
