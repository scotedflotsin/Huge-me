package com.qboxus.hugmeapp.adapters;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.facebook.drawee.view.SimpleDraweeView;
import java.util.List;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.R;

public class ViewPagerAdpNew extends PagerAdapter {

    private Context context;
    private LayoutInflater inflater;

    List<String> listProfileImg;
    public ViewPagerAdpNew(Context context, List<String> listProfileImg) {
        this.context = context;
        this.listProfileImg = listProfileImg;
    }


    @Override
    public int getCount() {
        return listProfileImg.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return (view==(RelativeLayout)o);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(R.layout.item_view_prof,container,false);

        SimpleDraweeView imageView = (SimpleDraweeView) view.findViewById(R.id.view_prof_item_iv_id);

        try{
            imageView.setController(Functions.frescoImageLoad(listProfileImg.get(position),
                    R.drawable.image_placeholder,imageView,false));

        }catch (Exception b){
            Functions.toastMsg(context,"Err " + b.toString());
        }



        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {

        container.removeView((RelativeLayout)object);

    }

}
