package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.interfaces.FragmentCallBack;

public class VerifyMessageBottomSheet extends BottomSheetDialogFragment {
    FragmentCallBack fragmentCallback;
    View view;
    public VerifyMessageBottomSheet(FragmentCallBack fragmentCallback) {
        this.fragmentCallback=fragmentCallback;
    }

 public static   VerifyMessageBottomSheet newInstance(FragmentCallBack fragmentCallback) {
        VerifyMessageBottomSheet fragment = new VerifyMessageBottomSheet(fragmentCallback);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_verify_message_bottom_sheet, container, false);

        view.findViewById(R.id.takePhotoBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle=new Bundle();
                fragmentCallback.onResponce(bundle);
                dismiss();
            }
        });

        view.findViewById(R.id.gotitBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });


        return view;
    }
}