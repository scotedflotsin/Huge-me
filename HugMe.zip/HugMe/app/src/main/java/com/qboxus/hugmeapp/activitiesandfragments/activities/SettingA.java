package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;

import static com.qboxus.hugmeapp.codeclasses.Variables.userGender;

public class SettingA extends AppCompatLocaleActivity implements View.OnClickListener {

    TextView textAppVersion, languageTxt;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        setContentView(R.layout.activity_setting);
        context = SettingA.this;
        textAppVersion = findViewById(R.id.t_app_verson_1);

        Functions.displayFbAd(context);


        try {
            PackageManager manager = getPackageManager();
            PackageInfo info = manager.getPackageInfo(getPackageName(), PackageManager.GET_ACTIVITIES);

            textAppVersion.setText(getResources().getString(R.string.version_txt) + ": " + info.versionName);  // Dynamica Version name


        } catch (Exception b) {
            Functions.toastMsg(context, " " + b.toString());
        }

        languageTxt = findViewById(R.id.language_txt);

        if (Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE).equalsIgnoreCase("en"))
        {
            languageTxt.setText(context.getResources().getString(R.string.english));
        }
        else
        {
            languageTxt.setText(context.getResources().getString(R.string.arabic));
        }


        findViewById(R.id.setting_blocked_id).setOnClickListener(this::onClick);

        findViewById(R.id.setting_about_id).setOnClickListener(this::onClick);

        findViewById(R.id.Chat_Inbox).setOnClickListener(this::onClick);

        findViewById(R.id.setting_back_id).setOnClickListener(this::onClick);

        findViewById(R.id.setting_basic_id).setOnClickListener(this::onClick);

        findViewById(R.id.setting_account_id).setOnClickListener(this::onClick);

        findViewById(R.id.setting_account_pref_id).setOnClickListener(this::onClick);

        findViewById(R.id.language_layout).setOnClickListener(this::onClick);

        findViewById(R.id.setting_help_id).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.setting_blocked_id:
                Intent myIntentGender = new Intent(SettingA.this, BlockedUserA.class);
                startActivity(myIntentGender);
                break;

            case R.id.setting_help_id:
                try {
                    Functions.openWebUrl(this,getString(R.string.privacy_policy),ApiLinks.App_Privacy_Policy_new);
                } catch (Exception vq) {
                    vq.printStackTrace();
                }
                break;

            case R.id.setting_about_id:
                try {
                    Functions.openWebUrl(this,getString(R.string.privacy_policy),ApiLinks.App_Privacy_Policy_new);
                } catch (Exception vq) {
                    vq.printStackTrace();
                }
                break;

            case R.id.Chat_Inbox:
                startActivity(new Intent(SettingA.this, ChatInboxA.class));
                break;

            case R.id.setting_back_id:
                finish();
                break;

            case R.id.setting_basic_id:
                Intent intent = new Intent(SettingA.this, BasicInfoA.class);
                intent.putExtra("gender", "" + userGender);
                startActivity(intent);

                break;

            case R.id.setting_account_id:
                startActivity(new Intent(SettingA.this, AccountA.class));
                break;

            case R.id.setting_account_pref_id:
                try {
                    Functions.openWebUrl(this,getString(R.string.privacy_policy),ApiLinks.App_Privacy_Policy_new);
                }
                catch (Exception vq) {
                    vq.printStackTrace();
                }
                break;


            case R.id.language_layout:

                final CharSequence[] options = {context.getResources().getString(R.string.english), context.getResources().getString(R.string.arabic)};
                Functions.showOptions(context, options, (requestType, response) -> {
                    String lagName="";
                    String lagCode="";

                    if (response.equalsIgnoreCase(""+context.getResources().getString(R.string.english)))
                    {
                        lagName=context.getResources().getString(R.string.english);
                        lagCode="en";
                    }
                    else
                    {
                        lagName=context.getResources().getString(R.string.arabic);
                        lagCode="ar";
                    }

                    SharedPreferences.Editor editor2 = Functions.getSharedPreference(SettingA.this).edit();
                    editor2.putString(Variables.APP_LANGUAGE, lagName);
                    editor2.putString(Variables.APP_LANGUAGE_CODE, lagCode);
                    editor2.commit();

                    Functions.setLocale(Functions.getSharedPreference(SettingA.this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                            , this, MainActivity.class,true);
                });

                break;

            default:
                break;
        }
    }
}
