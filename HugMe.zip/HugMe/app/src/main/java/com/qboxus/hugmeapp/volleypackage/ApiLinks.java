package com.qboxus.hugmeapp.volleypackage;

import com.qboxus.hugmeapp.Constants;

public class ApiLinks {

 public final static String App_Privacy_Policy_new = "https://www.freeprivacypolicy.com/privacy/view/0c27043e8c90c1896c009726e10c7b85";

 public static final String TWILIO_ACCESS_TOKEN_SERVER = "https://pearl-squid-2016.twil.io/sync-token?identity=";


 public static final String loginWithEmail = Constants.API_BASE_URL + "loginWithEmail";

 public static final String changeUserPassword = Constants.API_BASE_URL + "changeUserPassword";

 public static final String signUp = Constants.API_BASE_URL + "signup";

 public static final String signupWithEmail = Constants.API_BASE_URL + "signupWithEmail";

 public static final String getUserInfo = Constants.API_BASE_URL + "getUserInfo";

 public static final String userNearByMe = Constants.API_BASE_URL + "userNearByMe";

 public static final String editProfile = Constants.API_BASE_URL + "edit_profile";

 public static final String showOrHideProfile = Constants.API_BASE_URL + "show_or_hide_profile";

 public static final String deleteImages = Constants.API_BASE_URL + "deleteImages";

 public static final String deleteAccount = Constants.API_BASE_URL + "deleteAccount";

 public static final String uploadImages = Constants.API_BASE_URL + "uploadImages";

 public static final String flatUser = Constants.API_BASE_URL + "flat_user";

 public static final String myMatch = Constants.API_BASE_URL + "myMatch";

 public static final String firstChat = Constants.API_BASE_URL + "firstchat";

 public static final String unMatch = Constants.API_BASE_URL + "unMatch";

 public static final String checkSubscription = Constants.API_BASE_URL + "checkSubscription";

 public static final String purchaseSubscription = Constants.API_BASE_URL + "purchaseSubscription";

 public static final String sendPushNotification = Constants.API_BASE_URL + "sendPushNotification";

 public static final String changeProfilePicture = Constants.API_BASE_URL + "changeProfilePicture";

 public static final String mylikies=Constants.API_BASE_URL +"mylikies";

 public static final String boostProfile=Constants.API_BASE_URL +"boostProfile";

 public static final String sendCustomNotification=Constants.API_BASE_URL +"sendCustomNotification";

 public static final String verifyProfilePhoto = "index.php?p=verifyPhoto";

}
