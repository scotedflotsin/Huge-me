package com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.qboxus.hugmeapp.adapters.LiveUserAdapter;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.PermissionUtils;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.livestreaming.activities.LiveActivity;
import com.qboxus.hugmeapp.livestreaming.activities.StreamingMain_A;
import com.qboxus.hugmeapp.models.LiveUserModel;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.codeclasses.HugMeApplication;
import com.qboxus.hugmeapp.databinding.FragmentLiveUsersTabBinding;
import com.qboxus.hugmeapp.interfaces.AdapterClickListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.agora.rtc.Constants;

/**
 * A simple {@link Fragment} subclass.
 */
public class LiveUsersTabF extends Fragment {

    ArrayList<LiveUserModel> dataList = new ArrayList<>();
    LiveUserAdapter adapter;
    DatabaseReference rootref;
    FragmentLiveUsersTabBinding binding;
    PermissionUtils takePermissionUtils;
    LiveUserModel selectLiveModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_live_users_tab, container, false);
        rootref = FirebaseDatabase.getInstance().getReference();



        binding.recylerview.setLayoutManager(new GridLayoutManager(binding.getRoot().getContext(), 2));

        binding.recylerview.setHasFixedSize(true);

        adapter = new LiveUserAdapter(binding.getRoot().getContext(), dataList, new AdapterClickListener() {
            @Override
            public void onItemClick(View view, int pos, Object object) {
                LiveUserModel itemUpdate = (LiveUserModel) object;
                selectLiveModel=itemUpdate;
                if(Functions.checkLoginUser(getActivity())) {
                    takePermissionUtils=new PermissionUtils(getActivity(),mJoinStreamPermissionResult);
                    if (takePermissionUtils.isCameraRecordingPermissionGranted())
                    {
                        joinLiveSteam();
                    }
                    else
                    {
                        takePermissionUtils.showCameraRecordingPermissionDailog(getString(R.string.we_need_camera_and_recording_permission_for_live_streaming));
                    }

                }
            }
        });

        binding.recylerview.setAdapter(adapter);


        getData();


        binding.goLiveLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePermissionUtils=new PermissionUtils(getActivity(),mGoLivePermissionResult);
                if (takePermissionUtils.isCameraRecordingPermissionGranted())
                {
                    goLiveStream();
                }
                else
                {
                    takePermissionUtils.showCameraRecordingPermissionDailog(getString(R.string.we_need_camera_and_recording_permission_for_live_streaming));
                }
            }
        });

        return binding.getRoot();
    }

    private void joinLiveSteam() {


        final Intent intent = new Intent();
        intent.putExtra("user_id", selectLiveModel.getUser_id());
        intent.putExtra("user_name",  selectLiveModel.getUser_name());
        intent.putExtra("user_picture", selectLiveModel.getUser_picture());
        intent.putExtra("user_role", Constants.CLIENT_ROLE_AUDIENCE);
        intent.putExtra(com.qboxus.hugmeapp.livestreaming.Constants.KEY_CLIENT_ROLE, Constants.CLIENT_ROLE_AUDIENCE);
        intent.setClass(binding.getRoot().getContext(), LiveActivity.class);
        HugMeApplication ticTic = (HugMeApplication)getActivity().getApplication();
        ticTic.engineConfig().setChannelName(selectLiveModel.getUser_id());
        startActivity(intent);
    }


    // get the list of all live user from the firebase
    ChildEventListener valueEventListener;
    public void getData() {

        valueEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                LiveUserModel model = dataSnapshot.getValue(LiveUserModel.class);
                dataList.add(model);
                adapter.notifyDataSetChanged();
                binding.noDataFound.setVisibility(View.GONE);

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                try {


                    LiveUserModel model = dataSnapshot.getValue(LiveUserModel.class);

                    for (int i = 0; i < dataList.size(); i++) {
                        if (model.getUser_id().equals(dataList.get(i).getUser_id())) {
                            dataList.remove(i);
                        }
                    }
                    adapter.notifyDataSetChanged();

                    if (dataList.isEmpty()) {
                        binding.noDataFound.setVisibility(View.VISIBLE);
                    }

                }catch (Exception e){}

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };


        rootref.child("LiveUsers").addChildEventListener(valueEventListener);
    }


    @Override
    public void onDestroy() {
        if (mJoinStreamPermissionResult!=null)
        {
            mJoinStreamPermissionResult.unregister();
        }
        if (mGoLivePermissionResult!=null)
        {
            mGoLivePermissionResult.unregister();
        }
        if (rootref != null && valueEventListener != null)
            rootref.child("LiveUsers").removeEventListener(valueEventListener);
        super.onDestroy();

    }



    private ActivityResultLauncher<String[]> mJoinStreamPermissionResult = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onActivityResult(Map<String, Boolean> result) {

                    boolean allPermissionClear=true;
                    List<String> blockPermissionCheck=new ArrayList<>();
                    for (String key : result.keySet())
                    {
                        if (!(result.get(key)))
                        {
                            allPermissionClear=false;
                            blockPermissionCheck.add(Functions.getPermissionStatus(getActivity(),key));
                        }
                    }
                    if (blockPermissionCheck.contains("blocked"))
                    {
                        Functions.showPermissionSetting(binding.getRoot().getContext(),getString(R.string.we_need_camera_and_recording_permission_for_live_streaming));
                    }
                    else
                    if (allPermissionClear)
                    {
                        joinLiveSteam();
                    }

                }
            });


    private ActivityResultLauncher<String[]> mGoLivePermissionResult = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onActivityResult(Map<String, Boolean> result) {

                    boolean allPermissionClear=true;
                    List<String> blockPermissionCheck=new ArrayList<>();
                    for (String key : result.keySet())
                    {
                        if (!(result.get(key)))
                        {
                            allPermissionClear=false;
                            blockPermissionCheck.add(Functions.getPermissionStatus(getActivity(),key));
                        }
                    }
                    if (blockPermissionCheck.contains("blocked"))
                    {
                        Functions.showPermissionSetting(binding.getRoot().getContext(),getString(R.string.we_need_camera_and_recording_permission_for_live_streaming));
                    }
                    else
                    if (allPermissionClear)
                    {
                        goLiveStream();
                    }

                }
            });

    private void goLiveStream() {
        String user_id = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.FB_ID, "");
        String user_name = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.F_NAME, "") + " " +
                Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.L_NAME, "");
        String user_image = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.IMAGE1, "");

        Intent intent = new Intent(binding.getRoot().getContext(), StreamingMain_A.class);
        intent.putExtra("user_id", user_id);
        intent.putExtra("user_name", user_name);
        intent.putExtra("user_picture", user_image);
        intent.putExtra("user_role", io.agora.rtc.Constants.CLIENT_ROLE_BROADCASTER);
        startActivity(intent);
    }

}
