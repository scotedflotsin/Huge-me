package com.qboxus.hugmeapp.activitiesandfragments.activities;

import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.klinker.android.link_builder.Link;
import com.klinker.android.link_builder.LinkBuilder;
import com.klinker.android.link_builder.TouchableMovementMethod;
import com.qboxus.hugmeapp.Constants;
import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.volleypackage.CallBack;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class EmailLoginA extends AppCompatLocaleActivity{

    EditText edtEmail,edtPassword;

    ViewFlipper viewFlipper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        setContentView(R.layout.activity_email_login);
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword=findViewById(R.id.edtPassword);

        viewFlipper = findViewById(R.id.viewfillper);


        Functions.showKeyboard(EmailLoginA.this);

        SetupScreenData();
    }

    TextView login_terms_condition_txt;
    List<Link> links = new ArrayList<>();
    CheckBox chBox;
    private void SetupScreenData() {
        chBox = findViewById(R.id.chBox);
        login_terms_condition_txt =findViewById(R.id.login_terms_condition_txt);

        Link link = new Link(getString(R.string.terms_of_use));
        link.setTextColor(ContextCompat.getColor(this,R.color.black));
        link.setTextColorOfHighlightedLink(ContextCompat.getColor(this,R.color.colorPrimary));
        link.setUnderlined(true);
        link.setBold(false);
        link.setHighlightAlpha(.20f);
        link.setOnClickListener(new Link.OnClickListener() {
            @Override
            public void onClick(String clickedText) {
                openWebUrl(getString(R.string.terms_of_use),ApiLinks.App_Privacy_Policy_new);
            }
        });

        Link link2 = new Link(getString(R.string.privacy_policy));
        link2.setTextColor(ContextCompat.getColor(this,R.color.black));
        link2.setTextColorOfHighlightedLink(ContextCompat.getColor(this,R.color.colorPrimary));
        link2.setUnderlined(true);
        link2.setBold(false);
        link2.setHighlightAlpha(.20f);
        link2.setOnClickListener(new Link.OnClickListener() {
            @Override
            public void onClick(String clickedText) {
                openWebUrl(getString(R.string.privacy_policy),ApiLinks.App_Privacy_Policy_new);
            }
        });
        links.add(link);
        links.add(link2);
        CharSequence sequence = LinkBuilder.from(this, login_terms_condition_txt.getText().toString())
                .addLinks(links)
                .build();
        login_terms_condition_txt.setText(sequence);
        login_terms_condition_txt.setMovementMethod(TouchableMovementMethod.getInstance());
    }



    public void openWebUrl(String title, String url) {
        Intent intent=new Intent(this, WebviewA.class);
        intent.putExtra("url", url);
        intent.putExtra("title", title);
        startActivity(intent);
        overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
    }


    public void nextbtn(View view) {
        if (TextUtils.isEmpty(edtEmail.getText().toString())) {
            edtEmail.setError("" + getResources().getString(R.string.cant_empty));
            edtEmail.requestFocus();
            return;
        }
        else if (!(Functions.isValidEmail(edtEmail.getText().toString()))) {
            edtEmail.setError("" + getResources().getString(R.string.invalid_email));
            edtEmail.requestFocus();
            return;
        }
       else if (TextUtils.isEmpty(edtPassword.getText().toString())) {
            edtPassword.setError("" + getResources().getString(R.string.cant_empty));
            edtPassword.requestFocus();
            return;
        }

       else if(!chBox.isChecked()){
           Toast.makeText(this,"Please accept our 'Terms of use' & 'Privacy Policy'",Toast.LENGTH_LONG).show();
            return;
        }

        sendEmailVerification();

    }

    private void sendEmailVerification() {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("email", edtEmail.getText().toString());
            parameters.put("password", edtPassword.getText().toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
        Functions.showLoader(this, false, false);
        ApiRequest.callApi(
                this,
                ApiLinks.loginWithEmail,
                parameters,
                new CallBack() {
                    @RequiresApi(api = Build.VERSION_CODES.M)
                    @Override
                    public void getResponse(String requestType, String resp) {
                        Functions.cancelLoader();
                        try {
                            JSONObject response = new JSONObject(resp);


                            if (response.getString("code").equals("200")) {

                                JSONArray msgObj = response.getJSONArray("msg");
                                JSONObject userInfoObj = msgObj.getJSONObject(0);

                                UserModel userdetailModel= ParseData.parseUserModel(userInfoObj);
                                Functions.storeUserLoginDataIntoDb(EmailLoginA.this,userdetailModel);


                                Functions.getSharedPreference(EmailLoginA.this).edit().putString(Variables.EMAIL,userInfoObj.optString("email")).commit();
                                Functions.getSharedPreference(EmailLoginA.this).edit().putString(Variables.FB_ID,""+userInfoObj.optString("fb_id")).commit();
                                Functions.getSharedPreference(EmailLoginA.this).edit().putString(Variables.SOCIAL_INFO_JSON,"").commit();

                                enableLocation();


                            } else {
                                JSONArray msgObj = response.getJSONArray("msg");
                                JSONObject errorResponce = msgObj.getJSONObject(0);
                                if (errorResponce.optString("response").equals("email not exist"))
                                {
                                    Intent intent = new Intent(EmailLoginA.this, GetUserInfoA.class);
                                    intent.putExtra("isEmail",true);
                                    intent.putExtra("email", ""+edtEmail.getText().toString());
                                    intent.putExtra("password", ""+edtPassword.getText().toString());
                                    startActivity(intent);
                                    overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
                                    finish();
                                }
                                else
                                {
                                    Toast.makeText(EmailLoginA.this, getString(R.string.incorrect_login_detail), Toast.LENGTH_SHORT).show();
                                }


                            }

                        } catch (Exception b) {
                            Functions.toastMsg(EmailLoginA.this, "" + b.toString());
                        }

                    }
                }
        );


    }




    public void goback1(View view) {
        finish();
    }

    public void goback(View view) {
        viewFlipper.setInAnimation(EmailLoginA.this, R.anim.in_from_left);
        viewFlipper.setOutAnimation(EmailLoginA.this, R.anim.out_to_right);
        viewFlipper.setDisplayedChild(0);
    }


    private void enableLocation() {
        // will move the user for enable location screen
        startActivity(new Intent(this, EnableLocationA.class));
        overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
        finishAffinity();

    }



}
