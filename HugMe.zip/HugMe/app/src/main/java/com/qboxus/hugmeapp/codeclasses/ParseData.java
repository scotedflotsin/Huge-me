package com.qboxus.hugmeapp.codeclasses;

import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.models.UserModel;

import org.json.JSONObject;

public class ParseData {

    public static UserModel parseUserModel(JSONObject resObj)
    {
        UserModel item=new UserModel();
        item.setFbId(resObj.optString("fb_id"));
        item.setAboutMe(resObj.optString("about_me"));
        item.setJobTitle(resObj.optString("job_title"));
        item.setGender(resObj.optString("gender"));
        item.setBirthday(resObj.optString("birthday"));
        item.setAge(resObj.optInt("age",0));
        item.setCompany(resObj.optString("company"));
        item.setSchool(resObj.optString("school"));
        item.setFirstName(resObj.optString("first_name"));
        item.setLastName(resObj.optString("last_name"));
        item.setLiving(resObj.optString("living"));
        item.setChildren(resObj.optString("children"));
        item.setSmoking(resObj.optString("smoking"));
        item.setDrinking(resObj.optString("drinking"));
        item.setRelationship(resObj.optString("relationship"));
        item.setSexuality(resObj.optString("sexuality"));
        item.setImage1(resObj.optString("image1"));
        item.setImage2(resObj.optString("image2"));
        item.setImage3(resObj.optString("image3"));
        item.setImage4(resObj.optString("image4"));
        item.setImage5(resObj.optString("image5"));
        item.setImage6(resObj.optString("image6"));

        item.setVerified(resObj.optString("verified","0"));
        item.Swipe = resObj.optString("swipe");
        item.block = resObj.optString("block","0");
        item.distance = resObj.optString("distance");

        return item;
    }

}
