package com.qboxus.hugmeapp.codeclasses;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.media.MediaScannerConnection;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.qboxus.hugmeapp.Constants;
import com.qboxus.hugmeapp.activitiesandfragments.SplashA;
import com.qboxus.hugmeapp.activitiesandfragments.activities.WebviewA;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs.SwipeTabF;
import com.qboxus.hugmeapp.interfaces.InternetCheckCallback;
import com.qboxus.hugmeapp.models.BlockUserModel;
import com.qboxus.hugmeapp.models.ChatModel;
import com.qboxus.hugmeapp.models.ProfileInfoModel;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.volleypackage.CallBack;
import com.qboxus.hugmeapp.activitiesandfragments.activities.LoginA;
import com.qboxus.hugmeapp.interfaces.FragmentCallBack;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static android.content.Context.CONNECTIVITY_SERVICE;
import static android.content.Context.DOWNLOAD_SERVICE;
import static com.qboxus.hugmeapp.codeclasses.Variables.per1;

public class Functions {

    public static SharedPreferences getSharedPreference(Context context) {
        if (Variables.sharedPreferences != null)
            return Variables.sharedPreferences;
        else {
            Variables.sharedPreferences = context.getSharedPreferences(Variables.PREF_NAME, Context.MODE_PRIVATE);
            return Variables.sharedPreferences;
        }

    }

    // print any kind of log
    public static void printLog(String title, String text) {
        if (!Constants.IS_SECURE_INFO) {
            if (title != null && text != null)
                Log.d(title, text);
        }

    }

    // format the count value
    public static String getSuffix(String value) {
        try {

            if (value != null && (!value.equals("") && !value.equalsIgnoreCase("null"))) {
                long count = Long.parseLong(value);
                if (count < 1000)
                    return "" + count;
                int exp = (int) (Math.log(count) / Math.log(1000));
                return String.format(Locale.ENGLISH,"%.1f %c",
                        count / Math.pow(1000, exp),
                        "kMBTPE".charAt(exp - 1));
            } else {
                return "0";
            }
        } catch (Exception e) {
            return value;
        }

    }


    public static void logDMsg(String msg) {
        printLog(Constants.tag,msg);
    }

    public static void toastMsg(Context context, String msg) {
        Toast.makeText(context, "" + msg, Toast.LENGTH_SHORT).show();
    }


    public static String  getAppFolder(Context context) {
        return context.getExternalFilesDir(null).getPath() + "/";
    }
    //////////Show KEYBOARD
    public static void showKeyboard(Activity activity) {
        View view = activity.findViewById(android.R.id.content);
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
        }
    }


    // check email validation
    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }


    public static void openWebUrl(Activity activity,String title, String url) {
        Intent intent=new Intent(activity, WebviewA.class);
        intent.putExtra("url", url);
        intent.putExtra("title", title);
        activity.startActivity(intent);
        activity.overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
    }


    public static void alertDialogue(final Context context, String title, String msg) {

        AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        builder1.setTitle("" + title);
        builder1.setMessage(msg);
        builder1.setCancelable(true);

        builder1.setPositiveButton("Ok", (dialog, id) -> dialog.cancel());


        AlertDialog alert11 = builder1.create();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            alert11.show();

        } else {
            alert11.show();
        }


    }

    // this is the delete message diloge which will show after long press in chat message
    public static void showOptions(Context context, CharSequence[] options, final CallBack callback) {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(context, R.style.AlertDialogCustom);

        builder.setTitle(null);

        builder.setItems(options, (dialog, item) -> callback.getResponse("resp", "" + options[item]));

        builder.show();

    }


    public static void displayFbAd(final Context context) {

        final InterstitialAd interstitialAd;
        interstitialAd = new InterstitialAd(context, context.getString(R.string.facebook_interstitialAd_id));
        int num_click_post = Functions.getSharedPreference(context).getInt(Variables.ADS_CLICK,0);

        interstitialAd.loadAd(new InterstitialAd.InterstitialLoadAdConfig() {
        });

        InterstitialAd.InterstitialLoadAdConfig config= interstitialAd.buildLoadAdConfig().withAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
                Functions.logDMsg( "Interstitial ad displayed.");
                Functions.getSharedPreference(context).edit().putInt(Variables.ADS_CLICK,0).commit();
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Functions.logDMsg( "Interstitial ad dismissed.");
                Functions.getSharedPreference(context).edit().putInt(Variables.ADS_CLICK,0).commit();

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Functions.logDMsg( "Interstitial ad failed to load: " + adError.getErrorMessage() + " Code " + adError.getErrorCode());
            }

            @Override
            public void onAdLoaded(Ad ad) {
                interstitialAd.show();
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // Ad impression logged callback

            }
        }).build();

        interstitialAd.loadAd(config);

        if (num_click_post == Variables.varNumClickToShowAds) {
            interstitialAd.loadAd(config);
        }

    }

    public static int countNumClick(Context context) {

        int numClickPost = Functions.getSharedPreference(context).getInt(Variables.ADS_CLICK,0);

        Functions.getSharedPreference(context).edit().putInt(Variables.ADS_CLICK,numClickPost + 1).commit();

        if (numClickPost >= Variables.varNumClickToShowAds) {
            numClickPost = 1;

            Functions.getSharedPreference(context).edit().putInt(Variables.ADS_CLICK,numClickPost).commit();
        }

        return numClickPost;

    }

    public static int getAge(String dobString) {

        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            date = sdf.parse(dobString);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (date == null) return 0;

        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.setTime(date);

        int year = dob.get(Calendar.YEAR);
        int month = dob.get(Calendar.MONTH);
        int day = dob.get(Calendar.DAY_OF_MONTH);

        dob.set(year, month + 1, day);

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }


        return age;
    }

    public static Drawable getRoundRect() {
        RoundRectShape rectShape = new RoundRectShape(new float[]{
                25, 25, 25, 25,
                0, 25, 25, 25
        }, null, null);
        ShapeDrawable shapeDrawable = new ShapeDrawable(rectShape);

        shapeDrawable.getPaint().setStyle(Paint.Style.FILL);
        shapeDrawable.getPaint().setAntiAlias(true);
        shapeDrawable.getPaint().setFlags(Paint.ANTI_ALIAS_FLAG);
        return shapeDrawable;
    }

    public static String parseDateToddMMyyyy(String time) {

        String inputPattern = "dd-MM-yyyy HH:mm:ss";
        String outputPattern = "yyyy-MM-dd HH:mm:ss";

        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern);

        Date date = null;
        String str = null;

        try {
            date = inputFormat.parse(time);
            str = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return str;
    }

    public static String getTimeAgoOrg(String dateTime) {

        TimeAgo2 timeAgo2 = new TimeAgo2();
        String myFinalValue = timeAgo2.covertTimeToText(dateTime);

        return myFinalValue;

    }

    public static long downloadDataForChat(Context context, ChatModel item) {

        long downloadReference;
        DownloadManager downloadManager = (DownloadManager) context.getSystemService(DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(item.getPic_url()));

        request.setTitle(item.getSender_name());

        if (item.getType().equals("video")) {
            request.setDescription("Downloading Video");
            request.setDestinationUri(Uri.fromFile(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + "/Hugme/" + item.getChat_id() + ".mp4")));
        } else if (item.getType().equals("audio")) {
            request.setDescription("Downloading Audio");
            request.setDestinationUri(Uri.fromFile(new File(Environment.getExternalStorageDirectory() + "/Hugme/" + item.getChat_id() + ".mp3")));
        } else if (item.getType().equals("pdf")) {

            request.setDescription("Downloading Pdf Document");
            request.setDestinationUri(Uri.fromFile(new File(Environment.getExternalStorageDirectory() + "/Hugme/" + item.getChat_id() + ".pdf")));

        }

        downloadReference = downloadManager.enqueue(request);

        return downloadReference;
    }

    public static boolean isMyServiceRunning(Context context, Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                Log.i("isMyServiceRunning?", true + "");
                return true;
            }
        }
        Log.i("isMyServiceRunning?", false + "");
        return false;
    }

    public static void deleteAccount(final Context context, String fbId) {
        Functions.showLoader(context, false, false);

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", fbId);

        } catch (Exception e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(context,
                "" + ApiLinks.deleteAccount, parameters, (requestType, response) -> {
                    Functions.cancelLoader();
                    try {
                        Functions.logoutUser(context);
                        JSONObject response1 = new JSONObject(response);
                        JSONArray msgArr = response1.getJSONArray("msg");
                        Functions.toastMsg(context, "" + msgArr.getJSONObject(0).getString("response"));

                    } catch (Exception b) {
                        b.printStackTrace();
                    }


                }


        );


    }

    public static void deleteImage(final Context context, String imageLink, final String fb_id) {
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("image_link", imageLink);
            parameters.put("fb_id", fb_id);


        } catch (Exception e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(context, "" + ApiLinks.deleteImages, parameters, (requestType, response) -> {
                    try {
                        JSONObject response1 = new JSONObject(response);
                        JSONArray msgArr = response1.getJSONArray("msg");
                        Functions.toastMsg(context, "" + msgArr.getJSONObject(0).getString("response"));

                        getUserInfo(fb_id, context);

                    } catch (Exception b) {
                        b.printStackTrace();
                    }


                }


        );


    }

    public static void reportUser(final Context context, String fbId) {

        Functions.showLoader(context, false, false);

        String myId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", fbId);
            parameters.put("my_id", myId);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(context,
                "" + ApiLinks.flatUser, parameters, (requestType, response) -> {
                    Functions.cancelLoader();

                    try {
                        JSONObject response1 = new JSONObject(response);
                        JSONArray msgArr = response1.getJSONArray("msg");
                        Functions.toastMsg(context, "" + msgArr.getJSONObject(0).getString("response"));

                    } catch (Exception b) {
                        b.printStackTrace();
                    }


                }


        );

    }


    public static void blockUser(final Context context, String fbId, String firstName, String imgURl) {

        Functions.showLoader(context, false, false);

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference = databaseReference.child("BlockUser").child(Variables.userId);
        BlockUserModel inboxModel = new BlockUserModel();
        inboxModel.setImgUrl(imgURl);
        inboxModel.setId(fbId);
        inboxModel.setName(firstName);
        databaseReference.child(fbId).setValue(inboxModel).addOnCompleteListener(task -> {
            Functions.cancelLoader();
            if (task.isComplete()) {
                Functions.toastMsg(context, "User blocked");
            }
        });

    }

    public static void unblockUser(final Context context, String fbId) {

        Functions.showLoader(context, false, false);

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference = databaseReference.child("BlockUser").child(Variables.userId).child(fbId);
        databaseReference.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Functions.cancelLoader();
                if (task.isSuccessful()) {
                    Functions.toastMsg(context, "User unBlocked");
                }

            }
        });

    }


    public static void getUserIsBlockOrNot(String receiverid, final CallBack callback) {
        ValueEventListener eventListener;
        Query inboxQuery;
        DatabaseReference rootref = FirebaseDatabase.getInstance().getReference();

        inboxQuery = rootref.child("BlockUser").child(Variables.userId).child(receiverid);
        inboxQuery.keepSynced(true);

        eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) {
                    callback.getResponse("resp", "0");

                } else {
                    callback.getResponse("resp", "1");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };

        inboxQuery.addValueEventListener(eventListener);

    }


    public static void apiFirstchat(final Context context, String fbId, String effectedId) {

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", fbId);
            parameters.put("effected_id", effectedId);


        } catch (Exception e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(
                context,
                "" + ApiLinks.firstChat,
                parameters,
                new CallBack() {
                    @Override
                    public void getResponse(String requestType, String response) {


                    }
                }


        );


    }



    public static void addValuesToRv(ArrayList<ProfileInfoModel> list, String[] arrVal) {

        for (int i = 0; i < arrVal.length; i++) {
            list.add(new ProfileInfoModel("" + arrVal[i]));
        } // End For Loop


    }

    public static Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public static void getUserInfo(String userId, final Context context) {
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", userId);

        } catch (Exception e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(
                context,
                ApiLinks.getUserInfo,
                parameters,
                new CallBack() {
                    @Override
                    public void getResponse(String requestType, String resp) {
                        try {


                            JSONObject response = new JSONObject(resp);


                            if (response.getString("code").equals("200")) {


                                JSONArray msgObj = response.getJSONArray("msg");
                                JSONObject userInfoObj = msgObj.getJSONObject(0);

                                UserModel userdetailModel= ParseData.parseUserModel(userInfoObj);
                                Functions.storeUserLoginDataIntoDb(context,userdetailModel);

                            }

                        } catch (Exception b) {
                            b.printStackTrace();
                        }


                    }
                }
        );

    }

    public static void showOrHideProfile(String userId, String status, final Context context) {

        Functions.showLoader(context, false, false);
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", userId);
            parameters.put("status", status);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(
                context,
                ApiLinks.showOrHideProfile,
                parameters,
                new CallBack() {
                    @Override
                    public void getResponse(String requestType, String resp) {
                        try {


                            Functions.cancelLoader();

                            JSONObject response = new JSONObject(resp);


                            if (response.getString("code").equals("200")) {

                                JSONArray msgArr = response.getJSONArray("msg");
                                Functions.getSharedPreference(context).edit().putString(Variables.PROFILE_HIDE,status).commit();
                                Functions.toastMsg(context, "" + msgArr.getJSONObject(0).getString("response"));


                            }

                        } catch (Exception b) {
                            b.printStackTrace();
                        }


                    }
                }
        );

    }

    public static void sendPushNotification(final Context context, final String receverid, final String message, final String noti_type) {


        try {


            Query inboxQuery;
            DatabaseReference rootref = FirebaseDatabase.getInstance().getReference();


            inboxQuery = rootref.child("Users").child(receverid);
            inboxQuery.keepSynced(true);


            inboxQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if (dataSnapshot.exists()) {
                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            SwipeTabF.tokenOtherUser = ds.getValue().toString();

                            JSONObject notimap = new JSONObject();
                            try {
                                notimap.put("title", Functions.getSharedPreference(context).getString(Variables.F_NAME, ""));
                                notimap.put("message", message);
                                notimap.put("icon", Functions.getSharedPreference(context).getString(Variables.IMAGE1, ""));
                                notimap.put("tokon", SwipeTabF.tokenOtherUser);
                                notimap.put("senderid", "" + Functions.getSharedPreference(context).getString(Variables.FB_ID, ""));
                                notimap.put("receiverid", receverid);
                                notimap.put("action_type", "" + noti_type);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            ApiRequest.callApi(
                                    context,
                                    ApiLinks.sendPushNotification,
                                    notimap,
                                    new CallBack() {
                                        @Override
                                        public void getResponse(String requestType, String resp) {
                                            try {

                                                Functions.cancelLoader();

                                            } catch (Exception b) {
                                                b.printStackTrace();
                                            }


                                        }
                                    }
                            );

                        }

                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


            if (noti_type.equals("message")) {


                JSONObject notimap = new JSONObject();
                try {
                    notimap.put("title", Functions.getSharedPreference(context).getString(Variables.F_NAME, ""));
                    notimap.put("message", message);
                    notimap.put("icon", Functions.getSharedPreference(context).getString(Variables.IMAGE1, ""));
                    notimap.put("tokon", SwipeTabF.tokenOtherUser);
                    notimap.put("senderid", Functions.getSharedPreference(context).getString(Variables.FB_ID, ""));
                    notimap.put("receiverid", receverid);
                    notimap.put("action_type", "" + noti_type);
                } catch (Exception e) {
                    e.printStackTrace();
                }


                ApiRequest.callApi(
                        context,
                        ApiLinks.sendPushNotification,
                        notimap,
                        new CallBack() {
                            @Override
                            public void getResponse(String requestType, String resp) {
                                try {


                                    Functions.cancelLoader();

                                } catch (Exception b) {
                                    b.printStackTrace();
                                }


                            }
                        }
                );

            }

        }catch (Exception e){}
    }


    public static void opendatePicker(Context context, final EditText editText) {
        final SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());

        String dateString = editText.getText().toString();
        if (dateString.equals("")) {
            dateString = "01/01/2000";
        }
        String[] parts = dateString.split("/");

        DatePickerDialog mdiDialog = new DatePickerDialog(context, R.style.datepicker_style, (view, year, monthOfYear, dayOfMonth) -> {
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(0);
            cal.set(year, monthOfYear, dayOfMonth, 0, 0, 0);
            Date chosenDate = cal.getTime();
            editText.setText(format.format(chosenDate));

        }, Integer.parseInt(parts[2]), Integer.parseInt(parts[0]) - 1, Integer.parseInt(parts[1]));
        mdiDialog.show();
    }

    public static String getRandomString(int n) {
        String alphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "0123456789"
                + "abcdefghijklmnopqrstuvxyz";

        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            int index
                    = (int) (alphaNumericString.length()
                    * Math.random());

            sb.append(alphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }

    public static String convertSeconds(int seconds) {
        int h = seconds / 3600;
        int m = (seconds % 3600) / 60;
        int s = seconds % 60;
        String sh = (h > 0 ? String.valueOf(h) + " " + "h" : "");
        String sm = (m < 10 && m > 0 && h > 0 ? "0" : "") + (m > 0 ? (h > 0 && s == 0 ? String.valueOf(m) : String.valueOf(m) + " " + "min") : "");
        String ss = (s == 0 && (h > 0 || m > 0) ? "" : (s < 10 && (h > 0 || m > 0) ? "0" : "") + String.valueOf(s) + " " + "sec");
        return sh + (h > 0 ? " " : "") + sm + (m > 0 ? " " : "") + ss;
    }

    public static void showAlert(Context context, String title, String description, CallBack callBack) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title);
        builder.setMessage(description);
        builder.setPositiveButton("OK", (dialog, id) -> {
            if (callBack != null)
                callBack.getResponse("alert", "OK");
        });
        builder.create();
        builder.show();

    }



    public static Boolean isConnectedToInternet(Context context) {
        try {

            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network nw = connectivityManager.getActiveNetwork();
                if (nw == null) return false;
                NetworkCapabilities actNw = connectivityManager.getNetworkCapabilities(nw);
                return actNw != null && (actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) || actNw.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH));
            } else {
                NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
                if (networkInfo != null && networkInfo.isConnected()) {
                    return true;
                } else {
                    return false;
                }
            }
        } catch (Exception e) {
            Functions.logDMsg( e.getMessage());
            return false;
        }
    }


    //check rational permission status
    public static String getPermissionStatus(Activity activity, String androidPermissionName) {
        if(ContextCompat.checkSelfPermission(activity, androidPermissionName) != PackageManager.PERMISSION_GRANTED) {
            if(!ActivityCompat.shouldShowRequestPermissionRationale(activity, androidPermissionName)){
                return "blocked";
            }
            return "denied";
        }
        return "granted";
    }

    //show permission setting screen
    public static void showPermissionSetting(Context context,String message) {
        showDoubleButtonAlert(context, context.getString(R.string.permission_alert),message,
                context.getString(R.string.cancel), context.getString(R.string.settings), false, new FragmentCallBack() {
                    @Override
                    public void onResponce(Bundle bundle) {
                        if (bundle.getBoolean("isShow",false))
                        {
                            Intent intent = new Intent();
                            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package",context.getPackageName(), null);
                            intent.setData(uri);
                            context.startActivity(intent);
                        }
                    }
                });
    }


    public static void showDoubleButtonAlert(Context context, String title, String message, String negTitle, String posTitle,boolean isCancelable, FragmentCallBack callBack)
    {
        final Dialog dialog = new Dialog(context);
        dialog.setCancelable(isCancelable);
        dialog.setContentView(R.layout.show_double_button_new_popup_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        final TextView tvtitle,tvMessage,tvPositive,tvNegative;
        tvtitle=dialog.findViewById(R.id.tvtitle);
        tvMessage=dialog.findViewById(R.id.tvMessage);
        tvNegative=dialog.findViewById(R.id.tvNegative);
        tvPositive=dialog.findViewById(R.id.tvPositive);


        tvtitle.setText(title);
        tvMessage.setText(message);
        tvNegative.setText(negTitle);
        tvPositive.setText(posTitle);

        tvNegative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                Bundle bundle=new Bundle();
                bundle.putBoolean("isShow",false);
                callBack.onResponce(bundle);
            }
        });
        tvPositive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                Bundle bundle=new Bundle();
                bundle.putBoolean("isShow",true);
                callBack.onResponce(bundle);
            }
        });
        dialog.show();
    }



    // use for image loader and return controller for image load
    public static DraweeController frescoImageLoad(Uri resourceUri,int resource,SimpleDraweeView simpleDrawee, boolean isGif)
    {
        ImageRequest request = ImageRequestBuilder.newBuilderWithSource(resourceUri)
                .build();
        DraweeController controller;
        simpleDrawee.getHierarchy().setPlaceholderImage(resource);
        simpleDrawee.getHierarchy().setFailureImage(resource);
        if (isGif)
        {
            controller = Fresco.newDraweeControllerBuilder()
                    .setImageRequest(request)
                    .setOldController(simpleDrawee.getController())
                    .setAutoPlayAnimations(true)
                    .build();
        }
        else
        {
            controller = Fresco.newDraweeControllerBuilder()
                    .setImageRequest(request)
                    .setOldController(simpleDrawee.getController())
                    .build();
        }



        return controller;
    }

    // use for image loader and return controller for image load
    public static DraweeController frescoImageLoad(String url,int resource, SimpleDraweeView simpleDrawee, boolean isGif)
    {

        if (url==null || !url.contains(Variables.http)) {
            url = Constants.API_BASE_URL + url;
        }

        ImageRequest request = ImageRequestBuilder.newBuilderWithSource(Uri.parse(url))
                .build();
        DraweeController controller;
        simpleDrawee.getHierarchy().setPlaceholderImage(resource);
        simpleDrawee.getHierarchy().setFailureImage(resource);
        if (isGif)
        {
            controller = Fresco.newDraweeControllerBuilder()
                    .setImageRequest(request)
                    .setOldController(simpleDrawee.getController())
                    .setAutoPlayAnimations(true)
                    .build();
        }
        else
        {
            controller = Fresco.newDraweeControllerBuilder()
                    .setImageRequest(request)
                    .setOldController(simpleDrawee.getController())
                    .build();
        }



        return controller;
    }


    public static File getBitmapToUri(Context inContext, Bitmap bitmap,String fileName) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        File file = new File(Functions.getAppFolder(inContext) + fileName);
        try {
            FileOutputStream fo = new FileOutputStream(file);
            fo.write(bytes.toByteArray());
            fo.flush();
            fo.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (file.exists())
        {
            return file;
        }
        else
        {
            return null;
        }
    }


    // initialize the loader dialog and show
    public static Dialog dialog;

    public static void showLoader(Context context, boolean outside_touch, boolean cancleable) {
        try {

            if (dialog != null)
            {
                cancelLoader();
                dialog=null;
            }
            {
                dialog = new Dialog(context);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.item_dialog_loading_view);
                dialog.getWindow().setBackgroundDrawable(ContextCompat.getDrawable(context,R.drawable.d_round_white_background));

                if (!outside_touch)
                    dialog.setCanceledOnTouchOutside(false);

                if (!cancleable)
                    dialog.setCancelable(false);

                dialog.show();
            }

        }
        catch (Exception e)
        {
            Functions.logDMsg("Exception : "+e);
        }
    }

    public static void cancelLoader() {
        try {
            if (dialog != null || dialog.isShowing()) {
                dialog.cancel();
            }
        }catch (Exception e){
            Functions.logDMsg("Exception : "+e);
        }
    }

    public static void createNoMediaFile(Context context) {

        InputStream in = null;
        OutputStream out = null;

        try {

            //create output directory if it doesn't exist
            String path=getAppFolder(context)+"videoCache";
            Functions.logDMsg("path: "+path);
            File dir = new File(path);
            Functions.logDMsg("getAbsolutePath: "+dir.getAbsolutePath());
            File newFile = new File(dir, ".nomedia");
            if (!dir.exists()) {
                dir.mkdirs();
            }
            if (!newFile.exists()) {
                newFile.createNewFile();

                MediaScannerConnection.scanFile(context,
                        new String[]{path}, null,
                        new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                                Log.i("ExternalStorage", "Scanned " + path + ":");
                                Log.i("ExternalStorage", "-> uri=" + uri);
                            }
                        });
            }

        } catch (Exception e) {
            Functions.logDMsg( ""+e);
        }

    }


    //    app language change
    public static void setLocale(String lang, Activity context, Class<?> className,boolean isRefresh) {

        String[] languageArray=context.getResources().getStringArray(R.array.app_language_code);
        List<String> languageCode = Arrays.asList(languageArray);
        if (languageCode.contains(lang)) {
            Locale myLocale = new Locale(lang);
            Resources res = context.getBaseContext().getResources();
            DisplayMetrics dm = res.getDisplayMetrics();
            Configuration conf = new Configuration();
            conf.setLocale(myLocale);
            res.updateConfiguration(conf, dm);
            context.onConfigurationChanged(conf);

            if (isRefresh)
            {
                updateActivity(context,className);
            }
        }
    }

    public static void updateActivity(Activity context, Class<?> className) {
        Intent intent = new Intent(context,className);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);

    }


    public static boolean checkTimeDiffernce(Calendar current_cal, String date) {
        try {


            Calendar date_cal = Calendar.getInstance();

            SimpleDateFormat f = new SimpleDateFormat("dd-MM-yyyy HH:mm:ssZZ",Locale.ENGLISH);
            Date d = null;
            try {
                d = f.parse(date);
                date_cal.setTime(d);
            } catch (Exception e) {
                e.printStackTrace();
            }

            long difference = (current_cal.getTimeInMillis() - date_cal.getTimeInMillis()) / 1000;


            Functions.logDMsg("Tag : "+difference);

            if (difference <0) {
                return true;
            }
            else {
                return false;
            }

        } catch (Exception e) {
            return false;
        }


    }


    public static Dialog indeterminantDialog;

    public static void showIndeterminentLoader(Context context,String title, boolean outside_touch, boolean cancleable) {

        indeterminantDialog = new Dialog(context);
        indeterminantDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        indeterminantDialog.setContentView(R.layout.item_indeterminant_progress_layout);
        indeterminantDialog.getWindow().setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.d_round_white_background));
        TextView tvTitle=indeterminantDialog.findViewById(R.id.tvTitle);
        if (title!=null && TextUtils.isEmpty(title))
        {
            tvTitle.setText(title);
        }
        if (!outside_touch)
            indeterminantDialog.setCanceledOnTouchOutside(false);

        if (!cancleable)
            indeterminantDialog.setCancelable(false);

        indeterminantDialog.show();

    }


    public static void cancelIndeterminentLoader() {
        if (indeterminantDialog != null) {
            indeterminantDialog.cancel();
        }
    }



    public static void setApplicationMode(Activity activity){

            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

    }


    //check login status
    public static boolean checkLoginUser(Activity context) {
        if (Functions.getSharedPreference(context)
                .getBoolean(Variables.IS_LOGIN, false)) {

            return true;
        } else {
            Intent intent = new Intent(context, LoginA.class);
            context.startActivity(intent);
            context.overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
            return false;
        }
    }


    // manage for store user data
    public static void storeUserLoginDataIntoDb(Context context, UserModel userDetailModel) {
        SharedPreferences.Editor editor = Functions.getSharedPreference(context).edit();
        editor.putString(Variables.FB_ID, userDetailModel.getFbId());
        editor.putString(Variables.ABOUT_ME, userDetailModel.getAboutMe());
        editor.putString(Variables.JOB_TITLE, userDetailModel.getJobTitle());
        editor.putString(Variables.GENDER, userDetailModel.getGender());
        editor.putString(Variables.BIRTHDAY, userDetailModel.getBirthday());
        editor.putInt(Variables.AGE, userDetailModel.getAge());
        editor.putString(Variables.COMPANY, userDetailModel.getCompany());
        editor.putString(Variables.SCHOOL, userDetailModel.getSchool());
        editor.putString(Variables.F_NAME, userDetailModel.getFirstName());
        editor.putString(Variables.L_NAME, userDetailModel.getLastName());
        editor.putString(Variables.LIVING, userDetailModel.getLiving());
        editor.putString(Variables.CHILDREN, ""+userDetailModel.getChildren());
        editor.putString(Variables.SMOKING, userDetailModel.getSmoking());
        editor.putString(Variables.DRINKING, userDetailModel.getDrinking());
        editor.putString(Variables.RELATIONSHIP, userDetailModel.getRelationship());
        editor.putString(Variables.SEXUALITY, userDetailModel.getSexuality());
        editor.putString(Variables.Varified,userDetailModel.getVerified());
        editor.putString(Variables.IMAGE1, userDetailModel.getImage1());
        editor.putString(Variables.IMAGE2, userDetailModel.getImage2());
        editor.putString(Variables.IMAGE3, userDetailModel.getImage3());
        editor.putString(Variables.IMAGE4, userDetailModel.getImage4());
        editor.putString(Variables.IMAGE5, userDetailModel.getImage5());
        editor.putString(Variables.IMAGE6, userDetailModel.getImage6());
        editor.putBoolean(Variables.IS_LOGIN, true);
        editor.commit();
    }


    public static int calculateCompleteProfile(Context context) {



        Variables.varFilledValNew = 0;
        per1 = 0;
        int totalVal = 19;


        try {

            String jobTitle=Functions.getSharedPreference(context).getString(Variables.JOB_TITLE,"");
            int age=Functions.getSharedPreference(context).getInt(Variables.AGE,0);
            String aboutMe=Functions.getSharedPreference(context).getString(Variables.ABOUT_ME,"");
            String gender=Functions.getSharedPreference(context).getString(Variables.GENDER,"");
            String birthday=Functions.getSharedPreference(context).getString(Variables.BIRTHDAY,"");
            String company=Functions.getSharedPreference(context).getString(Variables.COMPANY,"");
            String school=Functions.getSharedPreference(context).getString(Variables.SCHOOL,"");
            String living=Functions.getSharedPreference(context).getString(Variables.LIVING,"");
            String children=Functions.getSharedPreference(context).getString(Variables.CHILDREN,"");
            String smoking=Functions.getSharedPreference(context).getString(Variables.SMOKING,"");
            String dringking=Functions.getSharedPreference(context).getString(Variables.DRINKING,"");
            String relationship=Functions.getSharedPreference(context).getString(Variables.RELATIONSHIP,"");
            String sexuality=Functions.getSharedPreference(context).getString(Variables.SEXUALITY,"");
            String image1=Functions.getSharedPreference(context).getString(Variables.IMAGE1,"");
            String image2=Functions.getSharedPreference(context).getString(Variables.IMAGE2,"");
            String image3=Functions.getSharedPreference(context).getString(Variables.IMAGE3,"");
            String image4=Functions.getSharedPreference(context).getString(Variables.IMAGE4,"");
            String image5=Functions.getSharedPreference(context).getString(Variables.IMAGE5,"");
            String image6=Functions.getSharedPreference(context).getString(Variables.IMAGE6,"");

            if (!TextUtils.isEmpty(jobTitle) && !jobTitle.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (age!=0) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (!TextUtils.isEmpty(aboutMe) && !aboutMe.equals("null")) {

                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }


            if (!TextUtils.isEmpty(gender) && !gender.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (!TextUtils.isEmpty(birthday) && !birthday.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (!TextUtils.isEmpty(company) && !company.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (!TextUtils.isEmpty(school) && !school.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (!TextUtils.isEmpty(living) && !living.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }
            if (!TextUtils.isEmpty(children) && !children.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }


            if (!TextUtils.isEmpty(smoking) && !smoking.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (!TextUtils.isEmpty(dringking) && !dringking.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (!TextUtils.isEmpty(relationship) && !relationship.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (!TextUtils.isEmpty(sexuality) && !sexuality.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }
            if (!TextUtils.isEmpty(image1) && !image1.equals("0") && !image1.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (!TextUtils.isEmpty(image2) && !image2.equals("0") && !image2.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }
            if (!TextUtils.isEmpty(image3) && !image3.equals("0") && !image3.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }


            if (!TextUtils.isEmpty(image4) && !image4.equals("0") && !image4.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            if (!TextUtils.isEmpty(image5) && !image5.equals("0") && !image5.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }
            if (!TextUtils.isEmpty(image6) && !image6.equals("0") && !image6.equals("null")) {
                Variables.varFilledValNew = Variables.varFilledValNew + 1;
            }

            float percantage1 = ((float) Variables.varFilledValNew / (float) totalVal) * 100;

            per1 = Integer.parseInt("" + (int) percantage1);

        } catch (Exception b) {
            b.printStackTrace();
        }


        return per1;
    }


    public static void logoutUser(Context context) {
        Variables.varFilledValNew = 0;
        per1 = 0;

        SharedPreferences.Editor editor = Functions.getSharedPreference(context).edit();
        editor.clear();
        editor.commit();
        Intent intent = new Intent(context, SplashA.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);

    }



    public static BroadcastReceiver broadcastReceiver;
    public static IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");

    public static void unRegisterConnectivity(Context mContext) {
        try {
            if (broadcastReceiver != null)
                mContext.unregisterReceiver(broadcastReceiver);

        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    public static void RegisterConnectivity(Context context, final InternetCheckCallback callback) {

        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (isConnectedToInternet(context)) {
                    callback.GetResponse("alert", "connected");
                } else {
                    callback.GetResponse("alert", "disconnected");
                }
            }
        };

        context.registerReceiver(broadcastReceiver, intentFilter);
    }



    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }


    public static String readableFileSize(long size) {
        if(size <= 0) return "0";
        final String[] units = new String[] { "B", "kB", "MB", "GB", "TB" };
        int digitGroups = (int) (Math.log10(size)/ Math.log10(1024));
        return new DecimalFormat("#,##0.#").format(size/ Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }

    public static String ChangeDateFormatWithAdditionalMonth(String fromFormat, String toFormat, String date, int additionalMonth){

        SimpleDateFormat dateFormat = new SimpleDateFormat(fromFormat, Locale.ENGLISH);
        Date sourceDate = null;

        try {
            sourceDate = dateFormat.parse(date);

            Calendar calanderDate = Calendar.getInstance();
            calanderDate.setTime(sourceDate);
            calanderDate.add(Calendar.MONTH,additionalMonth);
            sourceDate=calanderDate.getTime();

            SimpleDateFormat targetFormat = new SimpleDateFormat(toFormat,Locale.ENGLISH);

            return  targetFormat.format(sourceDate);

        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }

    }


    // getCurrent Date
    public static String getCurrentDate(String dateFormat) {
        SimpleDateFormat format=new SimpleDateFormat(dateFormat,Locale.ENGLISH);
        Calendar date = Calendar.getInstance();
        return format.format(date.getTime());
    }


    public static boolean isDateExpiredInDays(String format, String mStartDate, String mEndDate) {
        try {

            Calendar startDateCal = Calendar.getInstance();
            Calendar endDateCal = Calendar.getInstance();


            SimpleDateFormat f = new SimpleDateFormat(format,Locale.ENGLISH);

            Date startDate = null;
            try {
                startDate = f.parse(mStartDate);
                startDateCal.setTime(startDate);
            } catch (Exception e) {
                Log.d(Constants.tag,"Exception startDate: "+e);
            }

            Date endDate = null;
            try {
                endDate = f.parse(mEndDate);
                endDateCal.setTime(endDate);
            } catch (Exception e) {
                Log.d(Constants.tag,"Exception endDate: "+e);
            }

            long difference = (endDateCal.getTimeInMillis() - startDateCal.getTimeInMillis()) / 1000;

            Log.d(Constants.tag,"difference in Second: "+difference);
            if (difference>0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        catch (Exception e) {
            Log.d(Constants.tag,"Exception days: "+e);
            return true;
        }

    }

}
