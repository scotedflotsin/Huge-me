package com.qboxus.hugmeapp.codeclasses;

import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class Variables {

    public static int height;
    public static int width;

    public static final String http = "http";


    public static SharedPreferences sharedPreferences;
    public static final String PREF_NAME = "pref_name";
    public static final String APP_LANGUAGE = "app_language";
    public static final String APP_LANGUAGE_CODE = "app_language_code";
    public static final String DEFAULT_LANGUAGE_CODE = "en";
    public static final String DEFAULT_LANGUAGE = "English";
    public static final String DEVICE_TOKEN = "device_token";

    public static final String IS_LOGIN = "is_login";
    public static final String FB_ID = "fb_id";
    public static final String ABOUT_ME = "about_me";
    public static final String JOB_TITLE = "job_title";
    public static final String GENDER = "gender";
    public static final String BIRTHDAY = "birthday";
    public static final String AGE = "age";
    public static final String COMPANY = "company";
    public static final String SCHOOL = "school";
    public static final String F_NAME = "first_name";
    public static final String L_NAME = "last_name";
    public static final String LIVING = "living";
    public static final String CHILDREN = "children";
    public static final String SMOKING = "smoking";
    public static final String DRINKING = "drinking";
    public static final String RELATIONSHIP = "relationship";

    public static final String Varified = "varified";
    public static final String SEXUALITY = "sexuality";
    public static final String IMAGE1 = "image1";
    public static final String IMAGE2 = "image2";
    public static final String IMAGE3 = "image3";
    public static final String IMAGE4 = "image4";
    public static final String IMAGE5 = "image5";
    public static final String IMAGE6 = "image6";
    public static final String LATITUDE = "Latitude";
    public static final String LONGITUDE = "Longitude";

    public static final String IS_PURCHASE="is_puchase";
    public static final String EMAIL="email";
    public static final String PROFILE_HIDE="profile_hide";
    public static final String INBOX_FILTER="inbox_filter";
    public static final String BOOST_ON_TIME="boost_on_time";
    public static final String VIDEO_CALLING_USED_TIME="video_calling_used_time";
    public static final String VOICE_CALLING_USED_TIME="voice_calling_used_time";
    public static final String ADS_CLICK="ads_click";
    public static final String SEARCH_PLACE_NAME="search_place_name";
    public static final String SEARCH_LATITUDE = "search_latitude";
    public static final String SEARCH_LONGITUDE = "search_longitude";
    public static final String SEARCH_PARAMS_JSON = "search_params_json";
    public static final String SOCIAL_INFO_JSON = "social_info_json";



    public static final String onlineUser = "OnlineUsers";
    public static String downloadPref ="download_pref";
    public static String res;

    public static int varNumClickToShowAds = 3;
    public static int varFilledValNew;
    public static int per1;
    public static int varTabChange = 0;
    public static int isSearched = 0;
    public static int isSearchedAtWw = 0;

    public static int adDisplayAfter =9;


    public static int marginLeft = 10;
    public static int marginRight = 10;
    public static int marginTop = 10;
    public static int marginBottom = 10;

    public static SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH);
    public static SimpleDateFormat df2 = new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.ENGLISH);

    public static String openedChatId;
    public static String userName;
    public static String userPic;
    public static String userId;
    public static final int MY_API_TIMEOUT_MS = 30000;


    public static String varLiving = "";
    public static String varChildren = "";
    public static String varSmoking = "";
    public static String varDrinking = "";
    public static String varRelationship = "";
    public static String varSexuality = "";
    public static String varAboutMe = "";
    public static String userGender = "";



    public static String gifFirstpart ="https://media.giphy.com/media/";
    public static String gifSecondpart ="/100w.gif";

    public static String gifFirstpartChat ="https://media.giphy.com/media/";
    public static String gifSecondpartChat ="/200w.gif";


    // Arrays
    public static final String[] ARR_LIST_LIVING = {"No answer","By myself","Student residence","With parents","With partner","With housemate(s)"};
    public static final String[] ARR_LIST_RELATIONSHIP = {"No answer"," im in a complicated relationship", "Single"," Taken "};

    public static final String[] ARR_LIST_CHILDREN = {"No answer"," Grown up", "Already have"," No never ", "Someday"};
    public static final String[] ARR_LIST_SMOKE = {"No answer","Im a heavy smoker","I hate smoking","i dont like it","im a social smoker","I smoke occasionally"};
    public static final String[] ARR_LIST_DRINK = {"No answer"," I drink socially", "I dont drink"," Im against drinking ", "I drink a lot"};
    public static final String[] ARR_LIST_SEXUALITY = {"No answer","Bisexual", "Gay","Ask me ", "Straight"};
    public static final String[] ARR_LIST_GENDER = {"Male","Female", "I dont want to disclose"," No Way ", "Ask Me"};


    // Fragments Names
    public static final String FRAG_ABOUT = "Describe_yourself_F";
    public static final String FRAG_RELATION = "Relationship_A";
    public static final String FRAG_LIVING = "Living_F";
    public static final String FRAG_KIDS = "Kids_F";
    public static final String FRAG_SMOKE = "Smoke_F";
    public static final String FRAG_DRINK = "Drink_F";
    public static final String FRAG_GENDER = "Gender_F";


}
