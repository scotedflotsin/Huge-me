package com.qboxus.hugmeapp.inappsubscription;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.qboxus.hugmeapp.Constants;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.activitiesandfragments.SplashA;
import com.qboxus.hugmeapp.activitiesandfragments.activities.ChatA;
import com.qboxus.hugmeapp.activitiesandfragments.activities.MainActivity;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.databinding.ActivityInAppSubscriptionBinding;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.volleypackage.CallBack;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import games.moisoni.google_iab.BillingConnector;
import games.moisoni.google_iab.BillingEventListener;
import games.moisoni.google_iab.enums.ProductType;
import games.moisoni.google_iab.models.BillingResponse;
import games.moisoni.google_iab.models.ProductInfo;
import games.moisoni.google_iab.models.PurchaseInfo;

public class InAppSubscriptionA extends AppCompatActivity {



    int subscriptionPosition;
    private ArrayList<Integer> imagesArray;
    ActivityInAppSubscriptionBinding binding;

    private BillingConnector billingConnector;
    //list for example purposes to demonstrate how to manually acknowledge or consume purchases
    private final List<PurchaseInfo> purchasedInfoList = new ArrayList<>();
    //list for example purposes to demonstrate how to synchronously check a purchase state
    private final List<ProductInfo> fetchedProductInfoList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= DataBindingUtil.setContentView(this,R.layout.activity_in_app_subscription);

        initControl();
        actionControl();
    }

    private void initControl() {
        initializeBillingClient();
        setSlider();
        selectOne(2);
    }

    private void actionControl() {
        binding.Goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        binding.purchaseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MainActivity.purductPurchase)
                {
                    Toast.makeText(InAppSubscriptionA.this, InAppSubscriptionA.this.getString(R.string.already_subscribe_package), Toast.LENGTH_SHORT).show();
                }
                else
                {
                    purchaseSubscription(subscriptionPosition);
                }
            }
        });
        binding.subLayout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectOne(1);
            }
        });
        binding.subLayout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectOne(2);
            }
        });
        binding.subLayout3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectOne(3);
            }
        });
    }


    private void initializeBillingClient() {
        //create a list with subscription ids
        List<String> subscriptionIds = new ArrayList<>();
        subscriptionIds.add(Constants.PRODUCT_ID);
        subscriptionIds.add(Constants.PRODUCT_ID_2);
        subscriptionIds.add(Constants.PRODUCT_ID_3);

        billingConnector = new BillingConnector(this, Constants.licenseKey) //"license_key" - public developer key from Play Console
                .setSubscriptionIds(subscriptionIds) //to set subscription ids - call only for subscription products
                .autoAcknowledge() //legacy option - better call this. Alternatively purchases can be acknowledge via public method "acknowledgePurchase(PurchaseInfo purchaseInfo)"
                .autoConsume() //legacy option - better call this. Alternatively purchases can be consumed via public method consumePurchase(PurchaseInfo purchaseInfo)"
                .enableLogging()
                .connect(); //to connect billing client with Play Console

        billingConnector.setBillingEventListener(new BillingEventListener() {
            @Override
            public void onProductsFetched(@NonNull List<ProductInfo> productDetails) {
                String product;

                for (ProductInfo productInfo : productDetails) {
                    product = productInfo.getProduct();

                    Log.d(Constants.tag, "Product fetched: " + product);
                    fetchedProductInfoList.add(productInfo); //check "usefulPublicMethods" to see how to synchronously check a purchase state
                }
            }

            @Override
            public void onPurchasedProductsFetched(@NonNull ProductType productType, @NonNull List<PurchaseInfo> purchases) {
                /*
                 * This will be called even when no purchased products are returned by the API
                 * */
                Log.d(Constants.tag,"onPurchasedProductsFetched: "+productType);
                switch (productType) {
                    case INAPP:
                        //TODO - non-consumable/consumable products
                        break;
                    case SUBS:
                        //TODO - subscription products
                        binding.purchaseBtn.setEnabled(true);
                        binding.purchaseBtn.setClickable(true);
                        break;
                    case COMBINED:
                        //this will be triggered on activity start
                        //the other two (INAPP and SUBS) will be triggered when the user actually buys a product
                        //TODO - restore purchases
                        break;
                }

                String product;
                for (PurchaseInfo purchaseInfo : purchases) {
                    product = purchaseInfo.getProduct();

                    Log.d(Constants.tag, "Purchased product fetched: " + product);
                }
            }

            @Override
            public void onProductsPurchased(@NonNull List<PurchaseInfo> purchases) {
                String product;
                String purchaseToken;

                for (PurchaseInfo purchaseInfo : purchases) {
                    product = purchaseInfo.getProduct();
                    purchaseToken = purchaseInfo.getPurchaseToken();

                    Log.d(Constants.tag, "Product purchased: " + product);
                    //TODO - do something
                    Log.d(Constants.tag, "Purchase token: " + purchaseToken);
                    //TODO - similarly check for other ids
                    purchasedInfoList.add(purchaseInfo); //check "usefulPublicMethods" to see how to acknowledge or consume a purchase manually
                    acknowledgedPurchase(purchaseInfo);
                }
            }

            @Override
            public void onPurchaseAcknowledged(@NonNull PurchaseInfo purchase) {
                /*
                 * Grant user entitlement for NON-CONSUMABLE products and SUBSCRIPTIONS here
                 *
                 * Even though onProductsPurchased is triggered when a purchase is successfully made
                 * there might be a problem along the way with the payment and the purchase won't be acknowledged
                 *
                 * Google will refund users purchases that aren't acknowledged in 3 days
                 *
                 * To ensure that all valid purchases are acknowledged the library will automatically
                 * check and acknowledge all unacknowledged products at the startup
                 * */

                String acknowledgedProduct = purchase.getProduct();

                Log.d(Constants.tag, "Acknowledged: " + acknowledgedProduct);
            }

            @Override
            public void onPurchaseConsumed(@NonNull PurchaseInfo purchase) {
                /*
                 * Grant user entitlement for CONSUMABLE products here
                 *
                 * Even though onProductsPurchased is triggered when a purchase is successfully made
                 * there might be a problem along the way with the payment and the user will be able consume the product
                 * without actually paying
                 * */

                String consumedProduct = purchase.getProduct();

                Log.d(Constants.tag, "Consumed: " + consumedProduct);
            }

            @Override
            public void onBillingError(@NonNull BillingConnector billingConnector, @NonNull BillingResponse response) {
                switch (response.getErrorType()) {
                    case CLIENT_NOT_READY:
                        //TODO - client is not ready yet
                        break;
                    case CLIENT_DISCONNECTED:
                        //TODO - client has disconnected
                        break;
                    case PRODUCT_NOT_EXIST:
                        //TODO - product does not exist
                        break;
                    case CONSUME_ERROR:
                        //TODO - error during consumption
                        break;
                    case CONSUME_WARNING:
                        /*
                         * This will be triggered when a consumable purchase has a PENDING state
                         * User entitlement must be granted when the state is PURCHASED
                         *
                         * PENDING transactions usually occur when users choose cash as their form of payment
                         *
                         * Here users can be informed that it may take a while until the purchase complete
                         * and to come back later to receive their purchase
                         * */
                        //TODO - warning during consumption
                        break;
                    case ACKNOWLEDGE_ERROR:
                        //TODO - error during acknowledgment
                        break;
                    case ACKNOWLEDGE_WARNING:
                        /*
                         * This will be triggered when a purchase can not be acknowledged because the state is PENDING
                         * A purchase can be acknowledged only when the state is PURCHASED
                         *
                         * PENDING transactions usually occur when users choose cash as their form of payment
                         *
                         * Here users can be informed that it may take a while until the purchase complete
                         * and to come back later to receive their purchase
                         * */
                        //TODO - warning during acknowledgment
                        break;
                    case FETCH_PURCHASED_PRODUCTS_ERROR:
                        //TODO - error occurred while querying purchased products
                        break;
                    case BILLING_ERROR:
                        //TODO - error occurred during initialization / querying product details
                        break;
                    case USER_CANCELED:
                        //TODO - user pressed back or canceled a dialog
                        break;
                    case SERVICE_UNAVAILABLE:
                        //TODO - network connection is down
                        break;
                    case BILLING_UNAVAILABLE:
                        //TODO - billing API version is not supported for the type requested
                        break;
                    case ITEM_UNAVAILABLE:
                        //TODO - requested product is not available for purchase
                        break;
                    case DEVELOPER_ERROR:
                        //TODO - invalid arguments provided to the API
                        break;
                    case ERROR:
                        //TODO - fatal error during the API action
                        break;
                    case ITEM_ALREADY_OWNED:
                        Toast.makeText(InAppSubscriptionA.this, "Already Purchase", Toast.LENGTH_SHORT).show();
                        //TODO - failure to purchase since item is already owned
                        break;
                    case ITEM_NOT_OWNED:
                        //TODO - failure to consume since item is not owned
                        break;
                }

                Log.d(Constants.tag, "Error type: " + response.getErrorType() +
                        " Response code: " + response.getResponseCode() + " Message: " + response.getDebugMessage());

            }
        });
    }




    public void selectOne(int position) {
        subscriptionPosition = position;

        binding.subLayout1.setBackground(ContextCompat.getDrawable(binding.getRoot().getContext(), R.drawable.d_round_gray_border));
        binding.subLayout2.setBackground(ContextCompat.getDrawable(binding.getRoot().getContext(),R.drawable.d_round_gray_border));
        binding.subLayout3.setBackground(ContextCompat.getDrawable(binding.getRoot().getContext(),R.drawable.d_round_gray_border));

        if (position == 1) {
            binding.subLayout1.setBackground(ContextCompat.getDrawable(binding.getRoot().getContext(),R.drawable.d_round_border_radius15));

        } else if (position == 2) {
            binding.subLayout2.setBackground(ContextCompat.getDrawable(binding.getRoot().getContext(),R.drawable.d_round_border_radius15));

        } else if (position == 3) {
            binding.subLayout3.setBackground(ContextCompat.getDrawable(binding.getRoot().getContext(),R.drawable.d_round_border_radius15));
        }

    }


    public void purchaseSubscription(int index){
        if (index==1)
        {
            billingConnector.subscribe(InAppSubscriptionA.this, Constants.PRODUCT_ID);
        }
        else
        if (index==2)
        {
            billingConnector.subscribe(InAppSubscriptionA.this, Constants.PRODUCT_ID_2);
        }
        else
        if (index==3)
        {
            billingConnector.subscribe(InAppSubscriptionA.this, Constants.PRODUCT_ID_3);
        }
    }


    public void acknowledgedPurchase(PurchaseInfo purchaseInfo){
        MainActivity.purductPurchase = true;
        String duration="";
        if (purchaseInfo.getProduct().equals(Constants.PRODUCT_ID))
        {
            duration="1";
        }
        else
        if (purchaseInfo.getProduct().equals(Constants.PRODUCT_ID_2))
        {
            duration="3";
        }
        else
        if (purchaseInfo.getProduct().equals(Constants.PRODUCT_ID_3))
        {
            duration="12";
        }

        callApiForUpdatePurchase(purchaseInfo.getPurchaseToken(),duration);
    }


    // on destory we will release the billing process
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (billingConnector != null) {
            billingConnector.release();
        }
    }

    public void goback() {
        startActivity(new Intent(binding.getRoot().getContext(), SplashA.class));
        finish();
    }

    // when user subscribe the app then this method will call that will store the status of user
    // into the database
    private void callApiForUpdatePurchase(String purchaseToken,String duration) {

        JSONObject parameters = new JSONObject();
        try {

            String userId = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.FB_ID,"");

            parameters.put("fb_id", userId);
            parameters.put("subscription_id", ""+purchaseToken);
            parameters.put("duration", ""+duration);

        } catch (Exception e) {
            e.printStackTrace();
        }

        Functions.showLoader(binding.getRoot().getContext(), false, false);

        ApiRequest.callApi(binding.getRoot().getContext(), ApiLinks.purchaseSubscription, parameters, new CallBack() {
            @Override
            public void getResponse(String requestType, String response) {
                Functions.cancelLoader();
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    if (jsonObject.optInt("code")==200)
                    {
                        Functions.getSharedPreference(binding.getRoot().getContext()).edit().putBoolean(Variables.IS_PURCHASE,true).commit();
                        MainActivity.purductPurchase = true;

                        goback();
                    }
                    else
                    {
                        Functions.showAlert(binding.getRoot().getContext(), binding.getRoot().getContext().getString(R.string.alert), binding.getRoot().getContext().getString(R.string.unable_to_purchase_subscription), null);
                    }
                }
                catch (Exception e)
                {
                    Log.d(Constants.tag,"Exception: "+e);
                }



            }
        });


    }

    public void setSlider() {

        imagesArray = new ArrayList<>();
        imagesArray.add(0);
        imagesArray.add(1);

        try {
            binding.imageSliderPager.setAdapter(new SlidingImageAdapter(binding.subLayout1.getContext(), imagesArray));
        } catch (NullPointerException e) {
            e.getCause();
        }

        binding.imageSliderPager.setCurrentItem(0);
        binding.indicator.setupWithViewPager(binding.imageSliderPager, true);

    }



    private void reloadScreen() {
        Log.d(Constants.tag,"reloadScreen: ");
        //Reload the screen to activate the removeAd and remove the actual Ad off the screen.
        finish();
        overridePendingTransition(0, 0);
        startActivity(getIntent());
        overridePendingTransition(0, 0);
    }

}
