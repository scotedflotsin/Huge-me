package com.qboxus.hugmeapp.adapters;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import androidx.annotation.RequiresApi;

import com.facebook.drawee.view.SimpleDraweeView;
import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.R;

import java.util.List;

public class CardAdapter extends ArrayAdapter<UserModel> {


    AdapterClickListener adapterClicklistener;
    List<UserModel> nearbyList;
    Context context;

    public CardAdapter(Context context, int resources, AdapterClickListener adapterClicklistener, List<UserModel> nearbyList) {
        super(context, resources);
        this.adapterClicklistener = adapterClicklistener;
        this.nearbyList = nearbyList;
        this.context = context;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public View getView(final int position, View contentView, ViewGroup parent) {


        ViewHolder holder;

        if (contentView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            contentView = inflater.inflate(R.layout.item_card_layout, parent, false);
            holder = new ViewHolder(contentView);
            contentView.setTag(holder);
        } else {
            holder = (ViewHolder) contentView.getTag();
        }

        final UserModel item = getItem(position);

        holder.image.setImageResource(android.R.color.transparent);
        try {

            Uri uri = Uri.parse(item.getImage1());
            holder.image.setImageURI(uri);
        } catch (Exception v) {
            Functions.logDMsg("Error In Fresco " + getItem(position) + " Err " + v.toString());
        }

        holder.onbind(position, item, adapterClicklistener);
        return contentView;
    }

    private static class ViewHolder {

        public SimpleDraweeView image;
        ImageView like, dislike;

        public ViewHolder(View view) {
            image = view.findViewById(R.id.card_item_userimage_id);
            like = view.findViewById(R.id.right_overlay);
            dislike = view.findViewById(R.id.left_overlay);

        }

        public void onbind(final int pos, final UserModel model, final AdapterClickListener clickListener) {

            like.setOnClickListener(view -> clickListener.onItemClick(pos, model, view));

            dislike.setOnClickListener(view -> clickListener.onItemClick(pos, model, view));

        }
    }


}
