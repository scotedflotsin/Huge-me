package com.qboxus.hugmeapp.volleypackage;

import android.content.Context;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class ApiRequest {


    public static void callApi(final Context context, final String API_LINK,
                               final JSONObject jsonObject, final CallBack callBack) {


        Functions.logDMsg( API_LINK);
        if (jsonObject != null)
            Functions.logDMsg( jsonObject.toString());

        try {
            RequestQueue queue = Volley.newRequestQueue(context);

            JsonObjectRequest jsonObj = new JsonObjectRequest(API_LINK, jsonObject, response -> {
                Functions.logDMsg( response.toString());

                if (callBack != null)
                    callBack.getResponse("Post", response.toString());
            }, error -> {
                Functions.logDMsg( error.toString());
                if (callBack != null)
                    callBack.getResponse("Post", error.toString());

            });

            queue.add(jsonObj);
            jsonObj.setRetryPolicy(new DefaultRetryPolicy(
                    Variables.MY_API_TIMEOUT_MS,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
