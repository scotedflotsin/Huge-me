package com.qboxus.hugmeapp.activitiesandfragments.fragments;


import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.qboxus.hugmeapp.activitiesandfragments.activities.EditProfileVpA;
import com.qboxus.hugmeapp.adapters.ProfileOptionsAdapter;
import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.RootFragment;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.models.ProfileInfoModel;
import com.qboxus.hugmeapp.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class RelationshipF extends RootFragment {

    View view;
    RecyclerView rv;
    ProfileOptionsAdapter adapter;
    ArrayList<ProfileInfoModel> list;
    Context context;
    ListView listView;

    public RelationshipF() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_relation_ship, container, false);
        context = getContext();

        rv = (RecyclerView) view.findViewById(R.id.rv_id);

        list = new ArrayList<>();


        Functions.addValuesToRv(list, Variables.ARR_LIST_RELATIONSHIP);

        listView = (ListView) view.findViewById(R.id.simple_list);

        final ArrayAdapter<String> arrayAdapter

                = new ArrayAdapter<>(context,

                android.R.layout.simple_list_item_single_choice,

                Variables.ARR_LIST_RELATIONSHIP);

        listView.setOnItemClickListener((parent, view, position, id) -> {

            Variables.varRelationship = Variables.ARR_LIST_RELATIONSHIP[position];

            int adaptorPositionTotal = EditProfileVpA.segmentAdapter.getCount();
            int adpCurrentItemPosition = EditProfileVpA.vp.getCurrentItem() + 1;

            Variables.varRelationship = Variables.ARR_LIST_RELATIONSHIP[position];

            if (adaptorPositionTotal == adpCurrentItemPosition) {

                EditProfileVpA.createJsonForAPI(context);
                getActivity().finish();
            } else {
                EditProfileVpA.vp.setCurrentItem(EditProfileVpA.vp.getCurrentItem() + 1);
                EditProfileVpA.fragCounter.setText((EditProfileVpA.vp.getCurrentItem() + 1) + "/ " + EditProfileVpA.segmentAdapter.getCount());
                EditProfileVpA.colorRl.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.zink2));

                EditProfileVpA.getFragmentName(adpCurrentItemPosition);
            }
        });


        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        listView.setAdapter(arrayAdapter);


        RelativeLayout.LayoutParams lp1 = (RelativeLayout.LayoutParams) EditProfileVpA.vpRl.getLayoutParams();
        lp1.height = (int) (Variables.height / 2);

        EditProfileVpA.vpRl.setLayoutParams(lp1);

        EditProfileVpA.next.setVisibility(View.VISIBLE);


        adapter = new ProfileOptionsAdapter(getContext(), list, new AdapterClickListener() {
            @Override
            public void onItemClick(int postion, Object model, View view) {
                // Adapter posoition
                int adaptorPositionTotal = EditProfileVpA.segmentAdapter.getCount();
                int adpCurrentItemPosition = EditProfileVpA.vp.getCurrentItem() + 1;


                // Relationship_A Get Values from List
                ProfileInfoModel item = list.get(postion);


                Variables.varRelationship = item.getText();

                if (adaptorPositionTotal == adpCurrentItemPosition) {

                    EditProfileVpA.createJsonForAPI(context);
                    getActivity().finish();

                } else {

                    EditProfileVpA.vp.setCurrentItem(EditProfileVpA.vp.getCurrentItem() + 1);
                    EditProfileVpA.fragCounter.setText((EditProfileVpA.vp.getCurrentItem() + 1) + "/ " + EditProfileVpA.segmentAdapter.getCount());
                    EditProfileVpA.colorRl.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.orange));

                    methodHidelinearlayout(EditProfileVpA.bodytypeLl, EditProfileVpA.descLl, EditProfileVpA.happyLl,
                            EditProfileVpA.genderLl, EditProfileVpA.kidsLl, EditProfileVpA.livingLl, EditProfileVpA.drinkLl,
                            EditProfileVpA.smokeLl, EditProfileVpA.profqsLl, EditProfileVpA.relationLl, EditProfileVpA.missingLl);

                }
            }

            @Override
            public void onLongItemClick(int postion, Object model, View view) {

            }
        });

        rv.setHasFixedSize(false);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));

        rv.setAdapter(adapter);

        return view;
    }


    private void methodHidelinearlayout(LinearLayout ll1, LinearLayout ll2, LinearLayout ll3, LinearLayout ll4,
                                        LinearLayout ll5, LinearLayout ll6, LinearLayout ll7, LinearLayout ll8,
                                        LinearLayout ll9, LinearLayout ll10, LinearLayout ll11) {

        ll1.setVisibility(View.VISIBLE);
        ll2.setVisibility(View.GONE);
        ll3.setVisibility(View.GONE);
        ll4.setVisibility(View.GONE);
        ll5.setVisibility(View.GONE);
        ll6.setVisibility(View.GONE);
        ll7.setVisibility(View.GONE);
        ll8.setVisibility(View.GONE);
        ll9.setVisibility(View.GONE);
        ll10.setVisibility(View.GONE);
        ll11.setVisibility(View.GONE);

    }

}
