package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.core.content.FileProvider;
import androidx.databinding.DataBindingUtil;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.qboxus.hugmeapp.Constants;
import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.bottomsheet.MyProfileBottomSheet;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.codeclasses.PermissionUtils;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.databinding.ActivityAccountBinding;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class AccountA extends AppCompatLocaleActivity {

    ActivityAccountBinding binding;
    PermissionUtils takePermissionUtils;
    String imageFilePath;
    FirebaseStorage storage;
    StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        binding= DataBindingUtil.setContentView(this,R.layout.activity_account);
        binding.deleteAccount.setOnClickListener(v -> delAccount());

        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();



        binding.userimageImg.setOnClickListener(v -> addUserRecord());

        binding.addPhotoImgId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePermissionUtils=new PermissionUtils(AccountA.this,mCameraStoragePermissionResult);
                if (takePermissionUtils.isStorageCameraPermissionGranted()) {
                    selectImage();
                }
                else
                {
                    takePermissionUtils.
                            showStorageCameraPermissionDailog(getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
                }
            }
        });


        String isHide = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.PROFILE_HIDE,"0");

        if (isHide != null) {

            if (isHide.equals("1")) {
                binding.accountCBId.setChecked(true);
            } else {
                binding.accountCBId.setChecked(false);
            }

        }


        binding.accountCBId.setOnCheckedChangeListener((compoundButton, isChecked) -> {

            boolean varBoolSoundOn = (isChecked) ? true : false;
            String userId = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.FB_ID,"");
            if (varBoolSoundOn == true) {
                Functions.showOrHideProfile(userId, "1", binding.getRoot().getContext());
            } else {
                Functions.showOrHideProfile(userId, "0", binding.getRoot().getContext());
            }

        });

        binding.accountSignoutId.setOnClickListener(v -> Functions.logoutUser(binding.getRoot().getContext()));

        binding.ivBack.setOnClickListener(v -> finish());

        setUserData();

    }


    String userImage;
    String userName;
    public void setUserData() {
        userImage = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.IMAGE1,"");
        userName = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.F_NAME,"") + " ," +Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.L_NAME,"");
        binding.usernameTxt.setText("" + userName);
        binding.userimageImg.setController(Functions.frescoImageLoad(userImage,R.drawable.ic_user_icon,binding.userimageImg,false));
    }



    // this method will show the dialog of selete the either take a picture form camera or pick the image from gallary
    private void selectImage() {

        final CharSequence[] options = {binding.getRoot().getContext().getString(R.string.take_photo),
                binding.getRoot().getContext().getString(R.string.choose_from_gallery),
                binding.getRoot().getContext().getString(R.string.cancel)};


        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(binding.getRoot().getContext(), R.style.AlertDialogCustom);

        builder.setTitle(binding.getRoot().getContext().getString(R.string.add_photo_));

        builder.setItems(options, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (options[item].equals(binding.getRoot().getContext().getString(R.string.take_photo))) {
                    openCameraIntent();
                } else if (options[item].equals(binding.getRoot().getContext().getString(R.string.choose_from_gallery))) {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    resultCallbackForGallery.launch(intent);
                } else if (options[item].equals(binding.getRoot().getContext().getString(R.string.cancel))) {
                    dialog.dismiss();
                }
            }
        });

        builder.show();

    }


    ActivityResultLauncher<Intent> resultCallbackForCrop = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        CropImage.ActivityResult cropResult = CropImage.getActivityResult(data);
                        handleCrop(cropResult.getUri());
                    }
                }
            });


    ActivityResultLauncher<Intent> resultCallbackForGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        Uri selectedImage = data.getData();
                        beginCrop(selectedImage);

                    }
                }
            });

    ActivityResultLauncher<Intent> resultCallbackForCamera = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Matrix matrix = new Matrix();
                        try {
                            android.media.ExifInterface exif = new android.media.ExifInterface(imageFilePath);
                            int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                            switch (orientation) {
                                case android.media.ExifInterface.ORIENTATION_ROTATE_90:
                                    matrix.postRotate(90);
                                    break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_180:
                                    matrix.postRotate(180);
                                    break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_270:
                                    matrix.postRotate(270);
                                    break;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Uri selectedImage = (Uri.fromFile(new File(imageFilePath)));
                        beginCrop(selectedImage);
                    }
                }
            });


    public File createImageFile() throws IOException {
        String timeStamp =
                new SimpleDateFormat("yyyyMMdd_HHmmss",
                        Locale.getDefault()).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir =
                binding.getRoot().getContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  // prefix /
                ".jpg",         // suffix /
                storageDir      // directory /
        );

        imageFilePath = image.getAbsolutePath();
        return image;
    }


    private void beginCrop(Uri source) {
        Intent intent=CropImage.activity(source).setCropShape(CropImageView.CropShape.OVAL)
                .setAspectRatio(1,1).getIntent(binding.getRoot().getContext());
        resultCallbackForCrop.launch(intent);
    }

    // get the image uri after the image crope
    private void handleCrop(Uri userimageuri) {
        try {
            addProfilePic(userimageuri);
        } catch (Exception e) {
            Log.d(Constants.tag,"Exception: "+e);
        }
    }


    // below three method is related with taking the picture from camera
    private void openCameraIntent() {
        Intent pictureIntent = new Intent(
                MediaStore.ACTION_IMAGE_CAPTURE);
        if (pictureIntent.resolveActivity(binding.getRoot().getContext().getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (Exception ex) {
            }
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(binding.getRoot().getContext().getApplicationContext(), binding.getRoot().getContext().getPackageName() + ".fileprovider", photoFile);
                pictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                resultCallbackForCamera.launch(pictureIntent);
            }
        }
    }





    private ActivityResultLauncher<String[]> mCameraStoragePermissionResult = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onActivityResult(Map<String, Boolean> result) {

                    boolean allPermissionClear=true;
                    List<String> blockPermissionCheck=new ArrayList<>();
                    for (String key : result.keySet())
                    {
                        if (!(result.get(key)))
                        {
                            allPermissionClear=false;
                            blockPermissionCheck.add(Functions.getPermissionStatus(AccountA.this,key));
                        }
                    }
                    if (blockPermissionCheck.contains("blocked"))
                    {
                        Functions.showPermissionSetting(AccountA.this,binding.getRoot().getContext().getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
                    }
                    else
                    if (allPermissionClear)
                    {
                        selectImage();
                    }

                }
            });




    public void delAccount() {

        AlertDialog.Builder builder1 = new AlertDialog.Builder(binding.getRoot().getContext());
        builder1.setTitle(binding.getRoot().getContext().getString(R.string.alert));
        builder1.setMessage(R.string.are_you_sure_delete_account);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                R.string.yes,
                (dialog, id) -> {
                    String userId = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.FB_ID,"");
                    Functions.deleteAccount(binding.getRoot().getContext(), "" + userId);
                });

        builder1.setNegativeButton(
                R.string.no,
                (dialog, id) -> dialog.cancel());

        AlertDialog alert11 = builder1.create();
        alert11.show();


    } // End Del Account_A


    public void addUserRecord() {
        // Method to add Logged in Record

        UserModel item=new UserModel();
        item.setFbId(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.FB_ID,""));
        item.setAboutMe(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.ABOUT_ME,""));
        item.setJobTitle( "Job");
        item.setGender(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.GENDER,""));
        item.setBirthday(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.BIRTHDAY,""));
        item.setAge(Functions.getSharedPreference(binding.getRoot().getContext()).getInt(Variables.AGE,0));
        item.setCompany(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.COMPANY,""));
        item.setSchool(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.SCHOOL,""));
        item.setFirstName(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.F_NAME,""));
        item.setLastName(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.L_NAME,""));
        item.setLiving(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.LIVING,""));
        item.setChildren(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.CHILDREN,""));
        item.setSmoking(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.SMOKING,""));
        item.setDrinking(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.DRINKING,""));
        item.setRelationship(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.RELATIONSHIP,""));
        item.setImage1(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.IMAGE1,""));
        item.setImage2(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.IMAGE2,""));
        item.setImage3(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.IMAGE3,""));
        item.setImage4(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.IMAGE4,""));
        item.setImage5(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.IMAGE5,""));
        item.setImage6(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.IMAGE6,""));


        item.Swipe ="like";
        item.block = "";
        item.distance = "no";





        Bundle bundleUserProfile = new Bundle();
        bundleUserProfile.putString("user_id", "" + Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.FB_ID,""));
        bundleUserProfile.putString("current_position", "");
        bundleUserProfile.putSerializable("user_near_by", item);

        MyProfileBottomSheet viewProfile = new MyProfileBottomSheet();
        viewProfile.setArguments(bundleUserProfile);

        viewProfile.show(getSupportFragmentManager(), viewProfile.getTag());

    }


    // Upload User Profile_F.
    public void addProfilePic(Uri filePath) {

        Functions.showLoader(binding.getRoot().getContext(), true, false);

        final String fb_id = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.FB_ID,"");

        StorageReference ref = storageReference.child("images/" + UUID.randomUUID().toString());
        ref.putFile(filePath)
                .addOnSuccessListener(taskSnapshot -> ref.getDownloadUrl().addOnSuccessListener(uri -> {

                    Functions.logDMsg("Img Url " + uri.toString());


                    final JSONObject parameters = new JSONObject();
                    try {
                        parameters.put("image_link", uri.toString());
                        parameters.put("fb_id", fb_id);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                    ApiRequest.callApi(
                            binding.getRoot().getContext(),
                            "" + ApiLinks.changeProfilePicture,
                            parameters,
                            (requestType, response) -> {

                                Functions.cancelLoader();
                                try {
                                    JSONObject resp = new JSONObject(response);
                                    if (resp.getString("code").equals("200")) {


                                        JSONArray msgObj = resp.getJSONArray("msg");
                                        JSONObject userInfoObj = msgObj.getJSONObject(0);

                                        UserModel userdetailModel= ParseData.parseUserModel(userInfoObj);
                                        Functions.storeUserLoginDataIntoDb(binding.getRoot().getContext(),userdetailModel);

                                        setUserData();
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }


                            }
                    );
                }))
                .addOnFailureListener(e -> {
                })
                .addOnProgressListener(taskSnapshot -> {
                    double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot
                            .getTotalByteCount());

                });


    }


}
