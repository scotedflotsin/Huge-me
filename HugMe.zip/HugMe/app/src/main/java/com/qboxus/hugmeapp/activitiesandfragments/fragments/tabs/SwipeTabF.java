package com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import com.android.volley.BuildConfig;
import com.appyvet.materialrangebar.RangeBar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.qboxus.hugmeapp.Constants;
import com.qboxus.hugmeapp.activitiesandfragments.activities.MainActivity;
import com.qboxus.hugmeapp.activitiesandfragments.activities.SearchPlacesA;
import com.qboxus.hugmeapp.adapters.CardAdapter;
import com.qboxus.hugmeapp.bottomsheet.SwipeProfileBottomSheet;
import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.codeclasses.RootFragment;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.MainF;
import com.qboxus.hugmeapp.databinding.FragmentSwipeTabBinding;
import com.yuyakaido.android.cardstackview.CardStackView;
import com.yuyakaido.android.cardstackview.SwipeDirection;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SwipeTabF extends RootFragment {


    public static String tokenOtherUser;
    public static ArrayList<Object> removedUserIdsIndex = new ArrayList<>();
    public static TextView searchPlace;
    public CardAdapter adapter;
    String userIdOfSwipe;
    String searchGender, searchFilterBy, searchDistance;
    List<UserModel> nearbyList = new ArrayList<>();
    String userId="";
    public FragmentSwipeTabBinding binding;

    public static void updatedataOnLeftSwipe(Context context, final UserModel item) {
        try {
            Functions.countNumClick(context);
            Functions.displayFbAd(context);
        } catch (Exception b) {
            b.printStackTrace();
        }

        Functions.sendPushNotification(context, item.getFbId(), "dislike you", "dislike");

        final DatabaseReference rootref = FirebaseDatabase.getInstance().getReference();

        final String userId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("hh");
        final String formattedDate = df.format(c);

        rootref.child("Match").child(item.getFbId()).child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map mymap = new HashMap<>();
                    mymap.put("match", "false");
                    mymap.put("type", "dislike");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getFirstName());
                    mymap.put("effect", "true");


                    Map othermap = new HashMap<>();
                    othermap.put("match", "false");
                    othermap.put("type", "dislike");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", item.getFirstName());
                    othermap.put("effect", "false");

                    rootref.child("Match").child(userId + "/" + item.getFbId()).updateChildren(mymap);
                    rootref.child("Match").child(item.getFbId() + "/" + userId).updateChildren(othermap);


                } else {
                    Map mymap = new HashMap<>();
                    mymap.put("fragment_match", "false");
                    mymap.put("type", "dislike");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getFirstName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("fragment_match", "false");
                    othermap.put("type", "dislike");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", item.getFirstName());
                    othermap.put("effect", "false");

                    rootref.child("Match").child(userId + "/" + item.getFbId()).setValue(mymap);
                    rootref.child("Match").child(item.getFbId() + "/" + userId).setValue(othermap);

                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                //auto generated method stub
            }
        });

    }

    public static void updatedataOnrightSwipe(Context context, final UserModel item) {
        try {

            Functions.countNumClick(context);


            Functions.displayFbAd(context);
        } catch (Exception b) {

            b.printStackTrace();
        }


        Functions.sendPushNotification(context, item.getFbId(), "Like you", "like");

        final DatabaseReference rootref = FirebaseDatabase.getInstance().getReference();

        final String userId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        final String userName = Functions.getSharedPreference(context).getString(Variables.F_NAME,"");


        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("hh");
        final String formattedDate = df.format(c);

        Query query = rootref.child("Match").child(item.getFbId()).child(userId);
        query.keepSynced(true);

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists() || item.getSwipe().equals("like")) {
                    Map mymap = new HashMap<>();
                    mymap.put("fragment_match", "true");
                    mymap.put("type", "like");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getFirstName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("fragment_match", "true");
                    othermap.put("type", "like");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", userName);
                    othermap.put("effect", "false");

                    rootref.child("Match").child(userId + "/" + item.getFbId()).updateChildren(mymap);
                    rootref.child("Match").child(item.getFbId() + "/" + userId).updateChildren(othermap);

                } else {
                    Map mymap = new HashMap<>();
                    mymap.put("fragment_match", "false");
                    mymap.put("type", "like");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getFirstName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("fragment_match", "false");
                    othermap.put("type", "like");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", userName);
                    othermap.put("effect", "false");

                    rootref.child("Match").child(userId + "/" + item.getFbId()).setValue(mymap);
                    rootref.child("Match").child(item.getFbId() + "/" + userId).setValue(othermap);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                //auto generated method stub
            }
        });

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_swipe_tab, container,false);
        MainF.toolbar.setVisibility(View.GONE);

        nearbyList.clear();
        binding.controlIVId.setOnClickListener(v -> {
            displayFilterDialogue();

        });

        userId = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.FB_ID,"");


        Functions.getUserInfo("" + userId, binding.getRoot().getContext());

        binding.pulseView.changeSettingBtn.setOnClickListener(v -> {

            displayFilterDialogue();

        });


        String img = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.IMAGE1,"");
        binding.pulseView.profileimage.setController(Functions.frescoImageLoad(img,R.drawable.ic_avatar,binding.pulseView.profileimage,false));

        binding.swipeCsvId.setCardEventListener(new CardStackView.CardEventListener() {
            @Override
            public void onCardDragging(float percentX, float percentY) {
            }

            @Override
            public void onCardSwiped(SwipeDirection direction) {

                int orgIndex = binding.swipeCsvId.getTopIndex() - 1;

                if (orgIndex < adapter.getCount()) {

                    if (direction.equals(SwipeDirection.Left)) {
                        SwipeTabF.updatedataOnLeftSwipe(getContext(), adapter.getItem(orgIndex));
                    } else if (direction.equals(SwipeDirection.Right)) {
                        SwipeTabF.updatedataOnrightSwipe(getContext(), adapter.getItem(orgIndex));

                    }

                    if (binding.swipeCsvId.getTopIndex() == adapter.getCount()) {
                        binding.toolbar.setVisibility(View.VISIBLE);
                        binding.pulseView.findNearbyUser.setVisibility(View.VISIBLE);
                        binding.pulseView.pulsator.start();
                    }


                }


            }


            @Override
            public void onCardReversed() {
                //auto generated method stub
            }

            @Override
            public void onCardMovedToOrigin() {
                //auto generated method stub
            }

            @Override
            public void onCardClicked(int index) {

                UserModel getNearby = nearbyList.get(index);


                Bundle bundleUserProfile = new Bundle();
                bundleUserProfile.putString("user_id", "" + userIdOfSwipe);

                bundleUserProfile.putSerializable("user_near_by", getNearby);

                SwipeProfileBottomSheet viewProfile = new SwipeProfileBottomSheet(SwipeTabF.this);
                viewProfile.setArguments(bundleUserProfile);
                viewProfile.setCancelable(true);
                viewProfile.show(getActivity().getSupportFragmentManager(), viewProfile.getTag());


            }
        });


        initAdp();
        getNearByUsers();


        return binding.getRoot();
    }

    @Override
    public void setMenuVisibility(boolean isVisibleToUser) {
        super.setMenuVisibility(isVisibleToUser);
        if (isVisibleToUser) {

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {

                    MainF.toolbar.setVisibility(View.GONE);

                    if (Variables.isSearchedAtWw == 1) {
                        adapter.clear();
                        nearbyList.clear();
                        adapter.notifyDataSetChanged();

                        getNearByUsers();

                        Variables.isSearchedAtWw = 0;
                    }

                }
            },200);

        }
    }


    public void getNearByUsers() {

        binding.progressBar.setVisibility(View.VISIBLE);

        String search = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.SEARCH_PARAMS_JSON,"{}");
        String searchGender = "", searchAgeMin = "", searchAgeMax = "", searchDistance = "";
        try {

            JSONObject searchObj = new JSONObject(search);
            searchGender = searchObj.optString("gender", Constants.defalutGender);
            searchAgeMin = searchObj.optString("age_min", Constants.defalutMinAge);
            searchAgeMax = searchObj.optString("age_max", Constants.defalutMaxAge);
            searchDistance = searchObj.optString("search_distance", Constants.defalutMaxDistance);
        } catch (Exception n) {
            searchGender = Constants.defalutGender;
            searchAgeMin = Constants.defalutMinAge;
            searchAgeMax = Constants.defalutMaxAge;
            searchDistance = Constants.defalutMaxDistance;
            binding.progressBar.setVisibility(View.GONE);
        }


        final JSONObject parameters = new JSONObject();


        try {
            parameters.put("fb_id", userId);
            parameters.put("lat_long", Functions.getSharedPreference(binding.getRoot().getContext()).getFloat(Variables.LATITUDE,0f)+", "+Functions.getSharedPreference(binding.getRoot().getContext()).getFloat(Variables.LONGITUDE,0f));
            parameters.put("gender", searchGender);
            parameters.put("distance", searchDistance);
            parameters.put("device_token", Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.DEVICE_TOKEN,""));
            parameters.put("device", "android");
            parameters.put("age_min", searchAgeMin);
            parameters.put("age_max", searchAgeMax);
            parameters.put("version", BuildConfig.VERSION_NAME);
            if (MainActivity.purductPurchase)
                parameters.put("purchased", "1");
            else
                parameters.put("purchased", "0");

        } catch (Exception e) {

            e.printStackTrace();
            binding.progressBar.setVisibility(View.GONE);
        }

        ApiRequest.callApi(
                binding.getRoot().getContext(),
                "" + ApiLinks.userNearByMe,
                parameters,
                (requestType, resp) -> {

                    binding.progressBar.setVisibility(View.GONE);
                    Functions.logDMsg( "Near from Search \n " + parameters.toString());
                    Functions.logDMsg( "Near from Response  \n " + resp);
                    try {
                        JSONObject response = new JSONObject(resp);

                        JSONArray msgArr = response.getJSONArray("msg");

                        if (msgArr.length() == 0) {

                            binding.pulseView.findNearbyUser.setVisibility(View.VISIBLE);
                            binding.pulseView.pulsator.start();


                        } else {

                            adapter.clear();
                            nearbyList.clear();

                            binding.pulseView.findNearbyUser.setVisibility(View.GONE);

                            for (int i = 0; i < msgArr.length(); i++) {
                                JSONObject userObj = msgArr.getJSONObject(i);


                                UserModel nearby = ParseData.parseUserModel(userObj);
                                nearby.setSwipe("like");

                                adapter.add(nearby);
                                nearbyList.add(nearby);

                            }


                            adapter.notifyDataSetChanged();


                        }


                    } catch (Exception b) {
                        binding.progressBar.setVisibility(View.GONE);
                    }
                }
        );


    }


    public void displayFilterDialogue() {

        final Dialog dialog = new Dialog(getContext());

        final View dialogview = LayoutInflater.from(getContext()).inflate(R.layout.item_filter_dialog_layout, null);

        String handleSearch =  Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.SEARCH_PARAMS_JSON,"{}");

        String handleSearchGender = "", handleSearchFilterBy = "", handleSearchAgeMin = "", handleSearchAgeMax = "",
                handleSearchDistance = "";

        searchGender = Constants.defalutGender;
        searchFilterBy = Constants.defalutSearchByStatus;
        searchDistance = Constants.defalutMaxDistance;

        String userSearchPlace = Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.SEARCH_PLACE_NAME,"");


        final TextView filterText = dialogview.findViewById(R.id.filter_text);
        String sourceString = "<b>Filter</b> ";
        filterText.setText(Html.fromHtml(sourceString));

        final TextView tv = (TextView) dialogview.findViewById(R.id.guys_id);
        final TextView tv1 = (TextView) dialogview.findViewById(R.id.girls_id);
        final TextView tv2 = (TextView) dialogview.findViewById(R.id.both_id);

        final TextView tv4 = (TextView) dialogview.findViewById(R.id.all_id);
        final TextView tv5 = (TextView) dialogview.findViewById(R.id.online_id);
        final TextView tv6 = (TextView) dialogview.findViewById(R.id.new_id);

        searchPlace = dialogview.findViewById(R.id.search_place);
        if (!(TextUtils.isEmpty(userSearchPlace))) {
            // If it is not Null
            searchPlace.setText("" + userSearchPlace);
        } else {
            searchPlace.setText("People nearby");
        }


        final ImageView iv1 = (ImageView) dialogview.findViewById(R.id.dialog_cross_Id);
        final ImageView iv2 = (ImageView) dialogview.findViewById(R.id.dialog_tick_id);
        RangeBar rangeBar = (RangeBar) dialogview.findViewById(R.id.ww_RB_id);

        RelativeLayout nearByRlId = dialogview.findViewById(R.id.near_by_RL_id);


        nearByRlId.setOnClickListener(v -> {

            startActivity(new Intent(getActivity(), SearchPlacesA.class));

        });


        final TextView textAge = dialogview.findViewById(R.id.text_age);
        final TextView distance = dialogview.findViewById(R.id.distance);
        SeekBar simpleSeekBar = dialogview.findViewById(R.id.simpleSeekBar);
        simpleSeekBar.setProgress(Integer.parseInt(Constants.defalutMaxDistance));
        distance.setText("" + simpleSeekBar.getProgress());
        dialog.setContentView(dialogview);

        if (handleSearch != null) {

            try {

                JSONObject searchObj = new JSONObject(handleSearch);
                handleSearchGender = searchObj.getString("gender");
                handleSearchFilterBy = searchObj.getString("filter_by");
                handleSearchAgeMin = searchObj.getString("age_min");
                handleSearchAgeMax = searchObj.getString("age_max");
                handleSearchDistance = searchObj.getString("search_distance");

                textAge.setText(handleSearchAgeMin + " - " + handleSearchAgeMax);

                rangeBar.setRangePinsByValue(Float.parseFloat(handleSearchAgeMin), Float.parseFloat(handleSearchAgeMax));

            } catch (Exception b) {
                b.printStackTrace();
            }

            searchDistance = handleSearchDistance;
            searchGender = handleSearchGender;
            try {
                if (handleSearchDistance != null) {
                    simpleSeekBar.setProgress(Integer.parseInt(handleSearchDistance));
                    distance.setText(handleSearchDistance);
                } else {
                    distance.setText(Constants.defalutMaxDistance);
                    simpleSeekBar.setProgress(Integer.parseInt(Constants.defalutMaxDistance));
                }

            } catch (Exception b) {
                b.printStackTrace();
            }

            if (handleSearchGender.equals("female")) {
                tv1.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
                tv.setBackgroundResource(R.drawable.d_gray_border);
                tv2.setBackgroundResource(R.drawable.d_gray_border);
            } else if (handleSearchGender.equals("male")) {
                tv1.setBackgroundResource(R.drawable.d_gray_border);
                tv.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
                tv2.setBackgroundResource(R.drawable.d_gray_border);
            } else {

                tv1.setBackgroundResource(R.drawable.d_gray_border);
                tv.setBackgroundResource(R.drawable.d_gray_border);
                tv2.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            }


            if (handleSearchFilterBy.equals("All")) {

                tv4.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
                tv5.setBackgroundResource(R.drawable.d_gray_border);
                tv6.setBackgroundResource(R.drawable.d_gray_border);

            } else if (handleSearchFilterBy.equals("Online")) {
                tv4.setBackgroundResource(R.drawable.d_gray_border);
                tv5.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
                tv6.setBackgroundResource(R.drawable.d_gray_border);

            } else {
                tv4.setBackgroundResource(R.drawable.d_gray_border);
                tv5.setBackgroundResource(R.drawable.d_gray_border);
                tv6.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            }

        }


        simpleSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                distance.setText("" + progress);
                searchDistance = "" + progress + "";
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //auto generated method stub
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //auto generated method stub
            }
        });


        try {
            rangeBar.setOnRangeBarChangeListener((rangeBar1, leftPinIndex, rightPinIndex, leftPinValue, rightPinValue) -> {
                textAge.setText("" + leftPinValue + " - " + "" + rightPinValue);
            });

        } catch (Exception b) {
            b.printStackTrace();
        }


        tv.setOnClickListener(v -> {
            tv.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv1.setBackgroundResource(R.drawable.d_gray_border);
            tv2.setBackgroundResource(R.drawable.d_gray_border);
            addGender(tv);

        });


        tv1.setOnClickListener(v -> {
            tv1.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv.setBackgroundResource(R.drawable.d_gray_border);
            tv2.setBackgroundResource(R.drawable.d_gray_border);
            addGender(tv1);

        });


        tv2.setOnClickListener(v -> {
            tv2.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv.setBackgroundResource(R.drawable.d_gray_border);
            tv1.setBackgroundResource(R.drawable.d_gray_border);
            addGender(tv2);

        });


        tv4.setOnClickListener(v -> {
            tv4.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv5.setBackgroundResource(R.drawable.d_gray_border);
            tv6.setBackgroundResource(R.drawable.d_gray_border);
            addAllFilter(tv4);

        });


        tv5.setOnClickListener(v -> {
            tv5.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv4.setBackgroundResource(R.drawable.d_gray_border);
            tv6.setBackgroundResource(R.drawable.d_gray_border);
            addAllFilter(tv5);  //get Value from All Filter

        });


        tv6.setOnClickListener(v -> {
            tv6.setBackgroundResource(R.drawable.d_round_blue_border_radius8);
            tv5.setBackgroundResource(R.drawable.d_gray_border);
            tv4.setBackgroundResource(R.drawable.d_gray_border);
            addAllFilter(tv6);  //get Value from All Filter
        });


        iv1.setOnClickListener(v -> {
            dialog.dismiss();
        });


        iv2.setOnClickListener(v -> {
            try {
                JSONObject searchParams = new JSONObject();
                searchParams.put("gender", "" + searchGender);
                searchParams.put("filter_by", "" + searchFilterBy);
                searchParams.put("age_min", "" + rangeBar.getLeftPinValue());
                searchParams.put("age_max", "" + rangeBar.getRightPinValue());
                searchParams.put("search_distance", "" + searchDistance);

                Functions.getSharedPreference(binding.getRoot().getContext()).edit().putString(Variables.SEARCH_PARAMS_JSON,"" + searchParams).commit();

            } catch (Exception b) {
                b.printStackTrace();

            }

            Variables.isSearched = 1;

            getNearByUsers();
            dialog.dismiss();

        });

        dialog.show();


    }

    public void addGender(TextView textView) {
        searchGender = textView.getText().toString();

        if (searchGender.equals("Male")) {
            searchGender = "male";
        } else if (searchGender.equals("Female")) {
            searchGender = "female";
        } else if (searchGender.equals("Both")) {
            searchGender = "all";
        }

    }


    public void addAllFilter(TextView textView) {
        searchFilterBy = textView.getText().toString();
    }


    public void initAdp() {

        adapter = new CardAdapter(binding.getRoot().getContext(), 0, new AdapterClickListener() {
            @Override
            public void onItemClick(int postion, Object model, View view) {

                if (view.getId() == R.id.right_overlay) {
                    swipeRight();
                } else if (view.getId() == R.id.left_overlay) {

                    swipeLeft();
                }
            }

            @Override
            public void onLongItemClick(int postion, Object model, View view) {
                    //auto generated method
            }
        }, nearbyList);

        binding.swipeCsvId.setAdapter(adapter);

    }


    public void swipeLeft() {
        View target = binding.swipeCsvId.getTopView();
        View targetOverlay = binding.swipeCsvId.getTopView().getOverlayContainer();

        ValueAnimator rotation = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("rotation", -10f));
        rotation.setDuration(200);
        ValueAnimator translateX = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("translationX", 0f, -2000f));
        ValueAnimator translateY = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("translationY", 0f, 500f));
        translateX.setStartDelay(400);
        translateY.setStartDelay(400);
        translateX.setDuration(500);
        translateY.setDuration(500);
        AnimatorSet cardAnimationSet = new AnimatorSet();
        cardAnimationSet.playTogether(rotation, translateX, translateY);

        ObjectAnimator overlayAnimator = ObjectAnimator.ofFloat(targetOverlay, "alpha", 0f, 1f);
        overlayAnimator.setDuration(200);
        AnimatorSet overlayAnimationSet = new AnimatorSet();
        overlayAnimationSet.playTogether(overlayAnimator);

        binding.swipeCsvId.swipe(SwipeDirection.Left, cardAnimationSet, overlayAnimationSet);

    }


    public void swipeRight() {

        View target = binding.swipeCsvId.getTopView();
        View targetOverlay = binding.swipeCsvId.getTopView().getOverlayContainer();

        ValueAnimator rotation = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("rotation", 10f));
        rotation.setDuration(200);
        ValueAnimator translateX = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("translationX", 0f, 2000f));
        ValueAnimator translateY = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("translationY", 0f, 500f));
        translateX.setStartDelay(400);
        translateY.setStartDelay(400);
        translateX.setDuration(500);
        translateY.setDuration(500);
        AnimatorSet cardAnimationSet = new AnimatorSet();
        cardAnimationSet.playTogether(rotation, translateX, translateY);

        ObjectAnimator overlayAnimator = ObjectAnimator.ofFloat(targetOverlay, "alpha", 0f, 1f);
        overlayAnimator.setDuration(200);
        AnimatorSet overlayAnimationSet = new AnimatorSet();
        overlayAnimationSet.playTogether(overlayAnimator);

        binding.swipeCsvId.swipe(SwipeDirection.Right, cardAnimationSet, overlayAnimationSet);
    }


}
