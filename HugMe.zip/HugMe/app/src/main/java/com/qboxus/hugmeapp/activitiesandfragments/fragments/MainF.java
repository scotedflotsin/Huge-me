package com.qboxus.hugmeapp.activitiesandfragments.fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.material.tabs.TabLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import com.qboxus.hugmeapp.adapters.VPAdapter;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs.InboxTabF;
import com.qboxus.hugmeapp.activitiesandfragments.activities.EditProfileA;
import com.qboxus.hugmeapp.codeclasses.RootFragment;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.activitiesandfragments.activities.SettingA;
import com.qboxus.hugmeapp.codeclasses.CustomViewPager;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs.LiveUsersTabF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs.ProfileTabF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs.SwipeTabF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.tabs.WorldWideNativeAdsTabF;


public class MainF extends RootFragment {

    View v;
    public static Toolbar toolbar;
    public  TabLayout tabLayout;
    public CustomViewPager viewPager;
    VPAdapter adp;
    ImageView iv2, iv3;
    Context context;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable final Bundle savedInstanceState) {
        v = LayoutInflater.from(getContext()).inflate(R.layout.fragment_main, container,false);
        context = getContext();
        toolbar = (Toolbar) v.findViewById(R.id.toolbar);
        tabLayout = (TabLayout) v.findViewById(R.id.tablayout_id);
        viewPager = v.findViewById(R.id.main_f_vp_id);



        iv2 = (ImageView) v.findViewById(R.id.main_f_setting_id);
        iv3 = (ImageView) v.findViewById(R.id.main_f_edit_id);


        toolbar.setVisibility(View.GONE);
        adp = new VPAdapter(getChildFragmentManager());
        adp.addFragment(new WorldWideNativeAdsTabF(), "");
        adp.addFragment(new LiveUsersTabF(), "");
        adp.addFragment(new SwipeTabF(), "");
        adp.addFragment(new InboxTabF(), "");
        adp.addFragment(new ProfileTabF(), "");

        viewPager.setAdapter(adp);
        viewPager.setOffscreenPageLimit(4);
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setPagingEnabled(false);

        final View view1 = LayoutInflater.from(getContext()).inflate(R.layout.custom_tab_icons, null);
        ImageView imageView1 = (ImageView) view1.findViewById(R.id.CTI_IV_id);
        imageView1.setImageResource(R.drawable.ic_world_gray);
        tabLayout.getTabAt(0).setCustomView(view1);

        final View view5 = LayoutInflater.from(getContext()).inflate(R.layout.custom_tab_icons, null);
        ImageView imageView5 = (ImageView) view5.findViewById(R.id.CTI_IV_id);
        imageView5.setImageResource(R.drawable.ic_live_black);
        tabLayout.getTabAt(1).setCustomView(view5);


        final View view2 = LayoutInflater.from(getContext()).inflate(R.layout.custom_tab_icons, null);
        ImageView imageView22 = (ImageView) view2.findViewById(R.id.CTI_IV_id);
        imageView22.setImageResource(R.drawable.ic_card_color);
        tabLayout.getTabAt(2).setCustomView(view2);

        final View view3 = LayoutInflater.from(getContext()).inflate(R.layout.custom_tab_icons, null);
        ImageView imageView3 = (ImageView) view3.findViewById(R.id.CTI_IV_id);
        imageView3.setImageResource(R.drawable.ic_chat_gray);
        tabLayout.getTabAt(3).setCustomView(view3);

        final View view4 = LayoutInflater.from(getContext()).inflate(R.layout.custom_tab_icons, null);
        ImageView imageView4 = (ImageView) view4.findViewById(R.id.CTI_IV_id);
        imageView4.setImageResource(R.drawable.ic_profile_gray);
        tabLayout.getTabAt(4).setCustomView(view4);


        tabLayout.addOnTabSelectedListener(new TabLayout.BaseOnTabSelectedListener() {

            @SuppressLint("RestrictedApi")
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                View view = tab.getCustomView();
                ImageView image = view.findViewById(R.id.CTI_IV_id);
                switch (tab.getPosition()){
                    case 0:
                        image.setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.ic_world_color));
                        MainF.toolbar.setVisibility(View.GONE);
                        break;

                    case 1:
                        image.setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.ic_live_color));
                        MainF.toolbar.setVisibility(View.VISIBLE);
                        break;
                    case 2:
                        image.setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.ic_card_color));
                        MainF.toolbar.setVisibility(View.GONE);
                        break;

                    case 3:
                        image.setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.ic_chat_color));
                        MainF.toolbar.setVisibility(View.VISIBLE);
                        break;

                    case 4:
                        image.setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.ic_profile_color));
                        iv2.setVisibility(View.VISIBLE);
                        iv3.setVisibility(View.VISIBLE);
                        MainF.toolbar.setVisibility(View.VISIBLE);
                        break;

                    default:
                        break;

                }
                tab.setCustomView(view);

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View view = tab.getCustomView();
                ImageView image = view.findViewById(R.id.CTI_IV_id);

                switch (tab.getPosition()){
                    case 0:
                        image.setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.ic_world_gray));
                        break;

                    case 1:
                        image.setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.ic_live_black));
                        break;
                    case 2:
                        image.setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.ic_card_gray));
                        break;

                    case 3:
                        image.setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.ic_chat_gray));
                        break;

                    case 4:
                        image.setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.ic_profile_gray));
                        iv2.setVisibility(View.GONE);
                        iv3.setVisibility(View.GONE);
                        break;

                    default:
                        break;

                }

                tab.setCustomView(view);

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

        });






        tabLayout.getTabAt(2).select();





        iv2.setOnClickListener(v-> {
                startActivity(new Intent(getActivity(), SettingA.class));

        });




        iv3.setOnClickListener(v ->  {
                startActivity(new Intent(getActivity(), EditProfileA.class));

        });



        return v;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        getActivity().finish();
    }


    @Override
    public void setMenuVisibility(boolean isVisibleToUser) {
        super.setMenuVisibility(isVisibleToUser);
        if (isVisibleToUser) {
            MainF.toolbar.setVisibility(View.GONE);
        }
    }


}
