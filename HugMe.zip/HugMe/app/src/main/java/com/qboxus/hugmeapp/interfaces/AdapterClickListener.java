package com.qboxus.hugmeapp.interfaces;

import android.view.View;

public interface AdapterClickListener {
    void onItemClick(View view, int pos, Object object);
}
