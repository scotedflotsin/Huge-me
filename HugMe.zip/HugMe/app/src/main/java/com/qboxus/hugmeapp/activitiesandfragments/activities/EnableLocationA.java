package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.PermissionUtils;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.databinding.ActivityEnableLocationBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EnableLocationA extends AppCompatLocaleActivity {

    StorageReference storageReference;
    PermissionUtils takePermissionUtils;
    ActivityEnableLocationBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        binding= DataBindingUtil.setContentView(this,R.layout.activity_enable_location);
        storageReference = FirebaseStorage.getInstance().getReference();

        binding.btnLocation.setOnClickListener(v -> {

            takePermissionUtils = new PermissionUtils(EnableLocationA.this, mPermissionLocationResult);
            if (takePermissionUtils.isLocationPermissionGranted()) {
                binding.btnLocation.setEnabled(false);
                binding.btnLocation.setClickable(false);
                getGPSLocationData();
            } else {
                enableLocationByActivity();
            }

            Functions.logDMsg("enable location called called123");
            binding.btnLocation.setEnabled(false);
            binding.btnLocation.setClickable(false);

        });

    }

    private void getGPSLocationData() {
        Functions.showLoader(binding.getRoot().getContext(),false,false);
        FusedLocationProviderClient mFusedLocationClient = LocationServices.getFusedLocationProviderClient(binding.getRoot().getContext());
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            binding.btnLocation.setEnabled(true);
            binding.btnLocation.setClickable(true);
            return;
        }
        mFusedLocationClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                Functions.cancelLoader();
                // Got last known location. In some rare situations this can be null.
                if (location != null) {
                    try {

                        Functions.logDMsg("Lat "+location.getLatitude());
                        Functions.logDMsg("Lng "+location.getLongitude());
                        goNext(location);
                    } catch (Exception e) {
                        binding.btnLocation.setEnabled(true);
                        binding.btnLocation.setClickable(true);
                        Functions.logDMsg( "Exception : " + e);
                    }
                }
                else
                {
                    enableLocationByActivity();
                }
            }
        });
    }

    private void enableLocationByActivity() {
        binding.btnLocation.setEnabled(true);
        binding.btnLocation.setClickable(true);
        takePermissionUtils.showLocationPermissionDailog(binding.getRoot().getContext().getString(R.string.you_ll_need_to_enable_your_location_n_in_order_to_use_hugme));
    }


    private ActivityResultLauncher<String[]> mPermissionLocationResult = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onActivityResult(Map<String, Boolean> result) {

                    boolean allPermissionClear = true;
                    List<String> blockPermissionCheck = new ArrayList<>();
                    for (String key : result.keySet()) {
                        if (!(result.get(key))) {
                            allPermissionClear = false;
                            blockPermissionCheck.add(Functions.getPermissionStatus(EnableLocationA.this, key));
                        }
                    }
                    if (blockPermissionCheck.contains("blocked")) {
                        Functions.showPermissionSetting(binding.getRoot().getContext(), getString(R.string.we_need_location_permission_to_give_you_better_app_experience));
                    } else if (allPermissionClear) {
                        getGPSLocationData();
                    }

                }
            });










    public void goNext(Location location) {
        Functions.logDMsg("enable location called");
        if (location != null) {

            Functions.getSharedPreference(binding.getRoot().getContext()).edit()
                    .putFloat(Variables.LATITUDE, (float) location.getLatitude()).commit();
            Functions.getSharedPreference(binding.getRoot().getContext()).edit()
                    .putFloat(Variables.LONGITUDE, (float) location.getLongitude()).commit();


            if (Functions.checkLoginUser(EnableLocationA.this))
            {
                Intent intent = new Intent(binding.getRoot().getContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        }

    }

}
