package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.klinker.android.link_builder.Link;
import com.klinker.android.link_builder.LinkBuilder;
import com.klinker.android.link_builder.TouchableMovementMethod;
import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.volleypackage.CallBack;
import com.qboxus.hugmeapp.databinding.ActivityLoginBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LoginA extends AppCompatLocaleActivity {

    private static final String EMAIL = "email";
    String name, email, userId, password, imgUrl;
    private CallbackManager callbackManager;
    private AccessToken mAccessToken;
    private GoogleSignInClient googleSignInClient;
    ActivityLoginBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        callbackManager = CallbackManager.Factory.create();
        binding= DataBindingUtil.setContentView(this,R.layout.activity_login);


         findViewById(R.id.phone_login_layout).setOnClickListener(v -> {

            startActivity(new Intent(LoginA.this, LoginPhoneA.class));
            overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
        });

         findViewById(R.id.email_login_layout).setOnClickListener(v -> {

             startActivity(new Intent(LoginA.this, EmailLoginA.class));
             overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
        });


        googleSignIn();

        binding.FrameLayout1.setOnClickListener(v -> {
            binding.loginDetailsFbIVId.performClick();
        });

        binding.FrameLayout2.setOnClickListener(v -> {
            Intent signInIntent = googleSignInClient.getSignInIntent();
            resultCallbackForGoogle.launch(signInIntent);
        });


        binding.loginDetailsFbIVId.setPermissions(Arrays.asList(EMAIL));

        binding.loginDetailsFbIVId.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                mAccessToken = loginResult.getAccessToken();
                getUserProfile(mAccessToken);

            }

            @Override
            public void onCancel() {
                Functions.toastMsg(LoginA.this, "You cancel this.");
            }

            @Override
            public void onError(FacebookException error) {
                Functions.toastMsg(LoginA.this, "err " + error.toString());

            }
        });


        printKeyHash();


        SetupScreenData();

    }




    TextView login_terms_condition_txt;
    List<Link> links = new ArrayList<>();
    private void SetupScreenData() {
        login_terms_condition_txt =findViewById(R.id.login_terms_condition_txt);

        Link link = new Link(getString(R.string.terms_of_use));
        link.setTextColor(ContextCompat.getColor(this,R.color.black));
        link.setTextColorOfHighlightedLink(ContextCompat.getColor(this,R.color.colorPrimary));
        link.setUnderlined(true);
        link.setBold(false);
        link.setHighlightAlpha(.20f);
        link.setOnClickListener(new Link.OnClickListener() {
            @Override
            public void onClick(String clickedText) {
                openWebUrl(getString(R.string.terms_of_use),ApiLinks.App_Privacy_Policy_new);
            }
        });

        Link link2 = new Link(getString(R.string.privacy_policy));
        link2.setTextColor(ContextCompat.getColor(this,R.color.black));
        link2.setTextColorOfHighlightedLink(ContextCompat.getColor(this,R.color.colorPrimary));
        link2.setUnderlined(true);
        link2.setBold(false);
        link2.setHighlightAlpha(.20f);
        link2.setOnClickListener(new Link.OnClickListener() {
            @Override
            public void onClick(String clickedText) {
                openWebUrl(getString(R.string.privacy_policy),ApiLinks.App_Privacy_Policy_new);
            }
        });
        links.add(link);
        links.add(link2);
        CharSequence sequence = LinkBuilder.from(this, login_terms_condition_txt.getText().toString())
                .addLinks(links)
                .build();
        login_terms_condition_txt.setText(sequence);
        login_terms_condition_txt.setMovementMethod(TouchableMovementMethod.getInstance());
    }




    public void openWebUrl(String title, String url) {
        Intent intent=new Intent(this, WebviewA.class);
        intent.putExtra("url", url);
        intent.putExtra("title", title);
        startActivity(intent);
        overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
    }


    ActivityResultLauncher<Intent> resultCallbackForGoogle = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        handleSignInResult(Auth.GoogleSignInApi.getSignInResultFromIntent(data));
                    }
                }
            });

    private void getUserProfile(AccessToken currentAccessToken) {
        GraphRequest request = GraphRequest.newMeRequest(
                currentAccessToken,
                (object, response) -> {
                    try {
                        String fbUserId = object.getString("id");
                        userId = fbUserId;
                        String imgurl = "https://graph.facebook.com/" + object.getString("id") + "/picture?width=500";
                        String fbName = object.getString("name");
                        String fbEmail = object.getString("email");



                        JSONObject fbDataJson = new JSONObject();
                        fbDataJson.put("name", fbName);
                        fbDataJson.put("email", fbEmail);
                        fbDataJson.put("user_id", fbUserId);
                        fbDataJson.put("img_url", imgurl);


                        Functions.getSharedPreference(binding.getRoot().getContext()).edit().putString(Variables.SOCIAL_INFO_JSON,""+fbDataJson).commit();
                        getuserInfo(userId, fbDataJson);


                        LoginManager.getInstance().logOut();

                    } catch (Exception e) {
                        e.printStackTrace();
                        Functions.toastMsg(LoginA.this, "Error " + e.toString());
                    }
                });

        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,email,picture");
        request.setParameters(parameters);
        request.executeAsync();

    }

    public void googleSignIn() {

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(this, gso);

    }

    private void handleSignInResult(GoogleSignInResult result) {

        if (result.isSuccess()) {

            GoogleSignInAccount acct = result.getSignInAccount();

            try {
                name = acct.getDisplayName();
                userId = acct.getId();
                if (acct.getPhotoUrl() != null) {
                    imgUrl = acct.getPhotoUrl().toString();
                } else {
                    imgUrl = "";
                }

                email = acct.getEmail();
                name = acct.getDisplayName();
                password = acct.getId();

                try {
                    JSONObject msgsJson = new JSONObject();
                    msgsJson.put("name", name);
                    msgsJson.put("email", email);
                    msgsJson.put("user_id", userId);
                    msgsJson.put("img_url", imgUrl);


                    // Check if user ALready member or not
                    getuserInfo(userId, msgsJson);


                } catch (Exception b) {
                    b.printStackTrace();
                }


            } catch (Exception v) {
                Functions.toastMsg(LoginA.this, "exception at handle : " + v.toString());

            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }


    public void getuserInfo(final String user_id, final JSONObject msgsJson) {
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", user_id);

        } catch (Exception e) {
            e.printStackTrace();
        }

        Functions.logDMsg("params at login : "+user_id);
        ApiRequest.callApi(
                binding.getRoot().getContext(),
                ApiLinks.getUserInfo,
                parameters,
                new CallBack() {
                    @RequiresApi(api = Build.VERSION_CODES.M)
                    @Override
                    public void getResponse(String requestType, String resp) {
                        Functions.logDMsg("resp at login : "+resp);
                        try {
                            JSONObject response = new JSONObject(resp);
                            if (response.getString("code").equals("200")) {


                                JSONArray msgObj = response.getJSONArray("msg");
                                JSONObject userInfoObj = msgObj.getJSONObject(0);

                                UserModel userdetailModel= ParseData.parseUserModel(userInfoObj);
                                Functions.storeUserLoginDataIntoDb(binding.getRoot().getContext(),userdetailModel);

                                Functions.getSharedPreference(binding.getRoot().getContext()).edit().putString(Variables.FB_ID,""+user_id).commit();

                                Functions.getSharedPreference(binding.getRoot().getContext()).edit().putString(Variables.SOCIAL_INFO_JSON,"").commit();
                                openEnableLocation();


                            } else {
                                Functions.getSharedPreference(binding.getRoot().getContext()).edit().putString(Variables.SOCIAL_INFO_JSON,""+msgsJson).commit();
                                startActivity(new Intent(LoginA.this, SegmentsA.class));
                            }
                        } catch (Exception b) {
                            Functions.toastMsg(binding.getRoot().getContext(), "getuserInfo exception : " + b.toString());
                        }

                    }
                }
        );
    }

    public void openEnableLocation() {
        startActivity(new Intent(binding.getRoot().getContext(), EnableLocationA.class));
        overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
        finish();
    }


    public void printKeyHash() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.i("keyhash", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }


}
