package com.qboxus.hugmeapp.volleypackage;

public interface CallBack {
    void getResponse(String requestType, String response);
}
