package com.qboxus.hugmeapp.codeclasses;

import androidx.fragment.app.Fragment;

import com.qboxus.hugmeapp.interfaces.OnBackPressListener;

/**
 * Created by qboxus on 3/30/2018.
 */

public class RootFragment extends Fragment implements OnBackPressListener {

    @Override
    public boolean onBackPressed() {
        return new BackPressImplimentation(this).onBackPressed();
    }
}