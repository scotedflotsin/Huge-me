package com.qboxus.hugmeapp.interfaces;

public interface InternetCheckCallback {
    void GetResponse(String requestType, String response);
}
