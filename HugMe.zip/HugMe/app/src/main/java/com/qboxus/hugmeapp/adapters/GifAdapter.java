package com.qboxus.hugmeapp.adapters;

import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import com.facebook.drawee.view.SimpleDraweeView;
import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;

public class GifAdapter extends RecyclerView.Adapter<GifAdapter.CustomViewHolder > {

    public Context context;
    ArrayList<String> gifList;

    AdapterClickListener adapterClicklistener;

    public GifAdapter(Context context, ArrayList<String> urllist, AdapterClickListener adapterClicklistener) {
        this.context = context;
        this.gifList =urllist;
        this.adapterClicklistener = adapterClicklistener;

    }

    @Override
    public GifAdapter.CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewtype) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_gif_layout,null);
        GifAdapter.CustomViewHolder viewHolder = new GifAdapter.CustomViewHolder(view);
        return viewHolder;
    }

    @Override
    public int getItemCount() {
        return gifList.size();
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {
        SimpleDraweeView gifImage;

        public CustomViewHolder(View view) {
            super(view);
            gifImage =view.findViewById(R.id.gif_image);
        }

        public void bind(final int pos, final String item, final AdapterClickListener listener) {

            itemView.setOnClickListener(v->{
                    listener.onItemClick(pos,item,v);

            });


        }

    }


    @Override
    public void onBindViewHolder(final GifAdapter.CustomViewHolder holder, final int i) {
        holder.bind(i, gifList.get(i), adapterClicklistener);

        holder.gifImage.setController(Functions.frescoImageLoad(Variables.gifFirstpart + gifList.get(i)+ Variables.gifSecondpart,
                R.drawable.image_placeholder,holder.gifImage,false));
    }

}
