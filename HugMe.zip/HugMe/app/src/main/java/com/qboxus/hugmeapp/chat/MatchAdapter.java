package com.qboxus.hugmeapp.chat;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.qboxus.hugmeapp.activitiesandfragments.activities.ChatA;
import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.models.MatchModel;
import com.qboxus.hugmeapp.R;

import java.util.List;

public class MatchAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final static int LIKE_ITEM = 0;
    private final static int MATCH_LIST = 1;
    MatchModel matchModel;
    Context context;
    List<MatchModel> listMyMatch;
    List<MatchModel> likeList;
    AdapterClickListener adapterClickListener;
    public MatchAdapter(Context context, List<MatchModel> myMatch, List<MatchModel> listMyMatch, AdapterClickListener adapterClickListener) {
        this.context = context;
        this.listMyMatch = myMatch;
        this.likeList = listMyMatch;
        this.adapterClickListener = adapterClickListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == LIKE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_like_layout, parent, false);
            return new LiveViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_match_layout, parent, false);
            return new ViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int i) {
        final MatchModel myMatch = listMyMatch.get(i);

        if (i == 0) {
            matchModel = likeList.get(i);
        }

        if (holder.getItemViewType() == LIKE_ITEM) {
            LiveViewHolder viewHolder = (LiveViewHolder) holder;
            if (matchModel.totalCount != null) {
                int count = Integer.parseInt(matchModel.totalCount);
                if (count > 0) {
                    viewHolder.likeLayoutCount.setVisibility(View.VISIBLE);
                    viewHolder.likesCountTxt.setText(""+count);
                    String imageUrl = matchModel.likeImage;
                    if (imageUrl != null && !imageUrl.equals("")) {
                        Uri uri = Uri.parse(imageUrl);
                        viewHolder.likesImage.setImageURI(uri);
                    }
                } else {
                    viewHolder.likeLayoutCount.setVisibility(View.GONE);
                }
            }
            viewHolder.likeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    adapterClickListener.onItemClick(i,matchModel,v);
                }
            });
        } else {

            ViewHolder viewHolder = (ViewHolder) holder;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                viewHolder.iv.setClipToOutline(true);
            }

            try {
                Uri uri = Uri.parse(myMatch.getPicture());
                viewHolder.iv.setImageURI(uri);
            } catch (Exception v) {
                v.printStackTrace();
            }

            viewHolder.iv.setOnClickListener(v -> {
                Intent myIntent = new Intent(context, ChatA.class);
                myIntent.putExtra("receiver_id", myMatch.getuId());
                myIntent.putExtra("receiver_name", myMatch.getUsername());
                myIntent.putExtra("receiver_pic", myMatch.getPicture());
                myIntent.putExtra("match_api_run", "1");
                myIntent.putExtra("position_to_remove", "" + i);
                myIntent.putExtra("is_block", "0");
                context.startActivity(myIntent);
            });
        }
    }

    @Override
    public int getItemViewType(int position) {
        return position < 1 ? LIKE_ITEM : MATCH_LIST;
    }

    @Override
    public int getItemCount() {
        return listMyMatch.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView addPhoto;
        SimpleDraweeView iv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            iv = itemView.findViewById(R.id.chat_item_IV_id);
            addPhoto = itemView.findViewById(R.id.add_photo_img_id);

        }
    }


    public class LiveViewHolder extends RecyclerView.ViewHolder {
        SimpleDraweeView likesImage;
        TextView likesCountTxt;
        RelativeLayout likeLayout, likeLayoutCount;

        public LiveViewHolder(View itemView) {
            super(itemView);
            likesImage = itemView.findViewById(R.id.imageview_id);
            likesCountTxt = itemView.findViewById(R.id.tv_like_count);
            likeLayout = itemView.findViewById(R.id.like_layout);
            likeLayoutCount = itemView.findViewById(R.id.like_layout_count);
        }
    }
}
