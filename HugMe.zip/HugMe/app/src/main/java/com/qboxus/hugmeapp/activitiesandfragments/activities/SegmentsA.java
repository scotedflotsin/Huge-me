package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.os.Bundle;

import androidx.viewpager.widget.ViewPager;

import com.carlosmuvi.segmentedprogressbar.SegmentedProgressBar;
import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.adapters.SegmentAdapter;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.loginsteps.SegmentAddPicF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.loginsteps.SegmentDOBF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.loginsteps.SegmentEmailF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.loginsteps.SegmentGenderF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.loginsteps.SegmentNameF;
import com.qboxus.hugmeapp.R;

public class SegmentsA extends AppCompatLocaleActivity {

    public static SegmentedProgressBar segmentedProgressBar;
    public static ViewPager viewPager;
    SegmentAdapter segmentAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        setContentView(R.layout.activity_segments);

        segmentedProgressBar = (SegmentedProgressBar) findViewById(R.id.segment_bar_id);
        viewPager = (ViewPager) findViewById(R.id.view_pager_id);
        viewPager.setOffscreenPageLimit(5);


        segmentAdapter = new SegmentAdapter(getSupportFragmentManager());
        segmentAdapter.addFragment(new SegmentGenderF(), "");
        segmentAdapter.addFragment(new SegmentNameF(), "");
        segmentAdapter.addFragment(new SegmentDOBF(), "");
        segmentAdapter.addFragment(new SegmentEmailF(), "");
        segmentAdapter.addFragment(new SegmentAddPicF(), "");

        viewPager.setAdapter(segmentAdapter);
        segmentedProgressBar.setCompletedSegments(1);

        viewPager.setOnTouchListener((v, event) -> {
            viewPager.setCurrentItem(viewPager.getCurrentItem());
            return true;
        });

    }

    @Override
    public void onBackPressed() {

        if (viewPager.getCurrentItem() == 0) {
            super.onBackPressed();
        } else {
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
        }

    }

}
