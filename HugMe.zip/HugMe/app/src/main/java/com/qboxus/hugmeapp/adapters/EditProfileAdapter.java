package com.qboxus.hugmeapp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.R;

import java.util.List;

public class EditProfileAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public final int imageType = 1;
    public final int browseType = 2;
    List<String> listUserImage;
    AdapterClickListener adapterClickListener;

    public EditProfileAdapter(List<String> listUserImage, AdapterClickListener adapterClickListener) {
        this.adapterClickListener = adapterClickListener;
        this.listUserImage = listUserImage;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewtype) {
        View v;
        if (viewtype == imageType) {
            v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_edit_prof, viewGroup,false);
            return new EditProViewHolder(v);
        } else {
            v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_browse_profile_image, viewGroup,false);
            return new BrowseProViewHolder(v);
        }


    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder viewHolder, final int i) {
        String imgUrl=listUserImage.get(i);
        if (viewHolder instanceof EditProViewHolder)
        {
            EditProViewHolder holder=(EditProViewHolder) viewHolder;
            if (i==0)
            {
                holder.ivCancel.setVisibility(View.GONE);
            }
            else
            {
                holder.ivCancel.setVisibility(View.VISIBLE);
            }
            holder.iv.setController(
                    Functions.frescoImageLoad(imgUrl,R.drawable.image_placeholder,
                            holder.iv,false));
            holder.bind(i, imgUrl, adapterClickListener);
        }
        else
        {
            BrowseProViewHolder holder=(BrowseProViewHolder) viewHolder;

            holder.bind(i, imgUrl, adapterClickListener);
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (listUserImage.get(position).equals("0") || listUserImage.get(position).equals("")) {
            return browseType;
        } else {
            return imageType;
        }

    }

    @Override
    public int getItemCount() {
        return listUserImage.size();
    }

    public class EditProViewHolder extends RecyclerView.ViewHolder {

        SimpleDraweeView iv;
        ImageView ivCancel;


        public EditProViewHolder(@NonNull View itemView) {
            super(itemView);

            iv = itemView.findViewById(R.id.edit_prof_IV_id);
            ivCancel = itemView.findViewById(R.id.ivCancel);

        }

        public void bind(final int pos, final String item, final AdapterClickListener onClickListner) {

            iv.setOnClickListener(v -> onClickListner.onItemClick(pos, item, v));
            ivCancel.setOnClickListener(v -> onClickListner.onItemClick(pos, item, v));

        }

    }


    public class BrowseProViewHolder extends RecyclerView.ViewHolder {


        RelativeLayout rlAddImg;

        public BrowseProViewHolder(@NonNull View itemView) {
            super(itemView);

            rlAddImg = itemView.findViewById(R.id.RL_add_img);

        }

        public void bind(final int pos, final String item, final AdapterClickListener onClickListner) {
            rlAddImg.setOnClickListener(v -> onClickListner.onItemClick(pos, item, v));

        }

    }


}
