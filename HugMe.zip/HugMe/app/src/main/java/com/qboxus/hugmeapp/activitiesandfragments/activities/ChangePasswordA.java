package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.volleypackage.CallBack;

import org.json.JSONObject;

public class ChangePasswordA extends AppCompatLocaleActivity implements View.OnClickListener{

    ViewFlipper viewFlipper;
    ImageView  goBack3;
    EditText  edNewPass;
    Button  changePass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        setContentView(R.layout.activitychange_password);
        viewFlipper = findViewById(R.id.viewflliper);
        goBack3 = findViewById(R.id.goBack3);
        edNewPass = findViewById(R.id.ed_new_pass);
        changePass = findViewById(R.id.change_password_btn);
        changePass.setOnClickListener(this);
        goBack3.setOnClickListener(this);


        edNewPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int count) {
                // check the password validation
                String txtName = edNewPass.getText().toString();
                if (txtName.length() > 0) {
                    changePass.setEnabled(true);
                    changePass.setClickable(true);
                } else {
                    changePass.setEnabled(false);
                    changePass.setClickable(false);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }


    @Override
    public void onClick(View v) {
         if (v == goBack3) {
            viewFlipper.showPrevious();
        }  else if (v == changePass) {
            if (validateNewPassword()) {
                final String fbId = Functions.getSharedPreference(ChangePasswordA.this).getString(Variables.FB_ID,"");
                ChangePassword(fbId, edNewPass.getText().toString());
            }
        }
    }

    // this method will call the api of change password
    private void ChangePassword(String userId, String newpass) {
        JSONObject params = new JSONObject();
        try {
            params.put("fb_id", userId);
            params.put("password", newpass);
        } catch (Exception e) {
            Functions.cancelLoader();
            e.printStackTrace();
        }
        Functions.showLoader(this, false, false);
        ApiRequest.callApi(this, ApiLinks.changeUserPassword, params, new CallBack() {
            @Override
            public void getResponse(String requestType, String resp) {
                Functions.cancelLoader();
                try {
                    JSONObject response = new JSONObject(resp);
                    String code = response.optString("code");
                    if (code.equals("200")) {
                        Functions.cancelLoader();
                        finish();
                    } else {
                        String msg_txt = response.getString("msg");
                        Toast.makeText(ChangePasswordA.this, msg_txt, Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }


    @Override
    public void onBackPressed() {
        if (viewFlipper.getDisplayedChild() == 0) {
            finish();
        } else if (viewFlipper.getDisplayedChild() == 1) {
            viewFlipper.showPrevious();
        } else
            viewFlipper.showPrevious();
    }


    // check the new password validations
    public boolean validateNewPassword() {
        String newpass = edNewPass.getText().toString();

        if (newpass.isEmpty()) {
            Toast.makeText(this, getString(R.string.please_enter_valid_new_password), Toast.LENGTH_SHORT).show();
            return false;
        }
        if (newpass.length() <= 5 || newpass.length() >= 12) {
            Toast.makeText(this, getString(R.string.please_enter_valid_password), Toast.LENGTH_SHORT).show();
            return false;
        } else {

            return true;
        }
    }
}