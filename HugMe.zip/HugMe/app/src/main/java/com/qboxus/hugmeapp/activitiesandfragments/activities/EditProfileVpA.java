package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.adapters.SegmentAdapter;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.DescribeYourselfF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.DrinkF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.GenderF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.KidsF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.LivingF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.RelationshipF;
import com.qboxus.hugmeapp.activitiesandfragments.fragments.SmokeF;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.volleypackage.CallBack;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.qboxus.hugmeapp.activitiesandfragments.activities.EditProfileA.updateProfile;
import static com.qboxus.hugmeapp.codeclasses.Variables.userGender;

public class EditProfileVpA extends AppCompatLocaleActivity implements View.OnClickListener {

    public static ViewPager vp;
    public static SegmentAdapter segmentAdapter;

    public static RelativeLayout colorRl, vpRl;

    public static LinearLayout backLl, descLl, happyLl, genderLl, relationLl, bodytypeLl, livingLl, kidsLl, smokeLl, drinkLl, profqsLl, missingLl, updateProfileLL;

    public static ImageView next, previous;
    public static TextView fragCounter;


    Context context;
    List<String> listUserImgFromApi = new ArrayList<>();

    public static void methodHidelinearlayout(LinearLayout ll1, LinearLayout ll2, LinearLayout ll3, LinearLayout ll4,
                                              LinearLayout ll5, LinearLayout ll6, LinearLayout ll7, LinearLayout ll8,
                                              LinearLayout ll9, LinearLayout ll10, LinearLayout ll11) {

        ll1.setVisibility(View.VISIBLE);
        ll2.setVisibility(View.GONE);
        ll3.setVisibility(View.GONE);
        ll4.setVisibility(View.GONE);
        ll5.setVisibility(View.GONE);
        ll6.setVisibility(View.GONE);
        ll7.setVisibility(View.GONE);
        ll8.setVisibility(View.GONE);
        ll9.setVisibility(View.GONE);
        ll10.setVisibility(View.GONE);
        ll11.setVisibility(View.GONE);


    }

    public static String getFragmentName(int position) {
        int totalPages = segmentAdapter.getCount();

        String fullFragmentName = segmentAdapter.getItem(position).toString();
        int index = fullFragmentName.indexOf("{");

        String fragmentName = fullFragmentName.substring(0, index);
        position = position + 1;

        if (fragmentName.equals("" + Variables.FRAG_ABOUT)) {
            methodHidelinearlayout(descLl, happyLl, relationLl, kidsLl, livingLl, drinkLl, smokeLl, profqsLl, genderLl, bodytypeLl, missingLl);
        } else if (fragmentName.equals("" + Variables.FRAG_DRINK)) {
            methodHidelinearlayout(drinkLl, descLl, relationLl, kidsLl, livingLl, happyLl, smokeLl, profqsLl, genderLl, bodytypeLl, missingLl);

        } else if (fragmentName.equals("" + Variables.FRAG_KIDS)) {
            methodHidelinearlayout(kidsLl, descLl, relationLl, drinkLl, livingLl, happyLl, smokeLl, profqsLl, genderLl, bodytypeLl, missingLl);

        } else if (fragmentName.equals("" + Variables.FRAG_LIVING)) {
            methodHidelinearlayout(livingLl, descLl, relationLl, drinkLl, kidsLl, happyLl, smokeLl, profqsLl, genderLl, bodytypeLl, missingLl);

        } else if (fragmentName.equals("" + Variables.FRAG_RELATION)) {

            methodHidelinearlayout(relationLl, descLl, livingLl, drinkLl, kidsLl, happyLl, smokeLl, profqsLl, genderLl, bodytypeLl, missingLl);

        } else if (fragmentName.equals("" + Variables.FRAG_SMOKE)) {

            methodHidelinearlayout(smokeLl, descLl, livingLl, drinkLl, kidsLl, happyLl, relationLl, profqsLl, genderLl, bodytypeLl, missingLl);

        } else if (fragmentName.equals("" + Variables.FRAG_GENDER)) {
            methodHidelinearlayout(genderLl, descLl, livingLl, drinkLl, kidsLl, happyLl, relationLl, profqsLl, smokeLl, bodytypeLl, missingLl);

        }

        if (totalPages == position) {

            next.setVisibility(View.GONE);

        }


        return fragmentName;
    }

    public static void createJsonForAPI(Context context) {
        final String userId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        Variables.varSexuality = Functions.getSharedPreference(context).getString(Variables.SEXUALITY,"");
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", "" + userId);
            parameters.put("about_me", "" + Variables.varAboutMe.replaceAll("[-+.^:,']", ""));
            parameters.put("job_title", "job_title");
            parameters.put("company", "company");
            parameters.put("school", "school");
            parameters.put("living", "" + Variables.varLiving.replaceAll("[-+.^:,']", ""));
            parameters.put("children", "" + Variables.varChildren.replaceAll("[-+.^:,']", ""));
            parameters.put("smoking", "" + Variables.varSmoking.replaceAll("[-+.^:,']", ""));
            parameters.put("drinking", "" + Variables.varDrinking.replaceAll("[-+.^:,']", ""));
            parameters.put("relationship", "" + Variables.varRelationship.replaceAll("[-+.^:,']", ""));
            parameters.put("sexuality", "" + Variables.varSexuality.replaceAll("[-+.^:,']", ""));

            parameters.put("image1", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE1,""));
            parameters.put("image2", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE2,""));
            parameters.put("image3", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE3,""));
            parameters.put("image4", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE4,""));
            parameters.put("image5", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE5,""));
            parameters.put("image6", "" + Functions.getSharedPreference(context).getString(Variables.IMAGE6,""));

            parameters.put("gender", "" + userGender.replaceAll("[-+.^:,']", ""));
            parameters.put("birthday", "" + Functions.getSharedPreference(context).getString(Variables.BIRTHDAY,""));


            updateProfile(context, parameters);

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        Window window = this.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.black));
        }
        setContentView(R.layout.activity_edit_profile_vp);

        context = EditProfileVpA.this;


        vp = (ViewPager) findViewById(R.id.vp_id);

        colorRl = (RelativeLayout) findViewById(R.id.color_rl_id);
        vpRl = (RelativeLayout) findViewById(R.id.vp_rl_id);

        backLl = (LinearLayout) findViewById(R.id.back_ll_id);
        descLl = (LinearLayout) findViewById(R.id.desc_ll_id);
        happyLl = (LinearLayout) findViewById(R.id.happy_ll_id);
        genderLl = (LinearLayout) findViewById(R.id.gender_ll_id);
        relationLl = (LinearLayout) findViewById(R.id.relationship_ll_id);
        bodytypeLl = (LinearLayout) findViewById(R.id.bodytype_ll_id);
        livingLl = (LinearLayout) findViewById(R.id.house_ll_id);
        kidsLl = (LinearLayout) findViewById(R.id.kids_ll_id);
        smokeLl = (LinearLayout) findViewById(R.id.smoking_ll_id);
        drinkLl = (LinearLayout) findViewById(R.id.drink_ll_id);
        profqsLl = (LinearLayout) findViewById(R.id.profqs_ll_id);
        missingLl = (LinearLayout) findViewById(R.id.missing_ll_id);

        updateProfileLL = (LinearLayout) findViewById(R.id.update_profile_LL);

        next = (ImageView) findViewById(R.id.next_id);
        previous = (ImageView) findViewById(R.id.previous_id);

        fragCounter = (TextView) findViewById(R.id.fragment_counter_id);


        segmentAdapter = new SegmentAdapter(getSupportFragmentManager());

        String aboutMe=Functions.getSharedPreference(context).getString(Variables.ABOUT_ME,"");
        String gender=Functions.getSharedPreference(context).getString(Variables.GENDER,"");
        String relationship=Functions.getSharedPreference(context).getString(Variables.RELATIONSHIP,"");
        String living=Functions.getSharedPreference(context).getString(Variables.LIVING,"");
        String children=Functions.getSharedPreference(context).getString(Variables.CHILDREN,"");
        String smoking=Functions.getSharedPreference(context).getString(Variables.SMOKING,"");
        String drinking=Functions.getSharedPreference(context).getString(Variables.DRINKING,"");


        if (TextUtils.isEmpty(aboutMe) || aboutMe.equalsIgnoreCase("null")) {
            segmentAdapter.addFragment(new DescribeYourselfF(), "");
        }

        if (TextUtils.isEmpty(gender) || gender.equalsIgnoreCase("null")) {
            segmentAdapter.addFragment(new GenderF(), "");
        }

        if (TextUtils.isEmpty(relationship) || relationship.equalsIgnoreCase("null")) {
            segmentAdapter.addFragment(new RelationshipF(), "");

        }

        if (TextUtils.isEmpty(living) || living.equalsIgnoreCase("null")) {
            segmentAdapter.addFragment(new LivingF(), "");

        }
        if (TextUtils.isEmpty(children) || children.equalsIgnoreCase("null")) {
            segmentAdapter.addFragment(new KidsF(), "");

        }
        if (TextUtils.isEmpty(smoking) || smoking.equalsIgnoreCase("null")) {
            segmentAdapter.addFragment(new SmokeF(), "");

        }

        if (TextUtils.isEmpty(drinking) || drinking.equalsIgnoreCase("null")) {
            segmentAdapter.addFragment(new DrinkF(), "");

        }


        if ((!(TextUtils.isEmpty(drinking)) || !(drinking.equalsIgnoreCase("null"))) &&
                (!(TextUtils.isEmpty(smoking)) || !(smoking.equalsIgnoreCase("null"))) &&
                (!(TextUtils.isEmpty(children)) || !(children.equalsIgnoreCase("null"))) &&
                (!(TextUtils.isEmpty(living)) || !(living.equalsIgnoreCase("null"))) &&
                (!(TextUtils.isEmpty(relationship)) || !(relationship.equalsIgnoreCase("null"))) &&
                (!(TextUtils.isEmpty(gender)) || !(gender.equalsIgnoreCase("null"))) &&
                (!(TextUtils.isEmpty(aboutMe)) || !(aboutMe.equalsIgnoreCase("null")))
        ) {

            imagesCheck();
        }


        String userId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");
        getuserInfo(userId);


        vp.setAdapter(segmentAdapter);
        fragCounter.setText((vp.getCurrentItem() + 1) + "/" + segmentAdapter.getCount());

        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) colorRl.getLayoutParams();
        lp.height = (int) (Variables.height / 2);

        colorRl.setLayoutParams(lp);


        RelativeLayout.LayoutParams lp1 = (RelativeLayout.LayoutParams) vpRl.getLayoutParams();
        lp1.height = (int) (Variables.height / 2);

        vpRl.setLayoutParams(lp1);

        vp.setCurrentItem(0);
        vp.setOnTouchListener((v, event) -> {
            vp.setCurrentItem(vp.getCurrentItem());
            return true;
        });

        next.setOnClickListener(this);
        previous.setOnClickListener(this);
        backLl.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.back_ll_id:
                finish();
                break;


            case R.id.next_id:

                int position = vp.getCurrentItem() + 1;

                vp.setCurrentItem(vp.getCurrentItem() + 1);

                fragCounter.setText((vp.getCurrentItem() + 1) + "/" + segmentAdapter.getCount());

                if (position == segmentAdapter.getCount()) {
                    next.setVisibility(View.GONE);
                }

                getFragmentName(vp.getCurrentItem());
                switch (vp.getCurrentItem()) {
                    case 0:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.coloraccent));
                        break;

                    case 1:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.red));

                        break;

                    case 2:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.lightblue));

                        break;

                    case 3:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.pink));

                        break;

                    case 4:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.orange));

                        break;

                    case 5:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.green));

                        break;

                    case 6:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.zink));

                        break;

                    case 7:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.light_purple));

                        break;

                    case 8:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.coloraccent));

                        break;

                    case 9:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.zink2));
                        break;

                    case 10:
                        RelativeLayout.LayoutParams lp1 = (RelativeLayout.LayoutParams) vpRl.getLayoutParams();
                        lp1.height = (int) (Variables.height / 1.1);

                        vpRl.setLayoutParams(lp1);

                        methodHidelinearlayout(missingLl, drinkLl, smokeLl, kidsLl, livingLl, bodytypeLl, relationLl, genderLl, happyLl, descLl, profqsLl);
                        break;

                    default:
                        break;
                }

                if (vp.getCurrentItem() != 10)
                    getFragmentName(vp.getCurrentItem());

                next.setVisibility(View.VISIBLE);
                break;

            case R.id.previous_id:
                vp.setCurrentItem(vp.getCurrentItem() - 1);

                switch (vp.getCurrentItem()) {
                    case 0:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.coloraccent));
                        break;

                    case 1:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.red));
                        break;

                    case 2:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.lightblue));
                        break;

                    case 3:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.pink));

                        break;

                    case 4:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.orange));

                        break;

                    case 5:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.green));
                        break;

                    case 6:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.zink));

                        break;

                    case 7:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.light_purple));

                        break;

                    case 8:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.coloraccent));

                        break;

                    case 9:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.zink2));

                        break;

                    case 10:
                        colorRl.setBackgroundColor(ContextCompat.getColor(context, R.color.coloraccent));
                        break;

                    default:
                        break;
                }

                getFragmentName(vp.getCurrentItem());
                next.setVisibility(View.VISIBLE);

                fragCounter.setText((vp.getCurrentItem() + 1) + "/" + segmentAdapter.getCount());
                break;

            default:
                break;
        }
    }


    public void imagesCheck() {
        String living=Functions.getSharedPreference(context).getString(Variables.LIVING,"");
        if ((!(TextUtils.isEmpty(living)) || !(living.equalsIgnoreCase("null")))) {
            startActivity(new Intent(context, EditProfileA.class));
            finish();

        }


    }

    public void getuserInfo(final String userId) {

        Functions.showLoader(context, false, false);
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", userId);

        } catch (Exception e) {
            e.printStackTrace();
        }
        ApiRequest.callApi(
                context,
                ApiLinks.getUserInfo,
                parameters,
                new CallBack() {
                    @Override
                    public void getResponse(String requestType, String resp) {
                        try {

                            Functions.cancelLoader();


                            JSONObject response = new JSONObject(resp);


                            if (response.getString("code").equals("200")) {


                                JSONArray msgObj = response.getJSONArray("msg");
                                JSONObject userInfoObj = msgObj.getJSONObject(0);

                                UserModel userdetailModel= ParseData.parseUserModel(userInfoObj);
                                Functions.storeUserLoginDataIntoDb(context,userdetailModel);


                                Variables.varSexuality = userInfoObj.getString("about_me");
                                Variables.varLiving = userInfoObj.getString("living");
                                Variables.varChildren = userInfoObj.getString("children");
                                Variables.varSmoking = userInfoObj.getString("smoking");
                                Variables.varDrinking = userInfoObj.getString("drinking");
                                Variables.varRelationship = userInfoObj.getString("relationship");
                                Variables.varSexuality = userInfoObj.getString("sexuality");
                                Variables.varAboutMe = userInfoObj.getString("about_me");
                                userGender = userInfoObj.getString("gender");

                                /* Get User Images */


                                if (!userInfoObj.getString("image1").equals("") && !userInfoObj.getString("image1").equals("0")) {

                                    listUserImgFromApi.add(userInfoObj.getString("image1"));
                                }


                                if (!userInfoObj.getString("image2").equals("") && !userInfoObj.getString("image2").equals("0")) {
                                    listUserImgFromApi.add(userInfoObj.getString("image2"));

                                }

                                if (!userInfoObj.getString("image3").equals("") && !userInfoObj.getString("image3").equals("0")) {
                                    listUserImgFromApi.add(userInfoObj.getString("image3"));

                                }

                                if (!userInfoObj.getString("image4").equals("") && !userInfoObj.getString("image4").equals("0")) {
                                    listUserImgFromApi.add(userInfoObj.getString("image4"));
                                }

                                if (!userInfoObj.getString("image5").equals("") && !userInfoObj.getString("image5").equals("0")) {
                                    listUserImgFromApi.add(userInfoObj.getString("image5"));

                                }

                                if (!userInfoObj.getString("image6").equals("") && !userInfoObj.getString("image6").equals("0")) {
                                    listUserImgFromApi.add(userInfoObj.getString("image6"));

                                }


                            }

                        } catch (Exception b) {
                            Functions.cancelLoader();
                            Functions.toastMsg(context, "" + b.toString());
                        }

                    }
                }
        );

    }

}
