package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.content.Context;
import androidx.annotation.NonNull;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nex3z.flowlayout.FlowLayout;

import java.util.ArrayList;
import java.util.List;

import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.adapters.ViewPagerAdpNew;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.codeclasses.VerticalViewPager;
import com.qboxus.hugmeapp.R;

import me.relex.circleindicator.CircleIndicator;

public class ViewProfileA extends AppCompatLocaleActivity {

    VerticalViewPager vp;
    ViewPagerAdpNew adp;
    CircleIndicator ci;
    CoordinatorLayout rl;
    BottomSheetBehavior behavior ;
    ImageView icCancel;
    Context context;
    TextView nameAndAge, aboutMeText;

    List<String> listProfileImg;
    Button logout;
    FlowLayout item;
    ArrayList<String> aboutMe = new ArrayList<>();
    ArrayList<Integer> aboutMePics = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        setContentView(R.layout.activity_view_profile);
        context = ViewProfileA.this;
        rl = (CoordinatorLayout) findViewById(R.id.view_prof_rl_id);
        listProfileImg = new ArrayList<>();
        aboutMeText = findViewById(R.id.about_me);


        logout = findViewById(R.id.logout);

        logout.setOnClickListener(v-> {
            Functions.logoutUser(context);

        });

        String firstName = Functions.getSharedPreference(context).getString(Variables.F_NAME,"");

        String aboutMeDescription=Functions.getSharedPreference(context).getString(Variables.ABOUT_ME,"");

        String age = ""+Functions.getSharedPreference(context).getInt(Variables.AGE,0);

        String image1 = Functions.getSharedPreference(context).getString(Variables.IMAGE1,"");

        String image2 = Functions.getSharedPreference(context).getString(Variables.IMAGE2,"");

        String image3 = Functions.getSharedPreference(context).getString(Variables.IMAGE3,"");

        String image4 = Functions.getSharedPreference(context).getString(Variables.IMAGE4,"");

        String image5 = Functions.getSharedPreference(context).getString(Variables.IMAGE5,"");

        String image6 = Functions.getSharedPreference(context).getString(Variables.IMAGE6,"");


        if(image1.equals("") || image1.equals("0")){
            // If Empty
        }else{
            // If not Empty
            listProfileImg.add(image1);

        }


        if(image2.equals("") || image2.equals("0")){
            // If Empty
        }else{
            // If not Empty
            listProfileImg.add(image2);
        }

        if(image3.equals("") || image3.equals("0")){
            // If Empty
        }else{
            // If not Empty
            listProfileImg.add(image3);
        }

        if(image4.equals("") || image4.equals("0")){
            // If Empty
        }else{
            // If not Empty
            listProfileImg.add(image4);
        }

        if(image5.equals("") || image5.equals("0")){
            // If Empty
        }else{
            // If not Empty
            listProfileImg.add(image5);
        }

        if(image6.equals("") || image6.equals("0")){
            // If Empty
        }else{
            // If not Empty
            listProfileImg.add(image6);
        }

        nameAndAge = findViewById(R.id.name_and_age);
        nameAndAge.setText("" + firstName + ", " + age);
        aboutMeText.setText("" + aboutMeDescription);

        // Basic Profile_F add into ListArray





        if( Functions.getSharedPreference(context).getString(Variables.LIVING,"").equals("")){
             // If EMpty

        }else{
            // Not Empty
            aboutMePics.add(R.drawable.ic_living);
            aboutMe.add("" + Functions.getSharedPreference(context).getString(Variables.LIVING,""));
        }

        if(Functions.getSharedPreference(context).getString(Variables.CHILDREN,"").equals("")){
            // If EMpty

        }else{
            // If not Empty
            aboutMePics.add(R.drawable.ic_childrens);
            aboutMe.add("" + Functions.getSharedPreference(context).getString(Variables.CHILDREN,""));

        }


        if(Functions.getSharedPreference(context).getString(Variables.SMOKING,"").equals("")){
            /// If EMpty

        }else{
            // If nOt EMpty
            aboutMePics.add(R.drawable.ic_smoking);
            aboutMe.add("" + Functions.getSharedPreference(context).getString(Variables.SMOKING,""));

        }


        if(Functions.getSharedPreference(context).getString(Variables.DRINKING,"").equals("")){
             // If EMpty

        }else{
            // If Not EMpty
            aboutMePics.add(R.drawable.ic_drinking);
            aboutMe.add("" + Functions.getSharedPreference(context).getString(Variables.DRINKING,""));

        }

        if(Functions.getSharedPreference(context).getString(Variables.RELATIONSHIP,"").equals("")){
             // If EMpty

        }else{
            // If Not Empty
            aboutMePics.add(R.drawable.ic_relationship);
            aboutMe.add("" + Functions.getSharedPreference(context).getString(Variables.RELATIONSHIP,""));
        }


        if(Functions.getSharedPreference(context).getString(Variables.SEXUALITY,"").equals("")){
            // If Empty

        }else{
            // If Not EMpty
            aboutMePics.add(R.drawable.ic_sexuality);
            aboutMe.add("" + Functions.getSharedPreference(context).getString(Variables.SEXUALITY,""));
        }


        inflateLayout();



        final float scale = this.getResources().getDisplayMetrics().density;
        int pixels = (int) (320 * scale + 0.5f);

        icCancel = findViewById(R.id.ic_cancel);

        icCancel.setOnClickListener(v-> {
                finish();

        });


        CoordinatorLayout.LayoutParams relBtn = new CoordinatorLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, pixels);
        rl.setLayoutParams(relBtn);

        vp = (VerticalViewPager) findViewById(R.id.view_prof_vp_id);
        adp = new ViewPagerAdpNew(getApplicationContext(), listProfileImg);
        ci = (CircleIndicator) findViewById(R.id.view_prof_ci_id);

        vp.setAdapter(adp);
        ci.setViewPager(vp);

        final View bottomsheet = findViewById(R.id.bottom_sheet);

        behavior = BottomSheetBehavior.from(bottomsheet);
        behavior.setState(BottomSheetBehavior.STATE_HALF_EXPANDED);

        behavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View view, int i) {
                if (i == BottomSheetBehavior.STATE_COLLAPSED){
                    behavior.setState(BottomSheetBehavior.STATE_HALF_EXPANDED);
                }
            }

            @Override
            public void onSlide(@NonNull View view, float v) {

            }
        });

    }

    // End Method to inflate Layout
    public void inflateLayout(){
        // Method to inflate Layout

        item = findViewById(R.id.inflate_layout);//where you want to add/inflate a view as a child

        for(int i = 0; i< aboutMe.size(); i++){
            View child = getLayoutInflater().inflate(R.layout.item_intrest, null);//child.xml
            ImageView image = child.findViewById(R.id.ic_image);
            TextView intrestName = child.findViewById(R.id.intrest_name);
            LinearLayout mainLinearLayout = child.findViewById(R.id.main_linear_layout);
            try{
                aboutMePics.get(i);
                image.setImageResource(aboutMePics.get(i));
            }catch (Exception b){
                b.printStackTrace();
            }


            if(!aboutMe.get(i).equals("0") && !aboutMe.get(i).equals(" ")){
                LinearLayout.LayoutParams buttonLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                buttonLayoutParams.setMargins(Variables.marginLeft, Variables.marginTop, Variables.marginRight, Variables.marginBottom);
                mainLinearLayout.setLayoutParams(buttonLayoutParams);

                intrestName.setText("" + aboutMe.get(i));
                item.addView(child);
            }

        }

        aboutMe.clear();

    }// End Method to inflate Layout

}
