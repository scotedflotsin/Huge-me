package com.qboxus.hugmeapp.activitiesandfragments.fragments.loginsteps;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import androidx.databinding.DataBindingUtil;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.activitiesandfragments.activities.EnableLocationA;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.PermissionUtils;
import com.qboxus.hugmeapp.codeclasses.RootFragment;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.databinding.FragmentSegmentAddPicBinding;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import static com.qboxus.hugmeapp.activitiesandfragments.fragments.loginsteps.SegmentDOBF.dobComplete;
import static com.qboxus.hugmeapp.activitiesandfragments.fragments.loginsteps.SegmentGenderF.gender;
import static com.qboxus.hugmeapp.activitiesandfragments.fragments.loginsteps.SegmentNameF.signupName;

public class SegmentAddPicF extends RootFragment {

    FragmentSegmentAddPicBinding binding;
    PermissionUtils takePermissionUtils;
    FirebaseStorage storage;
    StorageReference storageReference;
    String imgUrl;
    ByteArrayOutputStream baos=null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_segment_add_pic, container,false);
        String text = "Picture time! <br> Choose your photo";
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        binding.addPicTitleId.setText(Html.fromHtml(text));

        try {

            imgUrl=new JSONObject(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.SOCIAL_INFO_JSON,"{}")).optString("img_url");

        }
        catch (Exception e)
        {
            Functions.logDMsg("Exception: "+e);
        }
        binding.profilePic.setController(Functions.frescoImageLoad(imgUrl,R.drawable.ic_avatar,binding.profilePic,false));


        binding.addPicBtnId.setOnClickListener(v -> {
            uploadImageToFirebase();
        });
        binding.ivAddProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePermissionUtils=new PermissionUtils(getActivity(),mPermissionResult);
                if (takePermissionUtils.isStorageCameraPermissionGranted())
                {
                    selectImage();
                }
                else
                {
                    takePermissionUtils.showStorageCameraPermissionDailog(binding.getRoot().getContext().getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
                }

            }
        });

        binding.addPicRlId.setOnClickListener(v -> {
            takePermissionUtils=new PermissionUtils(getActivity(),mPermissionResult);
            if (takePermissionUtils.isStorageCameraPermissionGranted())
            {
                selectImage();
            }
            else
            {
                takePermissionUtils.showStorageCameraPermissionDailog(binding.getRoot().getContext().getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
            }

        });


        return binding.getRoot();
    }

    private ActivityResultLauncher<String[]> mPermissionResult = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onActivityResult(Map<String, Boolean> result) {

                    boolean allPermissionClear=true;
                    List<String> blockPermissionCheck=new ArrayList<>();
                    for (String key : result.keySet())
                    {
                        if (!(result.get(key)))
                        {
                            allPermissionClear=false;
                            blockPermissionCheck.add(Functions.getPermissionStatus(getActivity(),key));
                        }
                    }
                    if (blockPermissionCheck.contains("blocked"))
                    {
                        Functions.showPermissionSetting(getActivity(),binding.getRoot().getContext().getString(R.string.we_need_storage_and_camera_permission_for_upload_profile_pic));
                    }
                    else
                    if (allPermissionClear)
                    {
                        selectImage();
                    }

                }
            });


    // this method will show the dialog of selete the either take a picture form camera or pick the image from gallary
    private void selectImage() {

        final CharSequence[] options = {getString(R.string.take_photo),
                getString(R.string.choose_from_gallery), getString(R.string.cancel)};


        AlertDialog.Builder builder = new AlertDialog.Builder(binding.getRoot().getContext(), R.style.AlertDialogCustom);

        builder.setTitle(getString(R.string.add_photo_));

        builder.setItems(options, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (options[item].equals(getString(R.string.take_photo))) {
                    openCameraIntent();
                } else if (options[item].equals(getString(R.string.choose_from_gallery))) {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    resultCallbackForGallery.launch(intent);
                } else if (options[item].equals(getString(R.string.cancel))) {

                    dialog.dismiss();

                }

            }


        });

        builder.show();

    }

    ActivityResultLauncher<Intent> resultCallbackForGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        Uri selectedImage = data.getData();
                        beginCrop(selectedImage);

                    }
                }
            });


    // below three method is related with taking the picture from camera
    private void openCameraIntent() {
        Intent pictureIntent = new Intent(
                MediaStore.ACTION_IMAGE_CAPTURE);
        if (pictureIntent.resolveActivity(binding.getRoot().getContext().getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (Exception ex) {
            }
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(binding.getRoot().getContext().getApplicationContext(), binding.getRoot().getContext().getPackageName() + ".fileprovider", photoFile);
                pictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                resultCallbackForCamera.launch(pictureIntent);
            }
        }
    }

    ActivityResultLauncher<Intent> resultCallbackForCamera = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Matrix matrix = new Matrix();
                        try {
                            android.media.ExifInterface exif = new android.media.ExifInterface(imageFilePath);
                            int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                            switch (orientation) {
                                case android.media.ExifInterface.ORIENTATION_ROTATE_90:
                                    matrix.postRotate(90);
                                    break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_180:
                                    matrix.postRotate(180);
                                    break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_270:
                                    matrix.postRotate(270);
                                    break;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Uri selectedImage = (Uri.fromFile(new File(imageFilePath)));
                        beginCrop(selectedImage);
                    }
                }
            });



String imageFilePath="";
    private File createImageFile() throws Exception {
        String timeStamp =
                new SimpleDateFormat("yyyyMMdd_HHmmss",
                        Locale.ENGLISH).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir =
                binding.getRoot().getContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );

        imageFilePath = image.getAbsolutePath();
        return image;
    }

    private void beginCrop(Uri source) {
        Intent intent= CropImage.activity(source).setCropShape(CropImageView.CropShape.OVAL)
                .setAspectRatio(1,1).getIntent(binding.getRoot().getContext());
        resultCallbackForCrop.launch(intent);
    }

    ActivityResultLauncher<Intent> resultCallbackForCrop = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        CropImage.ActivityResult cropResult = CropImage.getActivityResult(data);
                        handleCrop(cropResult.getUri());
                    }
                }
            });

    // get the image uri after the image crope
    private void handleCrop(Uri userimageuri) {

        InputStream imageStream = null;
        try {
            imageStream = binding.getRoot().getContext().getContentResolver().openInputStream(userimageuri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        final Bitmap imagebitmap = BitmapFactory.decodeStream(imageStream);

        String path = userimageuri.getPath();
        Matrix matrix = new Matrix();
        android.media.ExifInterface exif = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            try {
                exif = new android.media.ExifInterface(path);
                int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                switch (orientation) {
                    case android.media.ExifInterface.ORIENTATION_ROTATE_90:
                        matrix.postRotate(90);
                        break;
                    case android.media.ExifInterface.ORIENTATION_ROTATE_180:
                        matrix.postRotate(180);
                        break;
                    case android.media.ExifInterface.ORIENTATION_ROTATE_270:
                        matrix.postRotate(270);
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        Bitmap rotatedBitmap = Bitmap.createBitmap(imagebitmap, 0, 0, imagebitmap.getWidth(), imagebitmap.getHeight(), matrix, true);
        baos = new ByteArrayOutputStream();
        rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 20, baos);

        File uriPath=Functions.getBitmapToUri(binding.getRoot().getContext(),rotatedBitmap,"profilePic"+Functions.getRandomString(2)+".jpg");

        binding.profilePic.setController(Functions.frescoImageLoad(Uri.fromFile(uriPath),R.drawable.ic_avatar,binding.profilePic,false));
    }


    public void uploadImageToFirebase() {

        Functions.showLoader(binding.getRoot().getContext(), false, false);

        String user_id="";

        try {
            user_id=new JSONObject(Functions.getSharedPreference(binding.getRoot().getContext()).getString(Variables.SOCIAL_INFO_JSON,"{}")).optString("user_id");

        }catch (Exception e){Functions.logDMsg("Exception: "+e);}

        if(imgUrl!=null && imgUrl.contains(Variables.http))
        {
            updateProfileParam(user_id,imgUrl);
        }
        else
        {

            byte[] data = baos.toByteArray();
            StorageReference ref = storageReference.child("images/" + user_id);
            String finalUser_id = user_id;
            ref.putBytes(data)
                    .addOnSuccessListener(taskSnapshot -> ref.getDownloadUrl().addOnSuccessListener(uri -> {

                        Functions.logDMsg("user_id: "+ finalUser_id);
                        Functions.logDMsg("uri: "+uri.toString());
                        updateProfileParam(finalUser_id,""+uri.toString());

                    }));


        }

    }

    private void updateProfileParam(String finalUser_id, String uri) {
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", finalUser_id);
            parameters.put("first_name", signupName);
            parameters.put("last_name", "");
            parameters.put("birthday", dobComplete);
            parameters.put("gender", "" + gender);
            parameters.put("image1", uri);

        } catch (Exception e) {
            e.printStackTrace();
        }

        apiCalling(ApiLinks.signUp, binding.getRoot().getContext(), parameters);

        Functions.cancelLoader();
    }


    public void apiCalling(String url, final Context context, JSONObject parameters) {
        try {

            ApiRequest.callApi(context, url, parameters, (requestType, resp) -> {
                        try {
                            JSONObject response = new JSONObject(resp);

                            if (response.getString("code").equals("200")) {

                                JSONArray msgObj = response.getJSONArray("msg");
                                JSONObject userInfoObj = msgObj.getJSONObject(0);

                                UserModel userdetailModel= ParseData.parseUserModel(userInfoObj);
                                Functions.storeUserLoginDataIntoDb(context,userdetailModel);

                                Functions.getSharedPreference(context).edit().putString(Variables.FB_ID,""+userInfoObj.optString("fb_id")).commit();


                                Functions.getSharedPreference(context).edit().putString(Variables.SOCIAL_INFO_JSON,"{}").commit();

                                Functions.cancelLoader();


                                openEnableLocation();


                            }

                            Functions.cancelLoader();

                        } catch (Exception b) {
                            Functions.cancelLoader();
                        }
                    }
            );
        }
        catch (Exception b) {
            Functions.cancelLoader();
        }

    }


    public void openEnableLocation() {
        startActivity(new Intent(binding.getRoot().getContext(), EnableLocationA.class));
        getActivity().overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
        getActivity().finish();
    }


}
