package com.qboxus.hugmeapp.activitiesandfragments.fragments.loginsteps;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.RootFragment;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;

import static com.qboxus.hugmeapp.activitiesandfragments.activities.SegmentsA.segmentedProgressBar;
import static com.qboxus.hugmeapp.activitiesandfragments.activities.SegmentsA.viewPager;

import org.json.JSONObject;

public class SegmentNameF extends RootFragment {

    public static String signupName;
    View view;
    Button btn;
    EditText text;
    Context context;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_segment_name, null);

        text = view.findViewById(R.id.name_ET_id);
        context = getContext();

        String name="";
        try {
            name=new JSONObject(Functions.getSharedPreference(context).getString(Variables.SOCIAL_INFO_JSON,"{}")).optString("name");
        }
        catch (Exception e){
            Functions.logDMsg("Exception: "+e);}
        text.setText("" + name);

        btn = (Button) view.findViewById(R.id.continue_btn_id);
        btn.setOnClickListener(v -> {
            signupName = text.getText().toString();

            if (signupName.isEmpty()) {
                text.setError("Please fill this");
            } else {
                viewPager.setCurrentItem(2);
                segmentedProgressBar.setCompletedSegments(2);
            }

        });

        return view;
    }
}
