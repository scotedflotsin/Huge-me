package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

import com.facebook.drawee.view.SimpleDraweeView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.klinker.android.link_builder.Link;
import com.klinker.android.link_builder.LinkBuilder;
import com.klinker.android.link_builder.TouchableMovementMethod;
import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.volleypackage.CallBack;
import com.theartofdev.edmodo.cropper.CropImage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class GetUserInfoA extends AppCompatLocaleActivity {

    SimpleDraweeView profileImage;
    TextView firstName, lastName;

    DatabaseReference rootref;

    ImageButton editProfileImage;
    EditText dateofbrithEdit;
    RadioButton maleBtn, femaleBtn;
    byte[] imageByteArray;

    String userId;

    boolean isEmail=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        setContentView(R.layout.activity_get_user_info);

        rootref = FirebaseDatabase.getInstance().getReference();
        isEmail=getIntent().getBooleanExtra("isEmail",false);

        profileImage = findViewById(R.id.profile_image);

        editProfileImage = findViewById(R.id.edit_profile_image);
        editProfileImage.setOnClickListener(v -> selectImage());


        firstName = findViewById(R.id.first_name);
        lastName = findViewById(R.id.last_name);


        dateofbrithEdit = findViewById(R.id.dateofbirth_edit);

        maleBtn = findViewById(R.id.male_btn);
        femaleBtn = findViewById(R.id.female_btn);


        dateofbrithEdit.setOnClickListener(v -> {

            Functions.opendatePicker(GetUserInfoA.this, dateofbrithEdit);
        });


        findViewById(R.id.nextbtn).setOnClickListener(v -> {

            String fName = firstName.getText().toString();
            String lName = lastName.getText().toString();
            String dateOfBirth = dateofbrithEdit.getText().toString();

            if (imageByteArray == null) {
                Functions.toastMsg(GetUserInfoA.this, this.getResources().getString(R.string.select_image));
            }
            else if (TextUtils.isEmpty(fName)) {
                Functions.toastMsg(GetUserInfoA.this, this.getResources().getString(R.string.please_enter_first_name));

            }
            else if (TextUtils.isEmpty(lName)) {
                Functions.toastMsg(GetUserInfoA.this, this.getResources().getString(R.string.please_enter_last_name));

            }
            else if (TextUtils.isEmpty(dateOfBirth)) {
                Functions.toastMsg(GetUserInfoA.this, this.getResources().getString(R.string.please_enter_date_of_birth));
            }
            else if(!chBox.isChecked()){
                Toast.makeText(this,"Please accept our 'Terms of use' & 'Privacy Policy'",Toast.LENGTH_LONG).show();
            }

            else {

                saveInfo();
            }


        });


        Intent intent = getIntent();
        if (intent.hasExtra("id")) {
            userId = intent.getExtras().getString("id","");
            userId = userId.replace("+", "");
        }
        if (intent.hasExtra("fname")) {
            firstName.setText(intent.getExtras().getString("fname"));
        }

        if (intent.hasExtra("lname")) {
            lastName.setText(intent.getExtras().getString("lname"));
        }



        SetupScreenData();
    }



    TextView login_terms_condition_txt;
    List<Link> links = new ArrayList<>();
    CheckBox chBox;
    private void SetupScreenData() {
        chBox = findViewById(R.id.chBox);
        login_terms_condition_txt =findViewById(R.id.login_terms_condition_txt);

        Link link = new Link(getString(R.string.terms_of_use));
        link.setTextColor(ContextCompat.getColor(this,R.color.black));
        link.setTextColorOfHighlightedLink(ContextCompat.getColor(this,R.color.colorPrimary));
        link.setUnderlined(true);
        link.setBold(false);
        link.setHighlightAlpha(.20f);
        link.setOnClickListener(new Link.OnClickListener() {
            @Override
            public void onClick(String clickedText) {
                openWebUrl(getString(R.string.terms_of_use),ApiLinks.App_Privacy_Policy_new);
            }
        });

        Link link2 = new Link(getString(R.string.privacy_policy));
        link2.setTextColor(ContextCompat.getColor(this,R.color.black));
        link2.setTextColorOfHighlightedLink(ContextCompat.getColor(this,R.color.colorPrimary));
        link2.setUnderlined(true);
        link2.setBold(false);
        link2.setHighlightAlpha(.20f);
        link2.setOnClickListener(new Link.OnClickListener() {
            @Override
            public void onClick(String clickedText) {
                openWebUrl(getString(R.string.privacy_policy),ApiLinks.App_Privacy_Policy_new);
            }
        });
        links.add(link);
        links.add(link2);
        CharSequence sequence = LinkBuilder.from(this, login_terms_condition_txt.getText().toString())
                .addLinks(links)
                .build();
        login_terms_condition_txt.setText(sequence);
        login_terms_condition_txt.setMovementMethod(TouchableMovementMethod.getInstance());
    }



    public void openWebUrl(String title, String url) {
        Intent intent=new Intent(this, WebviewA.class);
        intent.putExtra("url", url);
        intent.putExtra("title", title);
        startActivity(intent);
        overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
    }

    // open the gallary to select and upload the picture
    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 2);
    }


    // on select the bottom method will reture the uri of that image
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {

            if (requestCode == 2) {

                Uri selectedImage = data.getData();
                beginCrop(selectedImage);
            } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {

                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                handleCrop(result.getUri());
            }

        }

    }


    private void beginCrop(Uri source) {

        CropImage.activity(source)
                .start(this);
    }


    private void handleCrop(Uri userimageuri) {

        InputStream imageStream = null;
        try {
            imageStream = getContentResolver().openInputStream(userimageuri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        final Bitmap imagebitmap = BitmapFactory.decodeStream(imageStream);

        String path = userimageuri.getPath();
        Matrix matrix = new Matrix();
        android.media.ExifInterface exif = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            try {
                exif = new android.media.ExifInterface(path);
                int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                switch (orientation) {
                    case android.media.ExifInterface.ORIENTATION_ROTATE_90:
                        matrix.postRotate(90);
                        break;
                    case android.media.ExifInterface.ORIENTATION_ROTATE_180:
                        matrix.postRotate(180);
                        break;
                    case android.media.ExifInterface.ORIENTATION_ROTATE_270:
                        matrix.postRotate(270);
                        break;

                    default:
                        break;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Bitmap rotatedBitmap = Bitmap.createBitmap(imagebitmap, 0, 0, imagebitmap.getWidth(), imagebitmap.getHeight(), matrix, true);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
        imageByteArray = out.toByteArray();
        File uriPath=Functions.getBitmapToUri(GetUserInfoA.this,rotatedBitmap,"profilePic"+Functions.getRandomString(2)+".jpg");

        profileImage.setController(Functions.frescoImageLoad(Uri.fromFile(uriPath),R.drawable.ic_avatar,profileImage,false));

    }


    // this method is used to store the selected image into database
    public void saveInfo() {
        Functions.showLoader(this, false, false);
        // first we upload image after upload then get the picture url and save the group data in database
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference filelocation = storageReference.child("User_image")
                .child(userId + ".jpg");

        filelocation.putBytes(imageByteArray).addOnSuccessListener(taskSnapshot -> filelocation.getDownloadUrl().addOnSuccessListener(uri -> callApiForSignup(userId,
                firstName.getText().toString(),
                lastName.getText().toString(),
                dateofbrithEdit.getText().toString()
                , uri.toString())));


    }


    // this method will store the info of user to  database
    private void callApiForSignup(String userId,
                                  String fName, String lName,
                                  String birthday, String picture) {

        fName = fName.replaceAll("\\W+", "");
        lName = lName.replaceAll("\\W+", "");

        JSONObject parameters = new JSONObject();
        try {

            parameters.put("first_name", fName);
            parameters.put("last_name", lName);
            parameters.put("birthday", birthday);
            if (isEmail)
            {
                parameters.put("profile_type", "user");
                parameters.put("email", getIntent().getStringExtra("email"));
                parameters.put("password", getIntent().getStringExtra("password"));
            }
            else
            {
                parameters.put("fb_id", userId);
            }

            if (maleBtn.isChecked()) {
                parameters.put("gender", "Male");

            } else {
                parameters.put("gender", "Female");
            }
            parameters.put("image1", picture);

        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            String URL=ApiLinks.signUp;
            if (isEmail)
            {
                URL=ApiLinks.signupWithEmail;
            }
            else
            {
                URL=ApiLinks.signUp;
            }

            ApiRequest.callApi(
                    this,
                    URL,
                    parameters,
                    new CallBack() {
                        @RequiresApi(api = Build.VERSION_CODES.M)
                        @Override
                        public void getResponse(String requestType, String resp) {

                            Functions.cancelLoader();
                            try {
                                JSONObject response = new JSONObject(resp);

                                if (response.getString("code").equals("200")) {

                                    JSONArray msgObj = response.getJSONArray("msg");
                                    JSONObject userInfoObj = msgObj.getJSONObject(0);

                                    UserModel userdetailModel= ParseData.parseUserModel(userInfoObj);
                                    Functions.storeUserLoginDataIntoDb(GetUserInfoA.this,userdetailModel);
                                    Functions.getSharedPreference(GetUserInfoA.this).edit().putString(Variables.FB_ID,""+userInfoObj.optString("fb_id")).commit();
                                    if (isEmail)
                                    {
                                        Functions.getSharedPreference(GetUserInfoA.this).edit().putString(Variables.EMAIL,userInfoObj.optString("email")).commit();
                                    }

                                    Functions.getSharedPreference(GetUserInfoA.this).edit().putString(Variables.SOCIAL_INFO_JSON,"").commit();

                                    enableLocation();

                                }


                            } catch (Exception b) {
                                Functions.cancelLoader();
                            }
                        }
                    }
            );
        } catch (Exception b) {
            Functions.cancelLoader();
        }

    }


    private void enableLocation() {

        startActivity(new Intent(this, EnableLocationA.class));
        overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
        finishAffinity();

    }


    public void goback(View view) {
        finish();
    }


}
