package com.qboxus.hugmeapp.interfaces;

import android.os.Bundle;

public interface FragmentCallBack {
    void onResponce(Bundle bundle);
}
