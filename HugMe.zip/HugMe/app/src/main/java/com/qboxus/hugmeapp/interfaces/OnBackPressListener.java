package com.qboxus.hugmeapp.interfaces;

/**
 * Created by qboxus on 3/30/2018.
 */

public interface OnBackPressListener {
    public boolean onBackPressed();
}
