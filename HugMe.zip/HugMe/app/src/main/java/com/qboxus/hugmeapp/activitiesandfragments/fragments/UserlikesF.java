package com.qboxus.hugmeapp.activitiesandfragments.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.qboxus.hugmeapp.codeclasses.ParseData;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.activitiesandfragments.activities.MainActivity;
import com.qboxus.hugmeapp.adapters.UserLikeAdapter;
import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.RootFragment;
import com.qboxus.hugmeapp.inappsubscription.InAppSubscriptionA;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.interfaces.FragmentCallBack;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.volleypackage.ApiLinks;
import com.qboxus.hugmeapp.volleypackage.ApiRequest;
import com.qboxus.hugmeapp.volleypackage.CallBack;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class UserlikesF extends RootFragment {

    View view;
    Context context;

    ArrayList<UserModel> dataList;
    RecyclerView recyclerView;
    UserLikeAdapter adapter;

    String likesCount;
    ProgressBar progressBar;
    DatabaseReference databaseReference;

    Boolean isViewCreated = false;
    FragmentCallBack fragmentCallback;
    Boolean isFromTab = false;

    public UserlikesF() {
        //Required public constructor
    }


    public UserlikesF(FragmentCallBack fragmentCallback, Boolean isFromTab) {
        this.fragmentCallback = fragmentCallback;
        this.isFromTab = isFromTab;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_user_list, container, false);
        context = getContext();

        databaseReference = FirebaseDatabase.getInstance().getReference();

        progressBar = view.findViewById(R.id.progress_bar);

        Bundle bundle = getArguments();
        if (bundle != null) {
            likesCount = bundle.getString("like_count");
        }

        if (MainActivity.purductPurchase) {
            view.findViewById(R.id.reveal_my_like).setVisibility(View.GONE);
        }
        view.findViewById(R.id.reveal_my_like).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSubscriptionView();
            }
        });

        view.findViewById(R.id.back_btn).setOnClickListener(v -> {

            if (fragmentCallback != null) {
                fragmentCallback.onResponce(null);
            }
            getActivity().onBackPressed();
        });

        dataList = new ArrayList<>();

        recyclerView = (RecyclerView) view.findViewById(R.id.recylerview);
        recyclerView.setLayoutManager(new GridLayoutManager(context, 2));

        recyclerView.setHasFixedSize(true);

        adapter = new UserLikeAdapter(context, dataList, new AdapterClickListener() {
            @Override
            public void onItemClick(int postion, Object model, View view) {
                UserModel item = dataList.get(postion);

                switch (view.getId()) {
                    case R.id.favorite_id:
                        if (!(MainActivity.purductPurchase)) {
                            openSubscriptionView();
                        } else {
                            dataList.remove(postion);
                            updatedataOnrightSwipe(item);
                            adapter.notifyDataSetChanged();
                        }
                        break;

                    case R.id.delete_request:
                        if (!(MainActivity.purductPurchase)) {
                            openSubscriptionView();
                        } else {
                            dataList.remove(postion);
                            updatedataOnLeftSwipe(item);
                            adapter.notifyDataSetChanged();
                        }

                        break;


                    default:
                        break;


                }
            }

            @Override
            public void onLongItemClick(int postion, Object model, View view) {
                //auto generated method stub
            }
        });

        recyclerView.setAdapter(adapter);
        getPeopleNearby();
        isViewCreated = true;
        return view;
    }

    private void getPeopleNearby() {

        progressBar.setVisibility(View.VISIBLE);
        String userId =Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", userId);


        } catch (Exception e) {
            e.printStackTrace();
        }

        ApiRequest.callApi(context, ApiLinks.mylikies, parameters, new CallBack() {
            @Override
            public void getResponse(String requestType, String response) {
                progressBar.setVisibility(View.GONE);

                parseUserInfo(response);
            }
        });


    }


    public void parseUserInfo(String loginData) {
        try {
            JSONObject jsonObject = new JSONObject(loginData);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                dataList.clear();
                JSONArray msg = jsonObject.getJSONArray("msg");

                for (int i = 0; i < msg.length(); i++) {
                    JSONObject userdata = msg.getJSONObject(i);
                    UserModel item = ParseData.parseUserModel(userdata);

                    dataList.add(item);
                }

                if (dataList.isEmpty()) {
                    view.findViewById(R.id.nodata_found_txt).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.main_layout).setVisibility(View.GONE);
                } else {
                    view.findViewById(R.id.nodata_found_txt).setVisibility(View.GONE);
                    view.findViewById(R.id.main_layout).setVisibility(View.VISIBLE);
                }

                adapter.notifyDataSetChanged();

            }
        } catch (Exception e) {
            e.printStackTrace();
            view.findViewById(R.id.nodata_found_txt).setVisibility(View.VISIBLE);

        }
    }


    public void updatedataOnLeftSwipe(final UserModel item) {
        try {
            Functions.countNumClick(context);
            Functions.displayFbAd(context);
        } catch (Exception b) {

            Functions.toastMsg(context, "" + b.toString());

        }

        Functions.sendPushNotification(context, item.getFbId(), "dislike you", "dislike");

        final DatabaseReference rootref = FirebaseDatabase.getInstance().getReference();

        final String userId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("hh");
        final String formattedDate = df.format(c);

        rootref.child("Match").child(item.getFbId()).child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map mymap = new HashMap<>();
                    mymap.put("fragment_match", "false");
                    mymap.put("type", "dislike");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getFirstName());
                    mymap.put("effect", "true");


                    Map othermap = new HashMap<>();
                    othermap.put("fragment_match", "false");
                    othermap.put("type", "dislike");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", item.getFirstName());
                    othermap.put("effect", "false");

                    rootref.child("Match").child(userId + "/" + item.getFbId()).updateChildren(mymap);
                    rootref.child("Match").child(item.getFbId() + "/" + userId).updateChildren(othermap);

                } else {
                    Map mymap = new HashMap<>();
                    mymap.put("fragment_match", "false");
                    mymap.put("type", "dislike");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getFirstName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("fragment_match", "false");
                    othermap.put("type", "dislike");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", item.getFirstName());
                    othermap.put("effect", "false");

                    rootref.child("Match").child(userId + "/" + item.getFbId()).setValue(mymap);
                    rootref.child("Match").child(item.getFbId() + "/" + userId).setValue(othermap);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                //auto generated method stub
            }
        });

    }


    public void updatedataOnrightSwipe(final UserModel item) {
        try {
            Functions.countNumClick(context);
            Functions.displayFbAd(context);
        } catch (Exception b) {

            b.printStackTrace();
        }


        Functions.sendPushNotification(context, item.getFbId(), "Like you", "like");

        final DatabaseReference rootref = FirebaseDatabase.getInstance().getReference();
        final String userId = Functions.getSharedPreference(context).getString(Variables.FB_ID,"");

        final String userName = Functions.getSharedPreference(context).getString(Variables.F_NAME,"");


        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("hh");
        final String formattedDate = df.format(c);

        Query query = rootref.child("Match").child(item.getFbId()).child(userId);
        query.keepSynced(true);

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists() || item.getSwipe().equals("like")) {
                    Map mymap = new HashMap<>();
                    mymap.put("fragment_match", "true");
                    mymap.put("type", "like");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getFirstName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("fragment_match", "true");
                    othermap.put("type", "like");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", userName);
                    othermap.put("effect", "false");

                    rootref.child("Match").child(userId + "/" + item.getFbId()).updateChildren(mymap);
                    rootref.child("Match").child(item.getFbId() + "/" + userId).updateChildren(othermap);

                } else {
                    Map mymap = new HashMap<>();
                    mymap.put("fragment_match", "false");
                    mymap.put("type", "like");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getFirstName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("fragment_match", "false");
                    othermap.put("type", "like");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", userName);
                    othermap.put("effect", "false");

                    rootref.child("Match").child(userId + "/" + item.getFbId()).setValue(mymap);
                    rootref.child("Match").child(item.getFbId() + "/" + userId).setValue(othermap);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                //auto generated method stub
            }
        });

    }


    public void openSubscriptionView() {
        Intent intent=new Intent(context, InAppSubscriptionA.class);
        startActivity(intent);
    }
}
