package com.qboxus.hugmeapp.models;

public class MatchModel {
    public String uId;
    public String Picture;
    public  String Username;
    public  String totalCount;
    public String likeImage;


    public MatchModel() {

    }

    public String getuId() {
        return uId;
    }

    public void setuId(String uId) {
        this.uId = uId;
    }

    public String getPicture() {
        return Picture;
    }

    public void setPicture(String picture) {
        Picture = picture;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }
}
