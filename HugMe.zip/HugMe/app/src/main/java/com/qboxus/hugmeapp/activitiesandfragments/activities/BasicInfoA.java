package com.qboxus.hugmeapp.activitiesandfragments.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;

import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;

import static com.qboxus.hugmeapp.codeclasses.Variables.userGender;

public class BasicInfoA extends AppCompatLocaleActivity {

    Toolbar tb;
    ImageView iv;
    TextView nameId, birthdayId,change_password_id;
    Context context;
    RadioButton radioFemaleRBId, radioMaleRbId;
    String userGenderFromPrePage;
    private RadioGroup radioGroup;
    private RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);
        setContentView(R.layout.activity_basic_info);
        context = BasicInfoA.this;

        String firstName = Functions.getSharedPreference(context).getString(Variables.F_NAME,"");
        String birthday = Functions.getSharedPreference(context).getString(Variables.BIRTHDAY,"");
        String gender = Functions.getSharedPreference(context).getString(Variables.GENDER,"");
        String email = Functions.getSharedPreference(context).getString(Variables.EMAIL,"");
        try {
            Intent intent = getIntent();
            userGenderFromPrePage = intent.getStringExtra("gender");

        } catch (Exception b) {
            b.printStackTrace();
        }

        change_password_id=findViewById(R.id.change_password_id);
        radioGroup = findViewById(R.id.basic_info_RG_id);
        birthdayId = findViewById(R.id.birthday_id);
        radioFemaleRBId = findViewById(R.id.female_RB_id);
        radioMaleRbId = findViewById(R.id.male_RB_id);
        userGender = gender;
        if (gender.equals("male")) {
            // If gender is male
            radioMaleRbId.setChecked(true);
        } else if (gender.equals("female")) {
            radioFemaleRBId.setChecked(true);
        }

        if (userGenderFromPrePage != null && !userGenderFromPrePage.isEmpty()) {
            // If not empty
            if (userGenderFromPrePage.equalsIgnoreCase("male")) {
                // If gender is mAle
                radioMaleRbId.setChecked(true);
            } else if (userGenderFromPrePage.equalsIgnoreCase("female")) {
                radioFemaleRBId.setChecked(true);
            }
        }

        tb = (Toolbar) findViewById(R.id.basic_info_TB_id);
        iv = (ImageView) tb.findViewById(R.id.basic_info_back_id);
        nameId = findViewById(R.id.name_id);
        nameId.setText(getString(R.string.name)+"\n"+ firstName);
        birthdayId.setText(getString(R.string.birthday)+"\n"+ birthday);

        if (TextUtils.isEmpty(email))
        {
            change_password_id.setVisibility(View.GONE);
        }
        else
        {
            change_password_id.setVisibility(View.VISIBLE);
        }

        iv.setOnClickListener((View.OnClickListener) v -> {

            int selectedId = radioGroup.getCheckedRadioButtonId();
            radioButton = (RadioButton) findViewById(selectedId);
            userGender = radioButton.getTag().toString();
            finish();
        });

        change_password_id.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BasicInfoA.this, ChangePasswordA.class));
                overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
            }
        });
    }
}
