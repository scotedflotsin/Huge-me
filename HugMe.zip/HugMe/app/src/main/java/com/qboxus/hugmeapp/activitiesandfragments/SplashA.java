package com.qboxus.hugmeapp.activitiesandfragments;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.qboxus.hugmeapp.codeclasses.AppCompatLocaleActivity;
import com.qboxus.hugmeapp.activitiesandfragments.activities.ChatA;
import com.qboxus.hugmeapp.activitiesandfragments.activities.EnableLocationA;
import com.qboxus.hugmeapp.codeclasses.Functions;
import com.qboxus.hugmeapp.codeclasses.PermissionUtils;
import com.qboxus.hugmeapp.codeclasses.Variables;
import com.qboxus.hugmeapp.R;
import com.qboxus.hugmeapp.activitiesandfragments.activities.MainActivity;
import com.qboxus.hugmeapp.databinding.ActivitySplashBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class SplashA extends AppCompatLocaleActivity {


    Handler handler;
    Runnable runnable;
    ActivitySplashBinding binding;
    PermissionUtils takePermissionUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        Functions.setLocale(Functions.getSharedPreference(this).getString(Variables.APP_LANGUAGE_CODE,Variables.DEFAULT_LANGUAGE_CODE)
                , this, getClass(),false);


        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash);


        Variables.varTabChange = 0;

        Variables.height = getResources().getDisplayMetrics().heightPixels;
        Variables.width = getResources().getDisplayMetrics().widthPixels;

        handler = new Handler();
        runnable = () -> {
            if (Functions.checkLoginUser(SplashA.this))
            {
                takePermissionUtils = new PermissionUtils(SplashA.this, mPermissionLocationResult);
                if (takePermissionUtils.isLocationPermissionGranted()) {

                    getGPSLocationData();
                } else {
                    enableLocationByActivity();
                }
            }
        };
        handler.postDelayed(runnable, 1500);


        if (getIntent().getExtras() != null) {

            final Handler handler1 = new Handler();
            handler1.postDelayed(() -> {
                try {

                    if (getIntent().getExtras() != null) {
                        String icon = "", recId = "";
                        for (String key : getIntent().getExtras().keySet()) {
                            String value = getIntent().getExtras().getString(key);

                            if (key.equals("receiverid")) {
                                recId = getIntent().getExtras().getString("senderid");
                            } else if (key.equals("icon")) {
                                icon = getIntent().getExtras().getString("icon");
                            }

                            if (value != null) {

                                if (value.equals("messege")) {

                                    Intent myIntent = new Intent(this, ChatA.class);
                                    myIntent.putExtra("receiver_id", "" + recId);
                                    myIntent.putExtra("receiver_name", "");
                                    myIntent.putExtra("receiver_pic", "" + icon);
                                    myIntent.putExtra("match_api_run", "0");
                                    startActivity(myIntent);


                                }

                            }


                        }
                    }

                }catch (Exception e){

                }

            }, 3000);

        }

    }

    private void enableLocationByActivity() {
        startActivity(new Intent(binding.getRoot().getContext(), EnableLocationA.class));
    }


    private ActivityResultLauncher<String[]> mPermissionLocationResult = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onActivityResult(Map<String, Boolean> result) {

                    boolean allPermissionClear = true;
                    List<String> blockPermissionCheck = new ArrayList<>();
                    for (String key : result.keySet()) {
                        if (!(result.get(key))) {
                            allPermissionClear = false;
                            blockPermissionCheck.add(Functions.getPermissionStatus(SplashA.this, key));
                        }
                    }
                    if (blockPermissionCheck.contains("blocked")) {
                        Functions.showPermissionSetting(binding.getRoot().getContext(), getString(R.string.we_need_location_permission_to_give_you_better_app_experience));
                    } else if (allPermissionClear) {
                        getGPSLocationData();
                    }

                }
            });





    private void getGPSLocationData() {
        FusedLocationProviderClient mFusedLocationClient = LocationServices.getFusedLocationProviderClient(binding.getRoot().getContext());
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mFusedLocationClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                // Got last known location. In some rare situations this can be null.
                if (location != null) {
                    try {
                        Functions.logDMsg("Lat "+location.getLatitude());
                        Functions.logDMsg("Lng "+location.getLongitude());
                        goNext(location);
                    } catch (Exception e) {
                        Functions.logDMsg( "Exception : " + e);
                    }
                }
                else
                {
                    enableLocationByActivity();
                }
            }
        });
    }


    public void goNext(Location location) {

        if (location != null) {
            Functions.getSharedPreference(binding.getRoot().getContext()).edit()
                    .putFloat(Variables.LATITUDE, (float) location.getLatitude()).commit();
            Functions.getSharedPreference(binding.getRoot().getContext()).edit()
                    .putFloat(Variables.LONGITUDE, (float) location.getLongitude()).commit();

            Intent intent = new Intent(binding.getRoot().getContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        }
    }

    @Override
    public void onDestroy() {
        if (handler != null && runnable != null)
            handler.removeCallbacks(runnable);

        super.onDestroy();
    }

}
