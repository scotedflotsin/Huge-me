package com.qboxus.hugmeapp.adapters;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.backends.pipeline.PipelineDraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.postprocessors.BlurPostProcessor;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import com.qboxus.hugmeapp.activitiesandfragments.activities.MainActivity;
import com.qboxus.hugmeapp.codeclasses.AdapterClickListener;
import com.qboxus.hugmeapp.models.UserModel;
import com.qboxus.hugmeapp.R;

import java.util.ArrayList;

/**
 * Created by qboxus on 3/20/2018.
 */

public class UserLikeAdapter extends RecyclerView.Adapter<UserLikeAdapter.CustomViewHolder >{
    public Context context;
    ArrayList<UserModel> dataList;
    AdapterClickListener adapterClickListener;
    public UserLikeAdapter(Context context, ArrayList<UserModel> userDatalist, AdapterClickListener adapterClickListener) {
        this.context = context;
        this.dataList=userDatalist;
        this.adapterClickListener=adapterClickListener;

    }

    @Override
    public UserLikeAdapter.CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewtype) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_user_layout,null);
        UserLikeAdapter.CustomViewHolder viewHolder = new UserLikeAdapter.CustomViewHolder(view);
        return viewHolder;
    }

    @Override
    public int getItemCount() {
       return dataList.size();
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {

        public SimpleDraweeView image;
        ImageView deleteRequest, favoriteId;


        public CustomViewHolder(View view) {
            super(view);
            image=view.findViewById(R.id.image);
            favoriteId =view.findViewById(R.id.favorite_id);
            deleteRequest =view.findViewById(R.id.delete_request);
        }

        public void bind(final int pos,final UserModel item,
                         final AdapterClickListener adapterClickListener) {

            itemView.setOnClickListener(v -> {
                    adapterClickListener.onItemClick(pos,item,v);

            });
            favoriteId.setOnClickListener(v -> {
                    adapterClickListener.onItemClick(pos,item,v);

            });
            deleteRequest.setOnClickListener(v -> {
                adapterClickListener.onItemClick(pos, item, v);

            });

        }


    }


    @Override
    public void onBindViewHolder(final UserLikeAdapter.CustomViewHolder holder, final int i) {

        final UserModel item=dataList.get(i);

        holder.bind(i,item,adapterClickListener);

        if(item.getImage1()!=null && !item.getImage1().equals("")) {
            Uri uri = Uri.parse(item.getImage1());
            if(!(MainActivity.purductPurchase)){
                blurToolbar(uri,holder.image);
            }else{
                holder.image.setImageURI(uri);
            }

        }
   }

    private void blurToolbar(Uri uri , SimpleDraweeView image){
        if(context!=null){

            ImageRequest imageRequest = ImageRequestBuilder.newBuilderWithSource(Uri.parse(String.valueOf(uri)))
                    .setPostprocessor(new BlurPostProcessor(25,context))
                    .setRequestPriority(com.facebook.imagepipeline.common.Priority.HIGH)
                    .build();

            PipelineDraweeController controller = (PipelineDraweeController) Fresco.newDraweeControllerBuilder()
                    .setImageRequest(imageRequest)
                    .setOldController(image.getController())
                    .build();


            image.setController(controller);


        }
    }

}